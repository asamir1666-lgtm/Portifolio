package ca.ucalgary.seng300.validation.account.enums;

public enum AccountErrorCode {
    INVALID_FORMAT,
    USERNAME_TAKEN,
    INVALID_CREDENTIALS,
    USER_NOT_FOUND,
    PASSWORD_MISMATCH,
    INVALID_TOKEN,
    TOKEN_EXPIRED,
    SESSION_NOT_FOUND
}
