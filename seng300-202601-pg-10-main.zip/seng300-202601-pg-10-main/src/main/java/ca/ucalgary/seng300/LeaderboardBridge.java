package ca.ucalgary.seng300;

import ca.ucalgary.seng300.network.Client;
import ca.ucalgary.seng300.network.handler.client.LeaderboardHandler;
import ca.ucalgary.seng300.platformcore.GameType;
import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;


public class LeaderboardBridge extends BridgeBase {
    private LeaderboardHandler leaderboardHandler;
    public LeaderboardBridge(WebEngine engine, Client client) {
        super(engine);
        this.leaderboardHandler = client.router.getHandler(LeaderboardHandler.class);
        setUpHandlers();
    }

    public void attachBridge() {
        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.SUCCEEDED) {
                JSObject window = (JSObject) engine.executeScript("window");
                window.setMember("bridge", this);
            }
        });
    }

    public void setUpHandlers() {
        setUpLeaderboard();
    }

    public void setUpLeaderboard() {
        leaderboardHandler.setOnGetLeaderboard(res -> {

            StringBuilder sb = new StringBuilder("renderLeaderboard([");

            for (int i = 0; i < res.entries().size(); i++) {
                var entry = res.entries().get(i);
                var stats = entry.getPlayerStats();

                int tttWins = stats.getStatsForGame(GameType.TICTACTOE).getWins();
                int tttLosses = stats.getStatsForGame(GameType.TICTACTOE).getLosses();
                int tttDraws = stats.getStatsForGame(GameType.TICTACTOE).getDraws();
                int tttELO = stats.getStatsForGame(GameType.TICTACTOE).getEloRating();
                int tttTotalGames = stats.getStatsForGame(GameType.TICTACTOE).getTotalGames();

                int c4Wins = stats.getStatsForGame(GameType.CONNECTFOUR).getWins();
                int c4Losses = stats.getStatsForGame(GameType.CONNECTFOUR).getLosses();
                int c4Draws = stats.getStatsForGame(GameType.CONNECTFOUR).getDraws();
                int c4ELO = stats.getStatsForGame(GameType.CONNECTFOUR).getEloRating();
                int c4TotalGames = stats.getStatsForGame(GameType.CONNECTFOUR).getTotalGames();

                int wins = tttWins + c4Wins;
                int losses = tttLosses + c4Losses;
                int ELO = (tttELO + c4ELO) / 2;
                int totalGames = tttTotalGames + c4TotalGames;
                int draws = tttDraws + c4Draws;
                double winRate = totalGames > 0 ? (double) wins / totalGames : 0.0;
                String rawName = entry.getDisplayUsername() != null && !entry.getDisplayUsername().isBlank()
                        ? entry.getDisplayUsername()
                        : entry.getPlayerId().id();
                String username = escapeJs(rawName);

                sb.append("{")
                        .append("username:\"").append(username).append("\",")
                        .append("elo:").append(ELO).append(",")
                        .append("wins:").append(wins).append(",")
                        .append("losses:").append(losses).append(",")
                        .append("draws:").append(draws).append(",")
                        .append("totalGames:").append(totalGames).append(",")
                        .append("winRate:").append(Math.floor(winRate * 100))
                        .append("}");

                if (i < res.entries().size() - 1) sb.append(",");
            }

            sb.append("])");

            Platform.runLater(() -> {
                System.out.println(sb);
                engine.executeScript(sb.toString());
            });
        });

        leaderboardHandler.setOnError(err -> {
            Platform.runLater(() -> {
                String msg = escapeJs(err.message());
                engine.executeScript("console.log('" + msg + "')");
            });
        });
    }

    public void getTTTLeaderboard() {
        leaderboardHandler.getLeaderboard(GameType.TICTACTOE, 10);
    }

    public void getC4Leaderboard() {
        leaderboardHandler.getLeaderboard(GameType.CONNECTFOUR, 10);
    }

    private String escapeJs(String value) {
        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");
    }
}
