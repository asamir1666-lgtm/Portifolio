package ca.ucalgary.seng300.platformcore;

import java.io.Serializable;
import java.util.Objects;

public class LobbyJoinResponse implements Serializable {
    private static final long serialVersionUID = 1L;
  public boolean success;
  public String message;
  public LobbyResponseType type;

  public LobbyJoinResponse(boolean success, String message, LobbyResponseType type) {
    this.success = success;
    this.message = message;
    this.type = type;
  }
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append(success ? "Success" : "Failure");
    sb.append(" type = ").append(type);
    sb.append(" message = ").append(message);
    return sb.toString();
  }
  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if (!(obj instanceof LobbyJoinResponse other)) {
      return false;
    }
    return other.success == success && other.message.equals(message) && other.type.equals(type);
  }
  @Override
  public int hashCode() {
    return Objects.hash(success, message, type);
  }
}
