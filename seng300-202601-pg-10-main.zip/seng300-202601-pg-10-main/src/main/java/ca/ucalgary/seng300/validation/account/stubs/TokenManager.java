package ca.ucalgary.seng300.validation.account.stubs;

import java.io.Serializable;
import java.util.HashMap;

import ca.ucalgary.seng300.validation.account.records.UserID;

public class TokenManager implements Serializable {
    private static final long serialVersionUID = 1L;
    private HashMap<UserID, SessionToken> tokenStore = new HashMap<>();

    public HashMap<UserID, SessionToken> getTokenStore() {
        return tokenStore;
    }

    public SessionToken getToken(UserID userId) {
        return tokenStore.get(userId);
    }

    public boolean writeToken(UserID userId, SessionToken token) {
        tokenStore.put(userId, token);
        return true;
    }

    public boolean removeToken(UserID userId) {
        if (!tokenStore.containsKey(userId)) {
            return false;
        }
        tokenStore.remove(userId);
        return true;
    }

    public boolean hasToken(SessionToken token) {
        return tokenStore.containsValue(token);
    }
}
