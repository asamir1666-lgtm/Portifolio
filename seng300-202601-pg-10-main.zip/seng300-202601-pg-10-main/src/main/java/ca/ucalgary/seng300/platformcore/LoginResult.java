package ca.ucalgary.seng300.platformcore;

/**
 * This is just a rough placeholder so Login class has something to call. WILL CHANGE LATER
 */

public class LoginResult {
    private final boolean success;
    private final String message;

    public LoginResult(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }
}
