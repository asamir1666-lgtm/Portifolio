package ca.ucalgary.seng300.platformcore;

import java.io.Serializable;

// holds a player's stats for a specific game type
// tracks ELO rating, wins, losses, and total games player

// this is stub too!

public class GameStats implements Serializable
{
    private int eloRating;
    private int wins;
    private int losses;
    private int draws;

    public GameStats(int initialElo)
    {
        this.eloRating = initialElo;
    }

    public GameStats(int eloRating, int wins, int losses, int draws)
    {
        this.eloRating = eloRating;
        this.wins = wins;
        this.losses = losses;
        this.draws = draws;
    }

    public int getEloRating()
    {
        return eloRating;
    }
    
    public int getTotalGamesPlayed()
    {
        return wins + losses + draws;
    }

    public double getWinRate()
    {
        int totalGames = getTotalGamesPlayed();
        if (totalGames == 0) {
            return 0.0; // Avoid division by zero, can also return a default value or throw an exception
        }
        return (double) wins / totalGames;
    }

    public int getWins()
    {
        return wins;
    }

    public int getLosses()
    {
        return losses;
    }

    public int getDraws()
    {
        return draws;
    }

    public int getTotalGames()
    {
        return wins + losses + draws;
    }

    public void recordWin()
    {
        wins++;
    }

    public void recordLoss()
    {
        losses++;
    }

    public void recordDraws()
    {
        draws++;
    }

    // the ELO Calc should be performed externally and then update this rating directly.
    public void setEloRating(int newRating)
    {
        this.eloRating = newRating;
    }
}
