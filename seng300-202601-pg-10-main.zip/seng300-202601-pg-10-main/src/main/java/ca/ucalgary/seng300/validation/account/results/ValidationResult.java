package ca.ucalgary.seng300.validation.account.results;

import ca.ucalgary.seng300.validation.account.enums.AccountErrorCode;

public class ValidationResult {
    public boolean isValid;
    public AccountErrorCode errorCode;
    public String message;

    public ValidationResult(boolean isValid, AccountErrorCode errorCode, String message) {
        this.isValid = isValid;
        this.errorCode = errorCode;
        this.message = message;
    }

}
