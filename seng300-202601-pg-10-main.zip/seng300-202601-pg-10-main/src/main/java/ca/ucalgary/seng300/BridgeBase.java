package ca.ucalgary.seng300;

import javafx.application.Platform;
import javafx.scene.web.WebEngine;

public abstract class BridgeBase {
    protected final WebEngine engine;

    public BridgeBase(WebEngine engine) {
        this.engine = engine;
    }

    public void navigateTo(String page) {
        navigateTo(page, null);
    }

    public void navigateTo(String page, String queryString) {
        var resource = getClass().getResource("/ca/ucalgary/seng300/views/" + page);
        if (resource == null) {
            System.out.println("Could not find page: " + page);
            return;
        }
        final String url = (queryString != null && !queryString.isEmpty())
                ? resource.toExternalForm() + "?" + queryString
                : resource.toExternalForm();
        Platform.runLater(() -> engine.load(url));
    }

    public void log(String message) {
        System.out.println("[JS]: " + message);
    }
}
