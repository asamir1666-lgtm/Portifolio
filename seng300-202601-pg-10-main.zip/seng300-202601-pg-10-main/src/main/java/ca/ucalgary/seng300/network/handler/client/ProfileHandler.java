package ca.ucalgary.seng300.network.handler.client;

import java.util.Objects;
import java.util.function.Consumer;

import ca.ucalgary.seng300.network.message.Payload.Profile.Res;
import ca.ucalgary.seng300.network.message.Payload.Profile.Req;

public class ProfileHandler extends ClientHandler<Res>{
    private Consumer<Res.Get>   onGetProfile;
    private Consumer<Res.Stats> onGetStats;
    private Consumer<Res.Error> onError;

    public void setOnGetProfile(Consumer<Res.Get> cb)     { this.onGetProfile = cb; }
    public void setOnGetStats(Consumer<Res.Stats> cb)     { this.onGetStats = cb; }
    public void setOnError(Consumer<Res.Error> cb)        { this.onError = cb; }

	@Override
	public void handle(Res serverResponse) {
		switch (serverResponse) {
		    case Res.Get r      -> onGetProfile.accept(r);
		    case Res.Stats r    -> onGetStats.accept(r);
		    case Res.Error e    -> onError.accept(e);
        }
	}
    
    public void getProfile() {
        this.sender.accept(new Req.Get());
    }

    public void getStats() {
        this.sender.accept(new Req.Stats());
    }
    
	@Override
	public void validate() {
	    Objects.requireNonNull(onGetProfile, "Get profile callback must be set");
        Objects.requireNonNull(onGetStats,   "Get stats callback must be set");
	}
}


