package ca.ucalgary.seng300;

import ca.ucalgary.seng300.database.SessionAccounts;
import ca.ucalgary.seng300.database.SessionStore;
import ca.ucalgary.seng300.network.Client;
import ca.ucalgary.seng300.network.handler.client.AuthHandler;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;

import java.util.Map;

public class AccountBridge extends BridgeBase {
    private final SessionStore sessionDb;
    private final AuthHandler authHandler;
    private Bridge bridge;
    private LobbyBridge lobbyBridge;

    public AccountBridge(WebEngine engine, Client client, SessionStore sessionDb) {
        super(engine);
        this.sessionDb = sessionDb;
        this.authHandler = client.router.getHandler(AuthHandler.class);
    }

    public void setBridgeHooks(Bridge bridge, LobbyBridge lobbyBridge) {
        this.bridge = bridge;
        this.lobbyBridge = lobbyBridge;
    }

    public void attachBridge() {
        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.SUCCEEDED) {
                JSObject window = (JSObject) engine.executeScript("window");
                window.setMember("accountBridge", this);
            }
        });
    }

    public String getAccountsJson() {
        SessionAccounts acc = sessionDb.getData();
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (Map.Entry<String, SessionToken> e : acc.orderedEntries()) {
            if (!first) {
                sb.append(",");
            }
            first = false;
            String uid = e.getKey();
            String name = acc.displayName(uid);
            boolean active = uid.equals(acc.getActiveUserId());
            sb.append("{")
                    .append("\"id\":").append(jsonString(uid)).append(",")
                    .append("\"username\":").append(jsonString(name)).append(",")
                    .append("\"active\":").append(active)
                    .append("}");
        }
        sb.append("]");
        return sb.toString();
    }

    private static String jsonString(String s) {
        if (s == null) {
            return "\"\"";
        }
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    public void selectAccount(String userId) {
        SessionAccounts acc = sessionDb.getData();
        SessionToken t = acc.getTokenForUser(userId);
        if (t == null || t.tokenValue == null || t.tokenValue.isEmpty()) {
            return;
        }
        acc.setActiveUserId(userId);
        sessionDb.save();
        authHandler.loginWithToken(t);
    }

    public void removeAccount(String userId) {
        SessionAccounts acc = sessionDb.getData();
        acc.removeAccount(userId);
        sessionDb.save();
        if (acc.size() == 0) {
            navigateTo("login-signup.html");
            return;
        }
        Platform.runLater(() -> engine.executeScript(
                "if (typeof refreshAccountList==='function') refreshAccountList();"));
    }

    public void goToLogin() {
        if (bridge == null || lobbyBridge == null) {
            navigateTo("login-signup.html");
            return;
        }
        ChangeListener<Worker.State> listener = new ChangeListener<>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> obs, Worker.State o, Worker.State n) {
                if (n == Worker.State.SUCCEEDED) {
                    JSObject window = (JSObject) engine.executeScript("window");
                    window.setMember("javaApp", bridge);
                    window.setMember("javaLobby", lobbyBridge);
                    window.setMember("accountBridge", AccountBridge.this);
                    engine.getLoadWorker().stateProperty().removeListener(this);
                }
            }
        };
        engine.getLoadWorker().stateProperty().addListener(listener);
        navigateTo("login-signup.html");
    }
}
