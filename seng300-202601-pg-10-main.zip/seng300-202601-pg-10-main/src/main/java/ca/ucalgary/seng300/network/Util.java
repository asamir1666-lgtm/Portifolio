package ca.ucalgary.seng300.network;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.UUID;

import ca.ucalgary.seng300.Config;

public class Util {
    public static String getLocalIP() throws IOException {
        try (final DatagramSocket socket = new DatagramSocket()) {
            socket.connect(InetAddress.getByName("8.8.8.8"), Config.DISCOVERY_PORT);
            return socket.getLocalAddress().getHostAddress();
        } catch (Exception e) {
            return "";
        }
    }

    public static String getRandomClientId() {
        return " " + UUID.randomUUID().toString().substring(0, 8);
    }
}
