package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.platformcore.game.GameState;
import ca.ucalgary.seng300.platformcore.game.Piece;

/*
    This class determines the weight of the game state. It can be used to determine which moves are the best to preform
    Partly uses the following video as a basis: https://www.youtube.com/watch?v=DV5d31z1xTI
*/
public class BotWeightDetection {

    // Not 100% on if using == will work with pieces, so gotta make this
    static boolean pieceEqual(Piece a, Piece b){
        if(a == null || b == null) return false;

        return a.getSymbol() == b.getSymbol();
    }
    static boolean outsideC4Board(int i, int j){
        return i < 0 || j < 0 || i > 5 || j > 6;
    }

    static int[][] TTTBoardWeight = {
            {3,2,3},
            {2,4,2},
            {3,2,3},
    };

    /**
     * This calculates the score of a specific player using a weighted board.
     * The weight is determined by how many ways there are to win by having
     * a piece in that particular spot.
     *
     * Takes into account the opponents placement to calculate score.
     * @param gameState The current state of the game
     * @param playerPiece The piece you want to calculate the score in favor of (flipping this just negates the score)
     * @return The score of the player in this board setup
     */
    public static int TTT_calculatePlayerScore(GameState gameState, Piece playerPiece){
        // We loop through the board and add up the weights for each player
        int playerWeight = 0;
        int opponentWeight = 0;

        // Cache the board to save my fingers :)
        Piece[][] board = gameState.getGameBoard();

        // Loop through every spot on the board
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                // Grab the piece at this grid spot
                Piece spotPiece = board[i][j];

                if(pieceEqual(spotPiece, playerPiece)){
                    // This means the piece is the players
                    // We add score using the weighted board
                    playerWeight += TTTBoardWeight[i][j];
                }else if(pieceEqual(spotPiece, playerPiece.opposite())){
                    // This means the piece is the opponents
                    // We add score using the weighted board
                    opponentWeight += TTTBoardWeight[i][j];
                }
            }
        }

        // We subtract the scores to get the final score for the assigned player
        return playerWeight - opponentWeight;
    }

    static int[][] C4BoardWeight = {
            {3,4,5 ,7 ,5 ,4,3},
            {4,6,8 ,10,8 ,6,4},
            {5,7,11,13,11,7,5},
            {5,7,11,13,11,7,5},
            {4,6,8 ,10,8 ,6,4},
            {3,4,5 ,7 ,5 ,4,3},
    };

    /**
     * This calculates the score of a specific player using a weighted board.
     * The weight is determined by how many ways there are to win by having
     * a piece in that particular spot.
     *
     * Takes into account the opponents placement to calculate score.
     * @param gameState The current state of the game
     * @param playerPiece The piece you want to calculate the score in favor of (flipping this just negates the score)
     * @return The score of the player in this board setup
     */
    public static int C4_calculatePlayerScore(GameState gameState, Piece playerPiece){
        // We loop through the board and add up the weights for each player
        int playerWeight = 0;
        int opponentWeight = 0;

        // Cache the board to save my fingers :)
        Piece[][] board = gameState.getGameBoard();

        // Loop through every spot on the board
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                // Grab the piece at this grid spot
                Piece spotPiece = board[i][j];

                if (pieceEqual(spotPiece, playerPiece)){
                    // This means the piece is the players
                    // We add score using the weighted board
                    playerWeight += C4BoardWeight[i][j];
                }
                else if (pieceEqual(spotPiece, playerPiece.opposite())){
                    // This means the piece is the opponents
                    // We add score using the weighted board
                    opponentWeight += C4BoardWeight[i][j];
                }
            }
        }

        // We subtract the scores to get the final score for the assigned player
        return playerWeight - opponentWeight;
    }

    /**
     * This calculates the score of a specific player using a weighted board.
     * On top of calculating favored positions, it also adds weights for any
     * pieces in succession.
     *
     * Takes into account the opponents placement to calculate score.
     * @param gameState The current state of the game
     * @param playerPiece The piece you want to calculate the score in favor of (flipping this just negates the score)
     * @return The score of the player in this board setup
     */
    public static int C4_advancedPlayerScore(GameState gameState, Piece playerPiece){
        // We just get the score based on how valuable the positions of the peices are
        int basicScore = C4_calculatePlayerScore(gameState, playerPiece);

        int boardLineScore = 0;
        // We loop through every grid space
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                // Checks the grid space North, East and NorthEast for any series of pieces in a row.
                boardLineScore += checkSpotScore(i,j, gameState, playerPiece);
            }
        }

        return basicScore + boardLineScore;
    }

    // This controls the weight for some amount of pieces found in a row
    // Weights are set to show favor to moves that line pieces up, but to still
    // prioritize moves that set the bot up for more winning situations in the future
    // -----
    // 1 piece: 0
    // 2 pieces: 5
    // 3 pieces: 11
    static int[] rowScore = {0,5,11};


    static int checkSpotScore(int i, int j, GameState gameState, Piece playerPiece){

        Piece[][] board = gameState.getGameBoard();
        Piece originPiece = board[i][j];

        // If this spot is blank, we do not evaluate it
        if(pieceEqual(originPiece, playerPiece) || pieceEqual(originPiece, playerPiece.opposite())){
            return 0;
        }

        int score = 0;

        int row = i;
        int column = j;

        // We check north, east, and northeast
        // We keep going in those directions until we are off the board or don't find a piece

        // North
        row = i;
        column = j;
        for (int n = 0; n < 3; n++) {
            row++;

            if(outsideC4Board(row, column)){
                score += rowScore[n];
                break;
            }

            Piece spotPiece = board[row][column];
            if(!pieceEqual(spotPiece, originPiece)){
                score += rowScore[n];
                break;
            }
        }

        // East
        row = i;
        column = j;
        for (int n = 0; n < 3; n++) {
            column++;

            if(outsideC4Board(row, column)){
                score += rowScore[n];
                break;
            }

            Piece spotPiece = board[row][column];
            if(!pieceEqual(spotPiece, originPiece)){
                score += rowScore[n];
                break;
            }
        }

        // NorthEast
        row = i;
        column = j;
        for (int n = 0; n < 3; n++) {
            row++;
            column++;

            if(outsideC4Board(row, column)){
                score += rowScore[n];
                break;
            }

            Piece spotPiece = board[row][column];
            if(!pieceEqual(spotPiece, originPiece)){
                score += rowScore[n];
                break;
            }
        }


        // Score is positive for the right piece, negative for the wrong piece
        if(pieceEqual(playerPiece, originPiece)){
            return score;
        }else if(pieceEqual(playerPiece.opposite(), originPiece)){
            return -score;
        }

        // Should never reach here
        return 0;
    }
}
