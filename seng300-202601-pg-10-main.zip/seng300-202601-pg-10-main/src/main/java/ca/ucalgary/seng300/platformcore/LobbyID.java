package ca.ucalgary.seng300.platformcore;

import java.io.Serializable;

public record LobbyID(String id) implements Serializable {
    private static final long serialVersionUID = 1L;}
