package ca.ucalgary.seng300;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import netscape.javascript.JSObject;

import java.util.logging.Logger;

import ca.ucalgary.seng300.database.Database;
import ca.ucalgary.seng300.database.SessionAccounts;
import ca.ucalgary.seng300.database.SessionStore;
import ca.ucalgary.seng300.logger.Logging;
import ca.ucalgary.seng300.network.Client;
import ca.ucalgary.seng300.network.handler.client.AuthHandler;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;

public class MainApp extends Application {
    private static boolean loggedIn = false;
    private static Client client;
    private static final Logger logger = Logging.getLogger("MainApp");
    private static SessionStore sessionDb = Database.getInstance(SessionStore.class);

    /** none | local | auto | ip — from {@link #main(String[])} args */
    private static String startupConnectMode = "none";
    private static String startupConnectIp;

    private static WebView webView;
    private static WebEngine engine;

    public static String getStartupConnectMode() {
        return startupConnectMode != null ? startupConnectMode : "none";
    }

    public static String getStartupConnectIp() {
        return startupConnectIp;
    }

    public static void onServerConnected(Client newClient) {
        client = newClient;
        continueApplicationStartup();
    }

    @Override
    public void start(Stage stage) {
        webView = new WebView();
        engine = webView.getEngine();

        sessionDb.connect();

        Scene scene = new Scene(webView, 1200, 800);
        stage.setTitle("SENG300 App");
        stage.setScene(scene);
        stage.show();

        ServerConnectionBridge connectionBridge = new ServerConnectionBridge(engine);
        connectionBridge.attachBridge();
        engine.load(MainApp.class.getResource("/ca/ucalgary/seng300/views/server-connection.html").toExternalForm());
    }

    private static void continueApplicationStartup() {
        SessionAccounts acc = sessionDb.getData();
        AuthHandler authHandler = client.router.getHandler(AuthHandler.class);

        authHandler.setOnLoginToken(r -> {
            logger.info("Login with token successful");
            loggedIn = true;
            Platform.runLater(MainApp::loadAndInit);
        });

        authHandler.setOnError(e -> {
            logger.warning("Token is invalid, login manually, " + e.message());
            loggedIn = false;
            authHandler.setOnError(null);

            Platform.runLater(MainApp::loadAndInit);
        });

        if (acc.size() > 1) {
            Bridge bridge = new Bridge(engine);
            AccountBridge accountBridge = new AccountBridge(engine, client, sessionDb);
            GameBridge gameBridge = new GameBridge(engine, client);
            LobbyBridge lobbyBridge = new LobbyBridge(engine, client, sessionDb, gameBridge, accountBridge, bridge);
            PostGameResultsBridge pgrBridge = new PostGameResultsBridge(engine, client, lobbyBridge);
            MatchmakingBridge matchmakingBridge = new MatchmakingBridge(engine, client, lobbyBridge);
            accountBridge.setBridgeHooks(bridge, lobbyBridge);
            accountBridge.attachBridge();
            lobbyBridge.attachBridge();
            bridge.attachBridge();
            gameBridge.attachBridge();
            pgrBridge.attachBridge();
            matchmakingBridge.attachBridge();
            engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
                if (newState == javafx.concurrent.Worker.State.SUCCEEDED) {
                    JSObject window = (JSObject) engine.executeScript("window");
                    window.setMember("accountBridge", accountBridge);
                    window.setMember("javaApp", bridge);
                    window.setMember("javaLobby", lobbyBridge);
                    window.setMember("pgrBridge", pgrBridge);
                    window.setMember("matchmakingBridge", matchmakingBridge);
                    engine.executeScript("if(typeof refreshAccountList==='function') refreshAccountList()");
                }
            });
            engine.load(MainApp.class.getResource("/ca/ucalgary/seng300/views/accounts.html").toExternalForm());
            return;
        }
        if (acc.size() == 1) {
            SessionToken t = acc.getOnlyToken();
            if (t != null) {
                authHandler.loginWithToken(t);
            } else {
                loadAndInit();
            }
            return;
        }
        loadAndInit();
    }

    private static void loadAndInit() {
        String url;
        try {
            if (!loggedIn) {
                url = MainApp.class.getResource("/ca/ucalgary/seng300/views/login-signup.html").toExternalForm();
                engine.load(url);
            } else {
                url = MainApp.class.getResource("/ca/ucalgary/seng300/views/dashboard.html").toExternalForm();
                engine.load(url);
            }
        } catch (Exception e) {
            url = MainApp.class.getResource("/ca/ucalgary/seng300/views/404.html").toExternalForm();
            engine.load(url);
            System.err.println("File not found.");
        }

        Bridge bridge = new Bridge(engine);
        AccountBridge accountBridge = new AccountBridge(engine, client, sessionDb);
        GameBridge gameBridge = new GameBridge(engine, client);
        LobbyBridge lobbyBridge = new LobbyBridge(engine, client, sessionDb, gameBridge, accountBridge, bridge);
        accountBridge.setBridgeHooks(bridge, lobbyBridge);
        accountBridge.attachBridge();
        PostGameResultsBridge pgrBridge = new PostGameResultsBridge(engine, client, lobbyBridge);
        LeaderboardBridge leaderboardBridge = new LeaderboardBridge(engine, client);
        MatchmakingBridge matchmakingBridge = new MatchmakingBridge(engine, client, lobbyBridge);

        bridge.attachBridge();
        pgrBridge.attachBridge();
        lobbyBridge.attachBridge();
        gameBridge.attachBridge();
        leaderboardBridge.attachBridge();
        matchmakingBridge.attachBridge();

        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == javafx.concurrent.Worker.State.SUCCEEDED) {
                JSObject window = (JSObject) engine.executeScript("window");
                window.setMember("javaApp", bridge);
                window.setMember("javaLobby", lobbyBridge);
                window.setMember("javaLeaderboard", leaderboardBridge);
                window.setMember("pgrBridge", pgrBridge);
                window.setMember("accountBridge", accountBridge);
                window.setMember("matchmakingBridge", matchmakingBridge);

                lobbyBridge.sendLobbyData();
                bridge.sendLeaderboardData();
                bridge.sendUserStats();
                bridge.sendSeasonProgress();
                bridge.sendUsernames("theGuy01", "phantomx2023");

            }
        });
    }

    public static void main(String[] args) {
        if (args.length > 0) {
            String a = args[0].trim();
            if (a.equalsIgnoreCase("auto")) {
                startupConnectMode = "auto";
            } else if (a.equalsIgnoreCase("local")) {
                startupConnectMode = "local";
            } else {
                startupConnectMode = "ip";
                startupConnectIp = args[0].trim();
            }
        }
        launch(args);
    }
}
