package ca.ucalgary.seng300.network.handler.server;

import ca.ucalgary.seng300.database.AccountDatabase;
import ca.ucalgary.seng300.database.LeaderboardDatabase;
import ca.ucalgary.seng300.network.ClientData;
import ca.ucalgary.seng300.network.message.Payload.Error;
import ca.ucalgary.seng300.network.message.Payload.Profile.Req;
import ca.ucalgary.seng300.network.message.Payload.Profile.Res;
import ca.ucalgary.seng300.platformcore.Leaderboard;
import ca.ucalgary.seng300.platformcore.MatchHistoryEntry;
import ca.ucalgary.seng300.platformcore.PlayerStats;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.account.stubs.UserCredentials;

import java.util.ArrayList;

public class ProfileHandler extends ServerHandler<Req, Res> {
    private final AccountDatabase accountDatabase;
    private final LeaderboardDatabase leaderboardDatabase;
    private ClientData clientData;

    public ProfileHandler(AccountDatabase accountDatabase, LeaderboardDatabase leaderboardDatabase) {
        this.accountDatabase = accountDatabase;
        this.leaderboardDatabase = leaderboardDatabase;
    }

    @Override
    public Res handle(Req req, ClientData clientData) {
        this.clientData = clientData;
        return switch (req) {
            case Req.Get r      -> getProfileHandler(r);
            case Req.Stats r    -> getStatsHandler(r);
        };
    }

    public Res getProfileHandler(Req.Get req) {
        UserID userID = this.clientData.getPlayer().getID();
        UserCredentials creds = accountDatabase.getData().getCredentialsStore().getCredentialsByUserID(userID);
        if (creds == null) {
            return new Error("User not found");
        }

        return new Res.Get(creds.profile);
    }

    public Res getStatsHandler(Req.Stats req) {
        UserID userID = this.clientData.getPlayer().getID();
        PlayerStats stats = this.clientData.getPlayer().getStats();
        Leaderboard lb = leaderboardDatabase.getData();
        ArrayList<MatchHistoryEntry> history = lb.getMatchHistory(userID);
        return new Res.Stats(stats, history);
    }
}
