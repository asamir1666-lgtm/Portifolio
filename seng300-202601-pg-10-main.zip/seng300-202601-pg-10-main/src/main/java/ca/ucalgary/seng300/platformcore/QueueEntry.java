package ca.ucalgary.seng300.platformcore;
import ca.ucalgary.seng300.platformcore.Player;
import java.time.Instant;

// wraps a player with the time they entered matchmaking queue

public class QueueEntry
{
    private final Player player;
    private final Instant enqueuedAt;

    public QueueEntry(Player player) {
        this.player = player;
        this.enqueuedAt = Instant.now();
    }

    public Player getPlayer()
    {
        return player;
    }

    public Instant getEnqueuedAt()
    {
        return enqueuedAt;
    }

    public long getWaitSeconds()
    {
        return java.time.Duration.between(enqueuedAt, Instant.now()).getSeconds();
    }

    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }

        if (!(o instanceof QueueEntry other))
        {
            return false;
        }
        return player.equals(other.player);
    }
}
