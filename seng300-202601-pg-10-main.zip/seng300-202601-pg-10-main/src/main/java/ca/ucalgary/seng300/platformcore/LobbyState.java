package ca.ucalgary.seng300.platformcore;

public enum LobbyState {
    WAITING_FOR_PLAYERS,
    FULL,
    IN_GAME,
    GAME_OVER
}
