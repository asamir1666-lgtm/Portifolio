package ca.ucalgary.seng300.lobby;
import java.util.List;
import static ca.ucalgary.seng300.platformcore.GameType.CONNECTFOUR;
import static ca.ucalgary.seng300.platformcore.GameType.TICTACTOE;

public class LobbyStubData {
    private LobbyStubData(){

    }
    public static List<LobbyEntry> getLobbyEntries(){
        return List.of(
                new LobbyEntry("1", TICTACTOE, 2, "1"),
                new LobbyEntry("2", CONNECTFOUR, 2, "1"),
                new LobbyEntry("3", TICTACTOE, 2, "1"),
                new LobbyEntry("4", CONNECTFOUR, 2, "1"),
                new LobbyEntry("5", TICTACTOE, 2, "1"),
                new LobbyEntry("6", CONNECTFOUR, 2, "1"),
                new LobbyEntry("7", TICTACTOE, 2, "1"),
                new LobbyEntry("8", CONNECTFOUR, 2, "1"),
                new LobbyEntry("9", TICTACTOE, 2, "1")
        );
    }
}
