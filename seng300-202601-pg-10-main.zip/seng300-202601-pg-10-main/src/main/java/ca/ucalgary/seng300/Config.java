package ca.ucalgary.seng300;

import ca.ucalgary.seng300.network.DiscoveryType;

public class Config {
    public static final int DEFAULT_ELO = 1000;
    public static final int JOIN_CODE_LENGTH = 6;
    public static final int DEFAULT_MAX_CAPACITY_LOBBY = 2;

    public static String DATABASE_FOLDER = "database_files";
    public static final String LEADERBOARD_FILE = "leaderboard";
    public static final String LOBBY_FILE = "lobby";
    public static final String ACCOUNT_FILE = "accounts";

    public static final String SESSION_ACCOUNTS_FILE = "session_accounts";

    public static int GAME_PORT = 2005;
    public static int DISCOVERY_PORT = 2006;
    public static int MAX_RETRY_ATTEMPTS = 3;

    public static String CLIENT_DISCOVERY_MESSAGE = "DISCOVER_SERVER";
    public static String SERVER_REPLY_DISCOVERY = "GAME_SERVER_HERE";

    public static DiscoveryType DISCOVERY_METHOD = DiscoveryType.SUBNET_SCAN;
}
