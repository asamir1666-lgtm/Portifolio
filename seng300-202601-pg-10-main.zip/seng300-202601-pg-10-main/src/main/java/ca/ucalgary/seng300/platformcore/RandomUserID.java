package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.validation.account.records.UserID;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//adjectives.txt
//nouns.txt

public class RandomUserID {
    public static UserID createRandomUsername() {
        String adjective;
        String noun;
        int n; //4 digits
        List<String> adjectives = new ArrayList<>();
        List<String> nouns = new ArrayList<>();

        try(BufferedReader adjReader = new BufferedReader(new FileReader("adjectives.txt"));
            BufferedReader nounReader = new BufferedReader(new FileReader("nouns.txt"))) {
            String line;
            while ((line = adjReader.readLine()) != null) {
                adjectives.add(line);
            }
            while ((line = nounReader.readLine()) != null) {
                nouns.add(line);
            }
            if (adjectives.isEmpty() || nouns.isEmpty()) {
                return new UserID("RandomBot1234");
            }

            Random rand = new Random();
            adjective = adjectives.get(rand.nextInt(adjectives.size()));
            noun = nouns.get(rand.nextInt(nouns.size()));
            n = 1000 + rand.nextInt(9000);

            return new UserID(adjective + noun + n);
        }
        catch (IOException e) {
            return new UserID("RandomBot1234");
        }
    }
}
