package ca.ucalgary.seng300;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.logging.Logger;

import ca.ucalgary.seng300.logger.Logging;
import ca.ucalgary.seng300.network.Client;
import ca.ucalgary.seng300.network.handler.client.GameHandler;
import ca.ucalgary.seng300.network.handler.client.ProfileHandler;
import ca.ucalgary.seng300.platformcore.EloCalculator;
import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.platformcore.game.GameAbstract;
import ca.ucalgary.seng300.platformcore.game.GameMove;
import ca.ucalgary.seng300.platformcore.game.GridSpace;
import ca.ucalgary.seng300.platformcore.game.MoveResult;
import ca.ucalgary.seng300.platformcore.game.Piece;
import ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourGame;
import ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourMove;
import ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourPiece;
import ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToeGame;
import ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToeMove;
import ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToePiece;
import ca.ucalgary.seng300.validation.account.records.UserID;
import javafx.application.Platform;
import javafx.scene.web.WebEngine;
import javafx.concurrent.Worker;
import netscape.javascript.JSObject;

public class GameBridge extends BridgeBase {
    private final GameHandler gameHandler;
    private final Logger logger = Logging.getLogger("GameBridge");

    private UserID myId;
    private Player[] players;
    private GameType currentGameType;
    private MoveResult lastFinishedMatch;
    private HashMap<UserID, String> connectFourColorByUserId = new HashMap<>();

    public GameBridge(WebEngine engine, Client client) {
        super(engine);
        this.gameHandler = client.router.getHandler(GameHandler.class);
        setUpHandlers();
    }

    public void setMyId(UserID id) {
        this.myId = id;
    }

    public void attachBridge() {
        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.SUCCEEDED) {
                JSObject window = (JSObject) engine.executeScript("window");
                window.setMember("GameBridge", this);
            }
        });
    }

    private void setUpHandlers() {
        setUpGameHandler();
    }
    
    public void onStart() {
        gameHandler.requestState();
    }

    private void handleConnectFour(ConnectFourGame game) {
        ConnectFourPiece piece = (ConnectFourPiece) game.currentPlayerPiece();
        
        HashMap<UserID, ConnectFourPiece> playerPieceMapping = game.getPlayerPieceMapping();
        Player[] players = game.getPlayers();
        this.players = players;
        
        String playerOneName = players[0].getUsername();
        String playerTwoName = players[1].getUsername();

        UserID playerOneId = players[0].getID();

        int playerOneElo = players[0].getGameStats(game.getGameType()).getEloRating();
        int playerTwoElo = players[1].getGameStats(game.getGameType()).getEloRating();

        ConnectFourPiece playerOnePiece = playerPieceMapping.get(playerOneId);

        String colorTurn = piece.toString();

        String meColor = playerPieceMapping.get(myId).toString();

        connectFourColorByUserId = new HashMap<>();
        for (Player p : players) {
            ConnectFourPiece pc = playerPieceMapping.get(p.getID());
            if (pc != null) {
                connectFourColorByUserId.put(p.getID(), pc.toString());
            }
        }

        if (playerOnePiece == ConnectFourPiece.RED) {
            startConnect4Game(
                playerOneName, 
                playerTwoName, 
                playerOneElo,
                playerTwoElo,
                meColor,
                colorTurn,
                myId.id()
            );
        } else {
            startConnect4Game(
                playerTwoName, 
                playerOneName, 
                playerTwoElo,
                playerOneElo,
                meColor,
                colorTurn,
                myId.id()
            );
        }
    }

    private void handleTicTacToe(TicTacToeGame game){
        HashMap<UserID, TicTacToePiece> playerPieceMapping = game.getPlayerPieceMapping();
        Player[] players = game.getPlayers();
        this.players = players;
        
        String playerOneName = players[0].getUsername();
        String playerTwoName = players[1].getUsername();

        UserID playerOneId = players[0].getID();
        UserID playerTwoId = players[1].getID();

        int playerOneElo = players[0].getGameStats(game.getGameType()).getEloRating();
        int playerTwoElo = players[1].getGameStats(game.getGameType()).getEloRating();

        TicTacToePiece playerOnePiece = playerPieceMapping.get(playerOneId);
        if (playerOnePiece == TicTacToePiece.X) {
            startTTTGame(
                playerOneName, 
                playerTwoName, 
                playerOneId.id(),
                playerTwoId.id(),
                playerOneElo,
                playerTwoElo,
                myId.id()
            );
        } else {
            startTTTGame(
                playerTwoName, 
                playerOneName, 
                playerTwoId.id(), 
                playerOneId.id(),
                playerTwoElo,
                playerOneElo,
                myId.id()
            );
        }
    }

    private void setUpGameHandler(){
        gameHandler.setOnMove(move -> {
            Platform.runLater(() -> {
                GameMove moveData = move.move();
                MoveResult result = move.result();

                logger.info("Received move: " + moveData.toString() + ", result: " + result.isAccepted());
                if (moveData instanceof TicTacToeMove) {
                    logger.info("Handling Tic Tac Toe move");
                    handleTicTacToeMove((TicTacToeMove) moveData, result);
                } else if (moveData instanceof ConnectFourMove) {
                    logger.info("Handling Connect Four move");
                    handleConnectFourMove((ConnectFourMove) moveData, result);
                } else {
                    logger.warning("Unknown move type received: " + moveData.getClass().getName());
                }
            });
        });

        gameHandler.setOnState(state -> {
            Platform.runLater(() -> {
                GameAbstract<?> game = state.game();
                currentGameType = game.getGameType();
                if (game.getGameType() == GameType.TICTACTOE) {
                    handleTicTacToe((TicTacToeGame) game);
                    return;
                }
                if (game.getGameType() == GameType.CONNECTFOUR) {
                    handleConnectFour((ConnectFourGame) game);
                }
            });
        });

        gameHandler.setOnChat(chat -> {
            Platform.runLater(() -> {
                if (chat.userChat().equals(myId)) {
                    String command = String.format("onSuccessChat(%s);", js(chat.message()));
                    System.out.println("Executing command: " + command);
                    engine.executeScript(command);
                    return;
                }
                String username = null;
                for (Player player : players) {
                    if (player.getID().equals(chat.userChat())) {
                        username = player.getUsername();
                        break;
                    }
                }
                String command = String.format("receiveMessage(%s, %s);", js(username), js(chat.message()));
                System.out.println("Executing command: " + command);
                engine.executeScript(command);
            });
        });

        gameHandler.setOnError(err -> {
            Platform.runLater(() -> {
                String m = err.message();
                logger.warning("Game error: " + m);
                if ("Not in a game".equals(m)) {
                    return;
                }
                showError(m);
            });
        });

        gameHandler.setOnDrawOfferPending(r -> Platform.runLater(() -> {
            String command = String.format("onDrawOfferPending(%s, %s);",
                    js(r.from().id()), js(myId.id()));
            engine.executeScript(command);
        }));

        gameHandler.setOnDrawDeclined(r -> Platform.runLater(() -> {
            String command = String.format("onDrawDeclined(%s);", js(r.by().id()));
            engine.executeScript(command);
        }));
    }

    public void sendMessage(String message) {
        gameHandler.sendChat(message);
    }

    private void handleConnectFourMove(ConnectFourMove moveData, MoveResult result) {
        int row = moveData.getPos().row;
        int column = moveData.getPos().column;
        String color = moveData.getServerAssignedPiece().toString();

        if (row >= 0 && column >= 0) {
            String commandApply = String.format("applyMove(%d, %d, %s);", row, column, js(color));
            System.out.println("Executing command: " + commandApply);
            engine.executeScript(commandApply);
        }

        if (result.hasWinner()) {
            String winColor = color;
            if (result.getWinnerID() != null && connectFourColorByUserId.containsKey(result.getWinnerID())) {
                winColor = connectFourColorByUserId.get(result.getWinnerID());
            }
            String command = String.format("showWinner(%s)", js(winColor));
            System.out.println("Executing command: " + command);
            engine.executeScript(command);
            lastFinishedMatch = result;
            presentResultsScreen(result);
        } else if (result.isDraw()) {
            String command = "showDraw()";
            System.out.println("Executing command: " + command);
            engine.executeScript(command);
            lastFinishedMatch = result;
            presentResultsScreen(result);
        }
    }

    private void handleTicTacToeMove(TicTacToeMove moveData, MoveResult result) {
        int row = moveData.getPos().row;
        int col = moveData.getPos().column;

        if (row >= 0 && col >= 0) {
            int index = row * 3 + col;
            String commandApply = String.format("applyMove(%d);", index);
            System.out.println("Executing command: " + commandApply);
            engine.executeScript(commandApply);
        }

        if (result.hasWinner()) {
            UserID winnerId = result.getWinnerID();
            String winnerName = null;
            for (Player player : players) {
                if (player.getID().equals(winnerId)) {
                    winnerName = player.getUsername();
                    break;
                }
            }
            
            String command = String.format("onWinDetected(%s);", js(winnerName));
            System.out.println("Executing command: " + command);
            engine.executeScript(command);
            lastFinishedMatch = result;
            presentResultsScreen(result);
        } else if (result.isDraw()) {
            String command = "onDrawDetected()";
            System.out.println("Executing command: " + command);
            engine.executeScript(command);
            lastFinishedMatch = result;
            presentResultsScreen(result);
        }
    }

    public void showResultsScreen() {
        if (lastFinishedMatch != null) {
            presentResultsScreen(lastFinishedMatch);
        } else {
            navigateTo("results.html");
        }
    }

    private void presentResultsScreen(MoveResult result) {
        if (players == null || players.length < 2) {
            navigateTo("results.html");
            return;
        }
        String p1 = players[0].getUsername();
        String p2 = players[1].getUsername();
        String winnerName = "";
        if (result.hasWinner() && result.getWinnerID() != null) {
            for (Player pl : players) {
                if (pl.getID().equals(result.getWinnerID())) {
                    winnerName = pl.getUsername();
                    break;
                }
            }
        }
        EloPostGame elo = computePostGameElo(result);
        navigateTo("results.html", buildResultsQuery(winnerName, result.isDraw(), p1, p2, elo));
    }

    private EloPostGame computePostGameElo(MoveResult result) {
        if (currentGameType == null || players == null || players.length < 2) {
            return EloPostGame.empty();
        }
        GameType gt = currentGameType;
        Player p0 = players[0];
        Player p1 = players[1];
        int elo0 = p0.getGameStats(gt).getEloRating();
        int elo1 = p1.getGameStats(gt).getEloRating();

        if (result.isDraw()) {
            int[] n = EloCalculator.newRatingsAfterGame(elo0, elo1, false, true);
            return EloPostGame.from(p0.isBot(), p1.isBot(), n[0], n[1], elo0, elo1);
        }
        if (!result.hasWinner() || result.getWinnerID() == null) {
            return EloPostGame.empty();
        }
        if (result.getWinnerID().equals(p0.getID())) {
            int[] n = EloCalculator.newRatingsAfterGame(elo0, elo1, true, false);
            return EloPostGame.from(p0.isBot(), p1.isBot(), n[0], n[1], elo0, elo1);
        }
        int[] n = EloCalculator.newRatingsAfterGame(elo1, elo0, true, false);
        return EloPostGame.from(p0.isBot(), p1.isBot(), n[1], n[0], elo0, elo1);
    }

    private record EloPostGame(
            Integer newEloP1,
            Integer newEloP2,
            Integer deltaP1,
            Integer deltaP2
    ) {
        static EloPostGame empty() {
            return new EloPostGame(null, null, null, null);
        }

        static EloPostGame from(boolean bot0, boolean bot1, int new0, int new1, int old0, int old1) {
            return new EloPostGame(
                    bot0 ? null : new0,
                    bot1 ? null : new1,
                    bot0 ? null : (new0 - old0),
                    bot1 ? null : (new1 - old1)
            );
        }
    }

    private static String buildResultsQuery(String winnerName, boolean draw, String p1, String p2, EloPostGame elo) {
        StringBuilder sb = new StringBuilder();
        sb.append("draw=").append(draw);
        if (winnerName != null && !winnerName.isEmpty()) {
            sb.append("&winner=").append(URLEncoder.encode(winnerName, StandardCharsets.UTF_8));
        }
        sb.append("&p1=").append(URLEncoder.encode(p1, StandardCharsets.UTF_8));
        sb.append("&p2=").append(URLEncoder.encode(p2, StandardCharsets.UTF_8));
        appendEloQuery(sb, "elo1", "de1", elo.newEloP1(), elo.deltaP1());
        appendEloQuery(sb, "elo2", "de2", elo.newEloP2(), elo.deltaP2());
        return sb.toString();
    }

    private static void appendEloQuery(StringBuilder sb, String eloKey, String deltaKey, Integer newElo, Integer delta) {
        if (newElo == null || delta == null) {
            sb.append("&").append(eloKey).append("=na");
            sb.append("&").append(deltaKey).append("=na");
        } else {
            sb.append("&").append(eloKey).append("=").append(newElo);
            sb.append("&").append(deltaKey).append("=")
                    .append(URLEncoder.encode(formatEloDelta(delta), StandardCharsets.UTF_8));
        }
    }

    private static String formatEloDelta(int d) {
        if (d > 0) {
            return "+" + d;
        }
        return Integer.toString(d);
    }

    public void startConnect4Game(String playerRedUsername, String playerYellowUsername, int elo1, int elo2, String meColor, String colorTurn, String myUserId){
        Platform.runLater(() -> {
            String command = String.format("startGame(%s, %s, %d, %d, %s, %s, %s);",
                js(playerRedUsername),
                js(playerYellowUsername), elo1, elo2,
                js(meColor), js(colorTurn), js(myUserId)
            );

            System.out.println("Executing command: " + command);
            engine.executeScript(command);
        });
    }

    public void startTTTGame(
        String usernameX, 
        String usernameO, 
        String idX, 
        String idO,
        int eloX,
        int eloO,
        String myId
    ) {
        Platform.runLater(() -> {
            String command = String.format("startGame(%s, %s, %s, %s, %d, %d, %s);",
                js(usernameX), js(usernameO), js(idX), js(idO), eloX, eloO, js(myId)
            );

            System.out.println("Executing command: " + command);
            engine.executeScript(command);
        });
    }

    public void connect4DropInColumn(int column) {
        try {
            GameMove move = new GameMove(
                new GridSpace(0, column)
            );
            gameHandler.playMove(move);
        } catch (Exception e) {
            e.printStackTrace();
            showError("Move failed.");
        }
    }

    public void ticTacToePlace(int row, int col) {
        try {
            GameMove move = new GameMove(
                new GridSpace(row, col)
            );
            logger.info("Playing move at row " + row + ", column " + col);
            gameHandler.playMove(move);
        } catch (Exception e) {
            e.printStackTrace();
            showError("Move failed.");
        }
    }

    public void resign() {
        try {
            gameHandler.resign();
        } catch (Exception e) {
            e.printStackTrace();
            showError("Resign failed.");
        }
    }

    public void offerDraw() {
        try {
            gameHandler.offerDraw();
        } catch (Exception e) {
            e.printStackTrace();
            showError("Could not offer draw.");
        }
    }

    public void respondDraw(boolean accept) {
        try {
            gameHandler.respondDraw(accept);
        } catch (Exception e) {
            e.printStackTrace();
            showError("Could not respond to draw.");
        }
    }

    @Deprecated
    public void quitGame() {
        resign();
    }

    private void showError(String message) {
        Platform.runLater(() ->
            engine.executeScript("showError(" + js(message) + ");")
        );
    }

    private String js(String value) {
        if (value == null) {
            return "null";
        }
        return "'" + value
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\n", "\\n")
                .replace("\r", "") + "'";
    }
}
