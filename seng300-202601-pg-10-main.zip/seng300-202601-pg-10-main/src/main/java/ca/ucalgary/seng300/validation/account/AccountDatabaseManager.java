package ca.ucalgary.seng300.validation.account;

import ca.ucalgary.seng300.validation.account.enums.AccountErrorCode;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.account.results.AccountCreationResult;
import ca.ucalgary.seng300.validation.account.results.OperationResult;
import ca.ucalgary.seng300.validation.account.results.ValidationResult;
import ca.ucalgary.seng300.validation.account.stubs.*;

import java.io.Serializable;
import java.util.UUID;

public class AccountDatabaseManager implements Serializable {
    private static final long serialVersionUID = 1L;
    private CredentialsStoreStub credentialsStore;
    private TokenManager tokenStore;
    private AccountValidation validation;

    public AccountDatabaseManager(AccountValidation validation) {
        this.validation = validation;
        this.credentialsStore = validation.getCredentialsStore();
        this.tokenStore = validation.getTokenStore();
    }

    public UserCredentials getUserCredentials(String username) {
        return credentialsStore.getCredentials(username);
    }

    public CredentialsStoreStub getCredentialsStore() {
        return credentialsStore;
    }

    public TokenManager getTokenManager() {
        return tokenStore;
    }

    public AccountValidation getAccountValidation() {
        return validation;
    }

    
    public SessionToken getSessionToken(UserID userId) {
        SessionToken token = tokenStore.getToken(userId);
        ValidationResult result = validation.validateToken(token);
        if (!result.isValid) {
            SessionToken newToken = validation.generateSessionToken(userId);
            tokenStore.writeToken(userId, newToken);
            return newToken;
        }
        return tokenStore.getToken(userId);
    }

    public AccountCreationResult createAccount(String username, String password) {
        ValidationResult vr = validation.validateRegistration(username, password);
        if (!vr.isValid) {
            return AccountCreationResult.failure(vr.errorCode, vr.message);
        }
        String userID = UUID.randomUUID().toString();
        UserID uid = new UserID(userID);
        UserProfile profile = new UserProfile(uid, username); // here i fixed lowercase u for userprofile.
        String hashedPassword = credentialsStore.hashPassword(password);
        UserCredentials credentials = new UserCredentials(profile, hashedPassword);

        boolean credsSaved = credentialsStore.saveCredentials(credentials);
        if (!credsSaved) {
            return AccountCreationResult.failure(AccountErrorCode.SESSION_NOT_FOUND, "Database error!");
        }

        SessionToken token = validation.generateSessionToken(uid);
        tokenStore.writeToken(uid, token);

        return AccountCreationResult.success(userID, token, profile);

    }

    public OperationResult updateUsername(String username, String password, String newUsername) {
        ValidationResult vr = validation.validateProfileEditUsername(username, password, newUsername);
        if (!vr.isValid) {
            return AccountCreationResult.failure(vr.errorCode, vr.message);
        }
        UserCredentials credentials = validation.getUserCredentials(username);
        UserCredentials updatedCreds = new UserCredentials(
                new UserProfile(credentials.profile.userID, newUsername),
                credentials.hashedPassword
        );
        credentialsStore.deleteCredentials(username);
        credentialsStore.saveCredentials(updatedCreds);
        return OperationResult.success();
    }

    public OperationResult updatePassword(String username, String oldPassword, String newPassword) {
        ValidationResult vr = validation.validateProfileEditPassword(username, oldPassword, newPassword);
        if (!vr.isValid) {
            return OperationResult.failure(vr.message, vr.errorCode);
        }

        UserCredentials credentials = validation.getUserCredentials(username);
        String newHashedPassword = AccountValidation.hashPassword(newPassword);
        UserCredentials updatedCreds = new UserCredentials(
                credentials.profile,
                newHashedPassword
        );
        credentialsStore.updatePassword(username, newHashedPassword);
        return OperationResult.success();
    }

    public OperationResult deleteAccount(String username, String password) {
        UserCredentials credentials = validation.getUserCredentials(username);
        if (credentials == null) {
            return OperationResult.failure("User not found", AccountErrorCode.USER_NOT_FOUND);
        }
        if (password == null || !AccountValidation.hashPassword(password).equals(credentials.hashedPassword)) {
            return OperationResult.failure("Wrong password", AccountErrorCode.INVALID_CREDENTIALS);
        }

        UserProfile profile = credentials.profile;
        UserID userId = profile.userID;
            
        credentialsStore.deleteCredentials(username);
        tokenStore.removeToken(userId);
        return OperationResult.success();
    }
}
