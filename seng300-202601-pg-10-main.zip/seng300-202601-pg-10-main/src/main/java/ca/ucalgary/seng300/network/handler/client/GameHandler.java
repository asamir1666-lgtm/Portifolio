package ca.ucalgary.seng300.network.handler.client;

import java.util.Objects;
import java.util.function.Consumer;

import ca.ucalgary.seng300.network.message.Payload.Compound;
import ca.ucalgary.seng300.network.message.Payload.Game.Req;
import ca.ucalgary.seng300.network.message.Payload.Game.Res;
import ca.ucalgary.seng300.platformcore.game.GameMove;

public class GameHandler extends ClientHandler<Res>{
    private Consumer<Res.State>     onState;
    private Consumer<Res.Move>      onMove;
    private Consumer<Res.Error>     onError;
    private Consumer<Res.Chat>      onChat;
    private Consumer<Res.DrawOfferPending> onDrawOfferPending;
    private Consumer<Res.DrawDeclined> onDrawDeclined;

    public void setOnState      (Consumer<Res.State> cb)        { this.onState = cb; }
    public void setOnMove       (Consumer<Res.Move> cb)         { this.onMove = cb; }
    public void setOnError      (Consumer<Res.Error> cb)        { this.onError = cb; }
    public void setOnChat       (Consumer<Res.Chat> cb)         { this.onChat = cb; }
    public void setOnDrawOfferPending(Consumer<Res.DrawOfferPending> cb) { this.onDrawOfferPending = cb; }
    public void setOnDrawDeclined(Consumer<Res.DrawDeclined> cb) { this.onDrawDeclined = cb; }
    
	@Override
	public void handle(Res serverResponse) {
		switch (serverResponse) {
            case Compound c -> throw new IllegalStateException(
                    "Client received Compound; server should unpack and send responses individually");
		    case Res.State r    -> onState.accept(r);
            case Res.Move r     -> onMove.accept(r);
            case Res.Chat r     -> onChat.accept(r);
            case Res.DrawOfferPending r -> onDrawOfferPending.accept(r);
            case Res.DrawDeclined r -> onDrawDeclined.accept(r);
            case Res.Error e    -> onError.accept(e);
        }
    }

    public void playMove(GameMove move) {
        this.sender.accept(new Req.Move(move));
    }

    public void requestState() {
        this.sender.accept(new Req.State());
    }

    public void sendChat(String message) {
        this.sender.accept(new Req.Chat(message));
    }

    public void resign() {
        this.sender.accept(new Req.Resign());
    }

    public void offerDraw() {
        this.sender.accept(new Req.DrawOffer());
    }

    public void respondDraw(boolean accept) {
        this.sender.accept(new Req.DrawRespond(accept));
    }

	@Override
	public void validate() {
	    Objects.requireNonNull(onMove,      "Move callback must be set");
	    Objects.requireNonNull(onChat,      "Chat callback must be set");
        Objects.requireNonNull(onState,     "State callback must be set");
	    Objects.requireNonNull(onError,     "Error callback must be set");
        Objects.requireNonNull(onDrawOfferPending, "Draw-offer callback must be set");
        Objects.requireNonNull(onDrawDeclined, "Draw-declined callback must be set");
	}
}

