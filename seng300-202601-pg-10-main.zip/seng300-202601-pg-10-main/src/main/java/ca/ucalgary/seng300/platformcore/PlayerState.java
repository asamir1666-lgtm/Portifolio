package ca.ucalgary.seng300.platformcore;

public enum PlayerState {
    DASHBOARD,
    IN_LOBBY,
    READY_FOR_MATCH,
    IN_GAME,
    POST_GAME
}

