package ca.ucalgary.seng300.platformcore;

public enum GameType {
  TICTACTOE,
  CONNECTFOUR
}
