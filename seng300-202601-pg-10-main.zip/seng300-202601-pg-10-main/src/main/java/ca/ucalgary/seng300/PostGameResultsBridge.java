package ca.ucalgary.seng300;

import ca.ucalgary.seng300.network.Client;
import ca.ucalgary.seng300.network.handler.client.LobbyHandler;
import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;

public class PostGameResultsBridge extends BridgeBase {
    private final LobbyHandler lobbyHandler;
    private final LobbyBridge lobbyBridge;

    public PostGameResultsBridge(WebEngine engine, Client client) {
        this(engine, client, null);
    }

    public PostGameResultsBridge(WebEngine engine, Client client, LobbyBridge lobbyBridge) {
        super(engine);
        this.lobbyBridge = lobbyBridge;
        if (client != null) {
            this.lobbyHandler = client.router.getHandler(LobbyHandler.class);
            setUpHandlers();
        } else {
            this.lobbyHandler = null;
        }
    }

    public void attachBridge() {
        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.SUCCEEDED) {
                JSObject window = (JSObject) engine.executeScript("window");
                window.setMember("pgrBridge", this);
            }
        });
    }

    private void setUpHandlers() {
        lobbyHandler.setOnRematchVote(res -> {
            String pid = res.player().id().replace("\\", "\\\\").replace("'", "\\'");
            Platform.runLater(() ->
                    engine.executeScript(
                            "if(typeof onRematchVote==='function')onRematchVote('" + pid + "')")
            );
        });

        lobbyHandler.setOnAllReady(res -> {
            Platform.runLater(() ->
                    engine.executeScript("if(typeof onAllReady==='function')onAllReady()"));
        });

        lobbyHandler.setOnReturnedLobby(res -> {
            Platform.runLater(() -> {
                if (lobbyBridge != null) {
                    lobbyBridge.scheduleWaitingRoomPopulateFromLobby(res.lobby());
                }
                navigateTo("waitingRoom.html");
            });
        });
    }

    public void rematch() {
        if (lobbyHandler == null) {
            return;
        }
        lobbyHandler.requestRematch();
    }

    public void returnToLobby() {
        if (lobbyHandler == null) {
            return;
        }
        lobbyHandler.returnToLobby();
    }

    public void returnToDashboard() {
        if (lobbyHandler == null) {
            return;
        }
        lobbyHandler.returnToDashboard();
        Platform.runLater(() -> navigateTo("dashboard.html"));
    }
}
