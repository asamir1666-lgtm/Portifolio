package ca.ucalgary.seng300.network.handler.server;

import ca.ucalgary.seng300.platformcore.LobbyID;
import ca.ucalgary.seng300.network.message.Payload.Direct;
import ca.ucalgary.seng300.network.message.Payload.Lobby.Res;
import ca.ucalgary.seng300.network.message.Payload.Lobby.Req;
import ca.ucalgary.seng300.platformcore.Bot;
import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.LobbyRoom;
import ca.ucalgary.seng300.platformcore.LobbyJoinResponse;
import ca.ucalgary.seng300.platformcore.LobbyManager;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.platformcore.RandomUserID;
import ca.ucalgary.seng300.Config;
import ca.ucalgary.seng300.database.LobbyDatabase;
import ca.ucalgary.seng300.network.ClientData;
import ca.ucalgary.seng300.network.message.Payload.Compound;
import ca.ucalgary.seng300.network.message.Payload.Error;
import ca.ucalgary.seng300.network.message.Payload.Response;
import ca.ucalgary.seng300.platformcore.LobbyState;
import ca.ucalgary.seng300.platformcore.PlayerState;

import java.util.ArrayList;
import java.util.List;

public class LobbyHandler extends ServerHandler<Req, Res> {
    private final LobbyDatabase lobbyDatabase;

    public LobbyHandler(LobbyDatabase lobbyDatabase) {
        this.lobbyDatabase = lobbyDatabase;
    }

    @Override
    public Res handle(Req req, ClientData clientData) {
        return switch (req) {
            case Req.Join r            -> joinLobbyHandler(r, clientData);
            case Req.List r            -> listLobbiesHandler(r);
            case Req.Create r          -> createLobbyHandler(r, clientData);
            case Req.Leave r           -> leaveLobbyHandler(r, clientData);
            case Req.Start r           -> startLobbyHandler(r, clientData);
            case Req.Rematch r         -> rematchHandler(r, clientData);
            case Req.ReturnLobby r     -> returnLobbyHandler(r, clientData);
            case Req.ReturnDashboard r -> returnDashboardHandler(r, clientData);
            case Req.AddBot r          -> addBotHandler(r, clientData);
            case Req.SetReady r        -> setReadyHandler(r, clientData);
        };
    }

    private Res setReadyHandler(Req.SetReady setReady, ClientData clientData) {
        Player connected = clientData.getPlayer();
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby = null;
        if (connected.getLobbyId() != null) {
            lobby = manager.getLobbyOrNull(connected.getLobbyId());
        }
        if (lobby == null) {
            lobby = manager.getLobbyContainingPlayer(connected.getID());
        }
        if (lobby == null) {
            return new Error("Player is not in a lobby");
        }
        Player player = lobby.getPlayer(connected.getID());
        if (player == null) {
            return new Error("Player is not in a lobby");
        }
        if (player != connected) {
            clientData.setPlayer(player);
        }
        if (lobby.getState() != LobbyState.WAITING_FOR_PLAYERS) {
            return new Error("Cannot change ready state now");
        }
        if (player.isBot()) {
            return new Error("Invalid ready request");
        }

        if (setReady.ready()) {
            if (player.getState() == PlayerState.IN_LOBBY) {
                player.readyForMatch();
            }
        } else {
            if (player.getState() == PlayerState.READY_FOR_MATCH) {
                player.cancelReady();
            }
        }

        lobbyDatabase.save();
        boolean nowReady = player.isReadyForMatch();
        return new Res.PlayerReady(player.getID(), nowReady);
    }

    private Res joinLobbyHandler(Req.Join join, ClientData clientData) {
        LobbyManager lobbyManager = lobbyDatabase.getData();
        Player player = clientData.getPlayer();

        LobbyID lobbyID = join.lobbyId();
        String joinCode = join.joinCode();

        LobbyJoinResponse res = lobbyManager.joinLobby(player, lobbyID, joinCode);
        LobbyRoom lobby = null;
        if (lobbyID != null) {
            lobby = lobbyManager.getLobby(lobbyID);
        } else {
            lobby = lobbyManager.getLobbyByJoinCode(joinCode);
        }
        if (res.success) {
            lobbyDatabase.save();
            return new Res.Join(player.getID(), lobby, res);
        }
        return new Error(res.message);
    }

    private Res.Create createLobbyHandler(Req.Create create, ClientData clientData) {
        GameType gameType           = create.gameType();
        
        LobbyManager lobbyManager   = lobbyDatabase.getData();
        LobbyRoom newLobby              = lobbyManager.newLobby(gameType, Config.DEFAULT_MAX_CAPACITY_LOBBY);
        Player player               = clientData.getPlayer();

        newLobby.setPublicity(create.isPublic());
        newLobby.addHost(player);
        lobbyManager.addLobby(newLobby);
        
        lobbyDatabase.save();
        return new Res.Create(newLobby);
    }

    private Res.List listLobbiesHandler(Req.List list) {
        LobbyManager lobbyManager = lobbyDatabase.getData();

        LobbyRoom[] lobbyRooms = lobbyManager.getLobbies().stream()
                .filter(lobby -> lobby.getState() == LobbyState.WAITING_FOR_PLAYERS)
                .filter(LobbyRoom::isPublic)
                .toArray(LobbyRoom[]::new);

        return new Res.List(lobbyRooms);
    }

    private Res leaveLobbyHandler(Req.Leave leave, ClientData clientData) {
        Player connected = clientData.getPlayer();
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby = null;
        if (connected.getLobbyId() != null) {
            lobby = manager.getLobbyOrNull(connected.getLobbyId());
        }
        if (lobby == null) {
            lobby = manager.getLobbyContainingPlayer(connected.getID());
        }
        if (lobby == null) {
            return new Error("Player is not in a lobby");
        }
        Player player = lobby.getPlayer(connected.getID());
        if (player == null) {
            return new Error("Player is not in a lobby");
        }
        if (player != connected) {
            clientData.setPlayer(player);
        }
        lobby.removePlayer(player);

        if (removeLobbyIfVacant(manager, lobby)) {
            lobbyDatabase.save();
            return new Res.Leave();
        }
        lobbyDatabase.save();
        return new Compound(new Response[] {
                new Res.Leave(),
                new Res.LobbyUpdated(lobby)
        });
    }

    /**
     * Removes the lobby if it has no players, or only bots (no human can start or continue a match).
     */
    private boolean removeLobbyIfVacant(LobbyManager manager, LobbyRoom lobby) {
        if (lobby.getPlayers().isEmpty()) {
            manager.removeLobby(lobby);
            return true;
        }
        for (Player p : lobby.getPlayers()) {
            if (!p.isBot()) {
                return false;
            }
        }
        lobby.dissolveAllPlayers();
        manager.removeLobby(lobby);
        return true;
    }

    private Res startLobbyHandler(Req.Start start, ClientData clientData) {
        Player player = clientData.getPlayer();
        LobbyManager lobbyManager = lobbyDatabase.getData();
        LobbyRoom lobby = lobbyManager.getLobby(player.getLobbyId());

        if (lobby == null) {
            return new Error("Player is not in a lobby");
        }
        if (!lobby.hostStart(player.getID())) {
            return new Error("Failed to start lobby. Ensure you are the host and all players are ready. (at least 2 players in the lobby)");
        }

        lobbyDatabase.save();
        return new Res.Start();
    }

    private Res rematchHandler(Req.Rematch rematch, ClientData clientData) {
        Player player = clientData.getPlayer();
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby = manager.getLobby(player.getLobbyId());

        lobby.requestRematch(player);
        lobbyDatabase.save();

        if (lobby.getState() == LobbyState.GAME_OVER
                && lobby.getReadyPlayers() == lobby.getPlayers().size()) {
            return new Res.AllReady();
        }

        return new Res.RematchVote(player.getID());
    }

    private Res returnLobbyHandler(Req.ReturnLobby ret, ClientData clientData) {
        Player player = clientData.getPlayer();
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby = manager.getLobbyOrNull(player.getLobbyId());
        if (lobby == null) {
            return new Error("Player is not in a lobby");
        }

        lobby.returnLobby(player);
        lobbyDatabase.save();
        return new Compound(new Response[] {
                new Res.LobbyUpdated(lobby),
                new Res.ReturnedLobby(lobby)
        });
    }

    private Res returnDashboardHandler(Req.ReturnDashboard dashboard, ClientData clientData) {
        Player connected = clientData.getPlayer();
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby = null;
        if (connected.getLobbyId() != null) {
            lobby = manager.getLobbyOrNull(connected.getLobbyId());
        }
        if (lobby == null) {
            lobby = manager.getLobbyContainingPlayer(connected.getID());
        }
        if (lobby == null) {
            return new Res.ReturnedDashboard();
        }
        Player player = lobby.getPlayer(connected.getID());
        if (player == null) {
            return new Res.ReturnedDashboard();
        }
        if (player != connected) {
            clientData.setPlayer(player);
        }

        lobby.returnDashboard(player);
        if (removeLobbyIfVacant(manager, lobby)) {
            lobbyDatabase.save();
            return new Res.ReturnedDashboard();
        }
        lobbyDatabase.save();
        return new Compound(new Response[] {
                new Res.LobbyUpdated(lobby),
                new Res.ReturnedDashboard()
        });
    }

    private Res addBotHandler(Req.AddBot addBot, ClientData clientData) {
        Player player = clientData.getPlayer();
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby = manager.getLobby(player.getLobbyId());

        if (lobby == null) {
            return new Error("Player is not in a lobby");
        }
        if (lobby.getRemainingSpots() <= 0) {
            return new Error("Lobby is full");
        }
        int d = addBot.difficulty();
        d = Math.max(0, Math.min(d, 10));
        Bot bot = new Bot();
        bot.setDifficulty(d);
        String joinCode = lobby.getJoinCode();
        LobbyJoinResponse res = lobby.admitPlayer(bot, joinCode);

        lobbyDatabase.save();

        return new Res.Join(bot.getID(), lobby, res);
    }

    public List<Response> handleDisconnect(Player player) {
        if (player == null) {
            return List.of();
        }

        LobbyID lobbyId = player.getLobbyId();
        LobbyManager mgr = lobbyDatabase.getData();

        boolean wasInGame = false;
        List<Player> peersToNotify = new ArrayList<>();

        if (lobbyId != null) {
            LobbyRoom lobby = mgr.getLobbyOrNull(lobbyId);
            if (lobby != null) {
                wasInGame = lobby.getState() == LobbyState.IN_GAME;
                for (Player p : lobby.getPlayers()) {
                    if (!p.equals(player) && !p.isBot()) {
                        peersToNotify.add(p);
                    }
                }
            }
        }

        mgr.handlePlayerDisconnected(player);
        boolean dissolved = lobbyId != null && mgr.getLobbyOrNull(lobbyId) == null;
        lobbyDatabase.save();

        List<Response> notifications = new ArrayList<>();
        if (!peersToNotify.isEmpty()) {
            Res.PlayerDisconnected msg = new Res.PlayerDisconnected(
                    player.getID(), dissolved || wasInGame);
            for (Player peer : peersToNotify) {
                notifications.add(new Direct(peer.getID(), msg));
            }
        }
        return notifications;
    }
}
