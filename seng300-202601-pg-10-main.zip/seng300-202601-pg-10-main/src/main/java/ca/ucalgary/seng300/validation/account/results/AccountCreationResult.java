package ca.ucalgary.seng300.validation.account.results;

import ca.ucalgary.seng300.validation.account.enums.AccountErrorCode;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;
import ca.ucalgary.seng300.validation.account.stubs.UserProfile;

public class AccountCreationResult extends OperationResult {
    public SessionToken token;
    public UserProfile userProfile;
    public String userID;

    private AccountCreationResult(boolean success, String message, AccountErrorCode errorCode, String userID, SessionToken token, UserProfile userProfile) {
        super(success, message, errorCode);
        this.userID = userID;
        this.token = token;
        this.userProfile = userProfile;
    }

    // its called on happy path: AccountCreationResult.success(token,profile)
    public static AccountCreationResult success(String userID, SessionToken token, UserProfile userProfile) {
        return new AccountCreationResult(true, "Account created successfully.", null, userID, token, userProfile);
    }

    // its called on failure: AccountCreationResult.failure(errorCode,message)
    public static AccountCreationResult failure(AccountErrorCode errorCode, String message) {
        return new AccountCreationResult(false, message, errorCode, null, null, null);
    }
}
