package ca.ucalgary.seng300.validation.account.records;

import java.io.Serializable;

public record UserID(String id) implements Serializable {
    private static final long serialVersionUID = 1L;}
