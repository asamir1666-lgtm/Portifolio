package ca.ucalgary.seng300;
import ca.ucalgary.seng300.database.SessionAccounts;
import ca.ucalgary.seng300.database.SessionStore;

import ca.ucalgary.seng300.network.Client;
import ca.ucalgary.seng300.network.handler.client.AuthHandler;
import ca.ucalgary.seng300.network.handler.client.LobbyHandler;
import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.LobbyID;
import ca.ucalgary.seng300.platformcore.MatchHistoryEntry;
import ca.ucalgary.seng300.platformcore.LobbyRoom;
import ca.ucalgary.seng300.platformcore.Bot;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;

import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;

import ca.ucalgary.seng300.network.handler.client.ProfileHandler;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class LobbyBridge extends BridgeBase {
    private AuthHandler authHandler;
    private LobbyHandler lobbyHandler;
    private SessionStore sessionDb;
    private ProfileHandler profileHandler;
    private GameBridge gameBridge;
    private final AccountBridge accountBridge;
    private final Bridge appBridge;

    private UserID id;
    private String gameType;
    private String username;
    private String pendingAuthUsername;
    private LobbyRoom pendingWaitingRoom;

    public LobbyBridge(WebEngine engine, Client client, SessionStore sessionDb, GameBridge gameBridge,
            AccountBridge accountBridge, Bridge appBridge) {
        super(engine);
        this.authHandler = client.router.getHandler(AuthHandler.class);
        this.lobbyHandler = client.router.getHandler(LobbyHandler.class);
        this.sessionDb = sessionDb;
        this.profileHandler = client.router.getHandler(ProfileHandler.class);
        this.appBridge = appBridge;
        SessionAccounts acc = sessionDb.getData();
        SessionToken t = acc.getActiveToken();
        if (t == null && acc.size() == 1) {
            t = acc.getOnlyToken();
        }
        this.id = t != null && t.userID != null ? t.userID : new UserID("");
        this.gameBridge = gameBridge;
        this.accountBridge = accountBridge;
        if (id != null && id.id() != null && !id.id().isEmpty()) {
            String u = acc.displayName(id.id());
            if (u != null && !u.isBlank()) {
                this.username = u;
            }
        }
        setUpHandlers();
    }

    private void navigateToAccountsWithBridge() {
        accountBridge.setBridgeHooks(appBridge, this);
        ChangeListener<Worker.State> listener = new ChangeListener<>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> obs, Worker.State o, Worker.State n) {
                if (n == Worker.State.SUCCEEDED) {
                    JSObject window = (JSObject) engine.executeScript("window");
                    window.setMember("accountBridge", accountBridge);
                    window.setMember("javaApp", appBridge);
                    window.setMember("javaLobby", LobbyBridge.this);
                    engine.executeScript("if(typeof refreshAccountList==='function') refreshAccountList()");
                    engine.getLoadWorker().stateProperty().removeListener(this);
                }
            }
        };
        engine.getLoadWorker().stateProperty().addListener(listener);
        navigateTo("accounts.html");
    }

    public void attachBridge() {
        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.SUCCEEDED) {
                JSObject window = (JSObject) engine.executeScript("window");
                window.setMember("javaLobby", this);
            }
        });
    }

    public void setUpHandlers() {
        setUpAuth();
        setUpLobby();
        setUpProfile();
    }

    public void setUpLobby(){
        lobbyHandler.setOnCreate(res -> {
            Platform.runLater(() -> {
                LobbyRoom room = res.lobby();
                String joinCode = room.getJoinCode();
                gameType = room.getGameType().toString();

                engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
                    if (newState == Worker.State.SUCCEEDED) {
                        String readyArr = buildReadyStatesJsArray(room.getPlayers());
                        String command = String.format("setUpGame('%s', '%s','%s','%s',[%s], '%s', %s, '%s')",
                                escapeJs(username), escapeJs(joinCode), escapeJs(gameType),
                                escapeJs(room.getID().id()),
                                buildPlayerRowJs(room.getPlayers().get(0)),
                                escapeJs(room.getHostID().id()),
                                readyArr, escapeJs(id.id()));
                        System.out.println("Executing script: " + command);
                        engine.executeScript(command);
                        engine.executeScript("if(typeof setAsHost==='function')setAsHost()");
                    }
                });

                handleNavigation("WAITINGROOM");
            });
        });

        lobbyHandler.setOnJoin(res -> {
            Platform.runLater(() -> {
                UserID playerJoined = res.playerJoin();
                LobbyRoom room = res.lobby();
                if (playerJoined.equals(id)) {
                    applyJoinLobbyRoom(room);
                } else {
                    String joinCode = room.getJoinCode();
                    gameType = room.getGameType().toString();
                    String playersJson = buildPlayersJsArray(room.getPlayers());

                    String hostId = room.getHostID().id();
                    String readyArr = buildReadyStatesJsArray(room.getPlayers());
                    String command = String.format(
                            "if(typeof updatePlayerList==='function'){updatePlayerList('%s', %s, '%s', %s, '%s', '%s', '%s');}",
                            escapeJs(username), playersJson, escapeJs(hostId), readyArr, escapeJs(id.id()),
                            escapeJs(room.getID().id()), escapeJs(room.getJoinCode()));
                    System.out.println("Executing script: " + command);
                    engine.executeScript(command);
                }
            });
        });

        lobbyHandler.setOnStart(res -> {
            Platform.runLater(() -> {
                ChangeListener<Worker.State> gamePageListener = new ChangeListener<>() {
                    @Override
                    public void changed(ObservableValue<? extends Worker.State> obs, Worker.State o, Worker.State n) {
                        if (n == Worker.State.SUCCEEDED) {
                            gameBridge.setMyId(id);
                            gameBridge.onStart();
                            engine.getLoadWorker().stateProperty().removeListener(this);
                        }
                    }
                };
                engine.getLoadWorker().stateProperty().addListener(gamePageListener);
                handleNavigation(gameType);
            });
        });

        lobbyHandler.setOnLeave(res -> {});
        lobbyHandler.setOnList(res -> {
            Platform.runLater(() -> {
                engine.executeScript(
                        "if(typeof setLobbies==='function')setLobbies(" + convertRoomsToJsArray(res.lobbies()) + ");");
            });
        });

        lobbyHandler.setOnError(err -> {
            Platform.runLater(() -> {
                String msg = escapeJs(err.message());
                engine.executeScript(
                        "if(typeof onLobbyError==='function')onLobbyError('" + msg + "')");
            });
        });
        lobbyHandler.setOnRematchVote(res -> {});
        lobbyHandler.setOnAllReady(res -> {});
        lobbyHandler.setOnLobbyUpdated(res -> {
            Platform.runLater(() -> {
                LobbyRoom room = res.lobby();
                pendingWaitingRoom = room;
                if (room.getPlayers().isEmpty()) {
                    return;
                }
                gameType = room.getGameType().toString();
                syncWaitingRoomFromLobby(room);
            });
        });
        lobbyHandler.setOnReturnedLobby(res -> {});
        lobbyHandler.setOnReturnedDashboard(res -> {});
        lobbyHandler.setOnPlayerReady(res -> {
            Platform.runLater(() ->
                    engine.executeScript(String.format(
                            "if(typeof onPlayerReady==='function')onPlayerReady('%s', %s)",
                            escapeJs(res.playerId().id()),
                            res.ready()))
            );
        });

        lobbyHandler.setOnPlayerDisconnected(res -> {
            Platform.runLater(() -> {
                String uid = escapeJs(res.disconnectedPlayer().id());
                if (res.lobbyDissolved()) {
                    engine.executeScript(
                            "if(typeof onOpponentDisconnected==='function') onOpponentDisconnected('" + uid + "')");
                    handleNavigation("DASHBOARD");
                } else {
                    engine.executeScript(
                            "if(typeof onPlayerLeft==='function') onPlayerLeft('" + uid + "')");
                }
            });
        });
    }

    private void applyJoinLobbyRoom(LobbyRoom room) {
        String joinCode = room.getJoinCode();
        gameType = room.getGameType().toString();
        String playersJson = buildPlayersJsArray(room.getPlayers());

        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.SUCCEEDED) {
                String hostId = room.getHostID().id();
                String readyArr = buildReadyStatesJsArray(room.getPlayers());
                String command = String.format("setUpGame('%s', '%s','%s','%s',%s, '%s', %s, '%s')",
                        escapeJs(username),
                        escapeJs(joinCode), escapeJs(gameType), escapeJs(room.getID().id()),
                        playersJson, escapeJs(hostId),
                        readyArr, escapeJs(id.id()));

                System.out.println("Executing script: " + command);
                engine.executeScript(command);
            }
        });
        handleNavigation("WAITINGROOM");
    }

    /** Matchmaking already placed both players server-side; only navigates and sets up UI. */
    public void enterLobbyFromMatchmaking(LobbyRoom room) {
        applyJoinLobbyRoom(room);
    }

    public void onCreateLobby(String selectedGame, boolean isPublic) {
        GameType type = selectedGame.equals("Tic Tac Toe") ? GameType.TICTACTOE : GameType.CONNECTFOUR;
        lobbyHandler.createLobby(type, isPublic);
    }

    public void onLobbyJoin(String joinCode) {
        lobbyHandler.joinLobby(null, joinCode);
    }

    public void setUpAuth() {
        authHandler.setOnSignup(res -> {
            Platform.runLater(() -> {
                engine.executeScript("if(typeof onSignupSuccess==='function')onSignupSuccess()");
            });
        });

        authHandler.setOnLogin(res -> {
            Platform.runLater(() -> {
                UserID userId = res.id();
                this.id = userId;
                SessionAccounts acc = sessionDb.getData();
                acc.addOrUpdate(userId, res.token(), pendingAuthUsername);
                this.username = sessionDb.getData().displayName(userId.id());
                pendingAuthUsername = null;
                sessionDb.save();
                handleNavigation("DASHBOARD");
            });
        });

        authHandler.setOnError(err -> {
            Platform.runLater(() -> {
                String msg = escapeJs(err.message());
                engine.executeScript(
                        "if(typeof onAuthFail==='function')onAuthFail('" + msg + "')");
            });
        });
    }
    public void setUpProfile() {
        profileHandler.setOnGetProfile((res) -> {
            Platform.runLater(() -> {
                String u = res.profile().username;
                this.username = u;
                String e = escapeJs(u);
                engine.executeScript("if(typeof updateDashboardUI==='function') updateDashboardUI('" + e + "')");
                engine.executeScript("if(typeof updateViewProfileUsername==='function') updateViewProfileUsername('" + e + "')");
                engine.executeScript("if(typeof updateLobbyUI==='function') updateLobbyUI('" + e + "')");
            });
        });

        profileHandler.setOnGetStats((res) -> {
            System.out.println("inside set on get stats");
            int tttWins = res.stat().getStatsForGame(GameType.TICTACTOE).getWins();
            int tttLosses = res.stat().getStatsForGame(GameType.TICTACTOE).getLosses();
            int tttDraws = res.stat().getStatsForGame(GameType.TICTACTOE).getDraws();
            int tttELO = res.stat().getStatsForGame(GameType.TICTACTOE).getEloRating();
            int tttTotalGames = res.stat().getStatsForGame(GameType.TICTACTOE).getTotalGames();
            double tttWinRate = res.stat().getStatsForGame(GameType.TICTACTOE).getWinRate();

            int c4Wins = res.stat().getStatsForGame(GameType.CONNECTFOUR).getWins();
            int c4Losses = res.stat().getStatsForGame(GameType.CONNECTFOUR).getLosses();
            int c4Draws = res.stat().getStatsForGame(GameType.CONNECTFOUR).getDraws();
            int c4ELO = res.stat().getStatsForGame(GameType.CONNECTFOUR).getEloRating();
            int c4TotalGames = res.stat().getStatsForGame(GameType.CONNECTFOUR).getTotalGames();
            double c4WinRate = res.stat().getStatsForGame(GameType.CONNECTFOUR).getWinRate();

            int wins = tttWins + c4Wins;
            int losses = tttLosses + c4Losses;
            // "Total" hero ELO is the simple mean of the two per-game ratings (not win-weighted).
            // Match history lines are per-game; compare TTT history to the Tic Tac Toe tab, not this average.
            int ELO = (tttELO + c4ELO) / 2;
            int totalGames = tttTotalGames + c4TotalGames;
            int draws = tttDraws + c4Draws;
            double winRate = totalGames > 0 ? (double) wins / totalGames : 0.0;

            Platform.runLater(() -> {
                System.out.println("( username: " + username + ", wins: " + wins + ", losess: " + losses + ", ELO: " + ELO + "," + " TOTAL GAMES " + totalGames + ", WIN RATE " + Math.floor(winRate*100) +")");
                engine.executeScript("if(typeof updateViewProfileUsername==='function') updateViewProfileUsername('" + escapeJs(username) + "')");
                engine.executeScript("loadProfile(" + ELO + "," + wins + "," + losses + "," + draws + ", " + totalGames + "," +  Math.floor(winRate*100) +")");
                engine.executeScript("loadGameStats('ttt'," + tttWins + "," + tttLosses + "," + tttDraws + "," + tttELO + ", " + tttTotalGames + ", " + Math.floor(tttWinRate*100) + ")");
                engine.executeScript("loadGameStats('c4',"  + c4Wins  + "," + c4Losses  + "," + c4Draws + "," + c4ELO + ", " + c4TotalGames + ", " + Math.floor(c4WinRate*100)  + ")" );
                engine.executeScript("loadMatchHistory(" + buildMatchHistoryJson(res.matchHistory()) + ")");
            });
        });

        profileHandler.setOnError(err -> {
            Platform.runLater(() -> {
                String msg = escapeJs(err.message());
                engine.executeScript("console.log('" + msg + "')");
            });
        });
        System.out.println("end of set up profile");
    }


    public void onLogin(String username, String password) {
        System.out.println("Login clicked: " + username);
        pendingAuthUsername = username;
        authHandler.login(username, password);
    }

    public void onCreateAccount(String username, String password) {
        System.out.println("Create Account clicked: " + username);
        authHandler.createAccount(username, password);
    }

    public String getUsername() {
        if (username != null && !username.isBlank()) {
            return username;
        }
        if (id != null && id.id() != null && !id.id().isEmpty()) {
            String u = sessionDb.getData().displayName(id.id());
            if (u != null && !u.isBlank()) {
                username = u;
                return username;
            }
        }
        return "";
    }

    public void refreshUsernameFromServer() {
        profileHandler.getProfile();
    }

    public void setUsername() {
        refreshUsernameFromServer();
    }

    public void requestProfileData() {
        profileHandler.getStats();
    }

    public void handleNavigation(String action) {
        Platform.runLater(() -> {
            switch (action) {
                case "PROFILE":
                    navigateTo("view-profile.html");
                    break;
                case "LOBBY":
                    navigateTo("lobby.html");
                    break;
                case "LEADERBOARD":
                    navigateTo("leaderboard.html");
                    break;
                case "LOGOUT":
                    if (sessionDb.getData().size() > 1) {
                        navigateToAccountsWithBridge();
                    } else {
                        navigateTo("login-signup.html");
                    }
                    break;
                case "WAITINGROOM":
                    navigateTo("waitingRoom.html");
                    break;
                case "CANCEL":
                    lobbyHandler.leaveLobby();
                    navigateTo("lobbyCreateMatch.html");
                    break;
                case "RETURNPRIVATE":
                    navigateTo("lobbyPrivate.html");
                    break;
                case "TICTACTOE":
                    navigateTo("tictactoe.html");
                    break;
                case "CONNECTFOUR":
                    navigateTo("connect4.html");
                    break;
                case "DASHBOARD":
                    lobbyHandler.returnToDashboard();
                    navigateTo("dashboard.html");
                    break;
                case "BACK":
                    navigateTo("lobby.html");
                    break;
                default:
                    System.out.println("Unknown action: " + action);
            }
        });
    }

    public void sendUsernames(String u1, String u2) {
        engine.executeScript("startGame('" + u1 + "', '" + u2 + "')");
    }

    public void startMatch() {
        lobbyHandler.startGame();
    }

    public void addBot(int difficulty) {
        lobbyHandler.addBot(difficulty);
    }

    public void setReady(boolean ready) {
        lobbyHandler.setReady(ready);
    }

    public void scheduleWaitingRoomPopulateFromLobby() {
        scheduleWaitingRoomPopulateFromLobby(pendingWaitingRoom);
    }

    public void scheduleWaitingRoomPopulateFromLobby(LobbyRoom room) {
        if (room == null || room.getPlayers().isEmpty()) {
            return;
        }
        pendingWaitingRoom = room;
        ChangeListener<Worker.State> listener = new ChangeListener<>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> obs, Worker.State o, Worker.State n) {
                if (n == Worker.State.SUCCEEDED) {
                    populateWaitingRoomFromLobby(room);
                    engine.getLoadWorker().stateProperty().removeListener(this);
                } else if (n == Worker.State.FAILED) {
                    engine.getLoadWorker().stateProperty().removeListener(this);
                }
            }
        };
        engine.getLoadWorker().stateProperty().addListener(listener);
    }

    private void populateWaitingRoomFromLobby(LobbyRoom room) {
        if (room.getHostID() == null) {
            return;
        }
        String joinCode = room.getJoinCode();
        gameType = room.getGameType().toString();
        String playersJson = buildPlayersJsArray(room.getPlayers());
        String hostId = room.getHostID().id();
        String readyArr = buildReadyStatesJsArray(room.getPlayers());
        String command = String.format("setUpGame('%s', '%s','%s','%s',%s, '%s', %s, '%s')",
                escapeJs(username),
                escapeJs(joinCode), escapeJs(gameType), escapeJs(room.getID().id()),
                playersJson, escapeJs(hostId),
                readyArr, escapeJs(id.id()));
        engine.executeScript(command);
        if (id.equals(room.getHostID())) {
            engine.executeScript("if(typeof setAsHost==='function')setAsHost()");
        }
    }

    private void syncWaitingRoomFromLobby(LobbyRoom room) {
        if (room.getHostID() == null) {
            return;
        }
        String playersJson = buildPlayersJsArray(room.getPlayers());
        String hostId = room.getHostID().id();
        String readyArr = buildReadyStatesJsArray(room.getPlayers());
        String command = String.format(
                "if(typeof updatePlayerList==='function'){updatePlayerList('%s', %s, '%s', %s, '%s', '%s', '%s');}",
                escapeJs(username), playersJson, escapeJs(hostId), readyArr, escapeJs(id.id()),
                escapeJs(room.getID().id()), escapeJs(room.getJoinCode()));
        engine.executeScript(command);
    }

    /** JSON array of [username, id, botDifficulty|null] for the waiting-room UI. */
    private String buildPlayersJsArray(ArrayList<Player> players) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < players.size(); i++) {
            if (i > 0) {
                sb.append(",");
            }
            sb.append(buildPlayerRowJs(players.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    private String buildPlayerRowJs(Player p) {
        String diff = (p instanceof Bot b) ? Integer.toString(b.getDifficulty()) : "null";
        return "[\"" + escapeJs(p.getUsername()) + "\",\"" + escapeJs(p.getID().id()) + "\"," + diff + "]";
    }

    private String buildReadyStatesJsArray(ArrayList<Player> players) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < players.size(); i++) {
            sb.append(players.get(i).isReadyForMatch());
            if (i < players.size() - 1) {
                sb.append(",");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    public void sendLobbyData() {
        lobbyHandler.listLobbies();
    }

    /** Re-fetches open lobbies for the lobby browser table (same as {@link #sendLobbyData}). */
    public void refreshLobbyList() {
        sendLobbyData();
    }

    public void joinLobby(String lobbyId) {
        joinLobby(lobbyId, "");
    }

    public void joinLobbyFromList(String lobbyId, String joinCode) {
        joinLobby(lobbyId, joinCode);
    }

    public void joinLobby(String lobbyId, String joinCode) {
        if (lobbyId == null || lobbyId.isBlank()) {
            return;
        }
        String code = joinCode == null ? "" : joinCode.trim();
        lobbyHandler.joinLobby(new LobbyID(lobbyId.trim()), code);
    }

    public void log(String message) {
        System.out.println("[Lobby UI] " + message);
    }

    private String convertRoomsToJsArray(LobbyRoom[] rooms) {
        StringBuilder sb = new StringBuilder("[");

        for (int i = 0; i < rooms.length; i++) {
            LobbyRoom room = rooms[i];

            sb.append("{")
                    .append("id:\"").append(escapeJs(room.getID().id())).append("\",")
                    .append("game:\"").append(escapeJs(room.getGameType().toString())).append("\",")
                    .append("type:\"casual\",")
                    .append("isPublic:").append(room.isPublic()).append(",")
                    .append("joinCode:\"").append(escapeJs(room.getJoinCode())).append("\"")
                    .append("}");

            if (i < rooms.length - 1) {
                sb.append(",");
            }
        }

        sb.append("]");
        return sb.toString();
    }

    private String buildMatchHistoryJson(ArrayList<MatchHistoryEntry> history) {
        if (history == null || history.isEmpty()) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder("[");
        var fmt = DateTimeFormatter.ofPattern("MMM d, yyyy HH:mm").withZone(ZoneId.systemDefault());
        for (int i = 0; i < history.size(); i++) {
            MatchHistoryEntry e = history.get(i);
            if (i > 0) {
                sb.append(",");
            }
            String when = fmt.format(Instant.ofEpochMilli(e.finishedAtEpochMs()));
            sb.append("{");
            sb.append("\"gameType\":").append(jsonQuote(labelGameType(e.gameType()))).append(",");
            sb.append("\"opponent\":").append(jsonQuote(e.opponentName())).append(",");
            sb.append("\"result\":").append(jsonQuote(e.outcome().name().toLowerCase())).append(",");
            sb.append("\"date\":").append(jsonQuote(when)).append(",");
            sb.append("\"eloBefore\":").append(e.eloBefore()).append(",");
            sb.append("\"eloAfter\":").append(e.eloAfter());
            sb.append("}");
        }
        sb.append("]");
        return sb.toString();
    }

    private static String jsonQuote(String s) {
        if (s == null) {
            return "\"\"";
        }
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    private static String labelGameType(GameType g) {
        return switch (g) {
            case TICTACTOE -> "Tic Tac Toe";
            case CONNECTFOUR -> "Connect 4";
        };
    }

    private String escapeJs(String value) {
        if (value == null) {
            return "";
        }
        return value
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }

}

