package ca.ucalgary.seng300.logger;

import java.util.logging.*;

public class Logging {
    public static Logger getLogger(String name) {
        Logger logger = Logger.getLogger(name);

        // Already have formatter
        if (logger.getHandlers().length > 0) {
            return logger;
        }
        logger.setUseParentHandlers(false);
        ConsoleHandler handler = new ConsoleHandler();
        handler.setFormatter(new LogFormatter());
        logger.addHandler(handler);

        return logger;
    }
}
