package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.platformcore.game.*;
import ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourPiece;
import ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToePiece;
import ca.ucalgary.seng300.validation.account.records.UserID;

import java.util.*;

public class Bot extends Player {
  private UserID ID;
  private GameState gameState;
  private GameType gameType;
  private Piece piece;
  private transient GamePossibilityNode possibilityTree;
  private int difficulty;

  public Bot() {
    UserID ID = new UserID(UUID.randomUUID().toString());
    String username = RandomUserID.createRandomUsername().id();
    super(ID, username);
    this.ID = ID;
    this.setAsBot();
    setDifficulty(1);
  }

  /**
   * chooses game move based on current game state
   * @param state state of the game
   * @return move the bot chooses
   */
  public GameMove makeMove(GameState state, Player opponent) {
    updateGameState(state, true, opponent);
    piece = state.getPlayerIDToPiece().get(ID);

    if (difficulty <= 2) { //easy difficulty - play random move
      return getMoveEasy();
    }
    return possibilityTree.chooseMove();
  }

  public void setDifficulty(int difficulty) {
    this.difficulty = difficulty;
    int elo = EloCalculator.eloFromDifficulty(difficulty);
    for (GameType gt : GameType.values()) {
      getGameStats(gt).setEloRating(elo);
    }
  }

  public int getDifficulty() {
    return difficulty;
  }

  public void updateGameState(GameState state, boolean botTurn, Player human) {
    gameState = state;
    gameType = gameState.getGameType();
    piece = state.getPlayerIDToPiece().get(ID);
    if (possibilityTree == null) {
      setPossibilityTree(human);
    }
    GamePossibilityNode newTree = possibilityTree.getChild(state);
    Player player = botTurn ? this : human;
    Player opponent = botTurn ? human : this;

    if (newTree == null) { //setting new tree
      possibilityTree = new GamePossibilityNode(gameState, null, player, opponent, getDepth(), difficulty);
      possibilityTree.evaluateNode(Integer.MIN_VALUE, Integer.MAX_VALUE);
    }
    else { //updating tree
      newTree.setHeight(getDepth());
      newTree.evaluateNode(Integer.MIN_VALUE, Integer.MAX_VALUE);
      possibilityTree = newTree;
    }
  }

  private UserID getOpponentID(GameState state) {
    for (UserID ID : state.getPlayerIDs()) {
      if (!ID.equals(this.ID)) {
        return ID;
      }
    }
    return null;
  }

  private GameMove getMoveEasy() {
    GameMove forcedMove = playForcedMove();
    if (forcedMove != null) {
      double mistakeThreshold = 0.65;
      Random rand = new Random();
      if (rand.nextDouble() < mistakeThreshold || difficulty >= 2) {
        return forcedMove;
      }
    }
    ArrayList<GameMove> possibleMoves = getPossibleMoves(gameState, piece);
    if (possibleMoves.isEmpty()) {
      return new GameMove(new GridSpace(0, 0));
    }
    return possibleMoves.get(Misc.random(0, possibleMoves.size()));
  }

  private GameMove playForcedMove() {
    if (piece == null) {
      return null;
    }
    int targetPieces = gameState.getGameType() == GameType.TICTACTOE ? 3 : 4;
    GameMove winMove = findForcedMove(gameState.getGameBoard(), piece, piece, targetPieces); //finds move that wins game
    if (winMove != null) { //game winning move found
      return winMove;
    }
    return findForcedMove(gameState.getGameBoard(), piece.opposite(), piece, targetPieces); //returns move needed to block opponent win, null if none exists
  }
  public static ArrayList<GameMove> getPossibleMoves(GameState gameState, Piece piece) {
    Piece[][] gameBoard = gameState.getGameBoard();
    GameType game = gameState.getGameType();
    ArrayList<Integer[]> openSpaces;
    if (game == GameType.TICTACTOE) {
      openSpaces = openTTTSpaces(gameBoard);
    }
    else {
      openSpaces = openC4Spaces(gameBoard);
    }
    ArrayList<GameMove> possibleMoves = new ArrayList<>();
    for (Integer[] space : openSpaces) {
      possibleMoves.add(new GameMove(new GridSpace(space[0], space[1]), piece));
    }
    return possibleMoves;
  }
  public static GameMove findForcedMove(Piece[][] board, Piece checkPiece, Piece playedPiece, int target) {
    for (int i = board.length-1; i >= 0; i--) { //starts in bottom left corner, more efficient for C4
      for (int j = 0; j < board[0].length; j++) {
        //checks each grid space for forced moves to complete line or block opponent's line
        int[] result = checkCell(board, new int[]{i,j}, checkPiece, 0, null, true, target-1);
        if (result[2] >= target-1) { //forced move found
          if (target == 3 || (target == 4 && validGravity(board, new int[]{result[0],result[1]}))) {
            GameMove forcedMove = new GameMove(new GridSpace(result[0], result[1]));
            forcedMove.setServerAssignedPiece(playedPiece);
            return forcedMove;
          }
        }
      }
    }
    return null; //no forced moves
  }

  public static boolean validGravity(Piece[][] board, int[] coord) {
    if (coord[0] == 5) {
      return true;
    }
    return board[coord[0]+1][coord[1]] != null;
  }

  private void setPossibilityTree(Player human) {
    possibilityTree = new GamePossibilityNode(gameState, null, this, human, getDepth(), difficulty);
  }

  public GamePossibilityNode getPossibilityTree() {
    return possibilityTree;
  }

  public UserID getID() {
    return ID;
  }
  public void setID(UserID ID) {
    this.ID = ID;
  }

  public boolean isReadyForMatch() {
    return true;
  }

  public void setPiece(Piece piece) {
    this.piece = piece;
  }
  public Piece getPiece() {
    return piece;
  }

  private int getDepth() {
    if (gameType == GameType.TICTACTOE) {
      if (difficulty < 8) {
        return (difficulty/2+2) * 2;
      }
      return -1; //full depth, terminate branches at game end
    }
    if (difficulty < 8) {
      return (difficulty/2+1)*2;
    }
    return 10; //capped at 10 layers (5 moves ahead)
  }

  /**
   * recursively finds empty square at the end of lines of a certain piece of target length from start square
   * @param coord current coordinate
   * @param piece piece being checked
   * @param line length of line of adjacent pieces
   * @param dir direction the line is going
   * @param continuous true if no empty spaces encountered yet
   * @param target target length of line (2 for Tic-tac-toe, 3 for connect four)
   * @return coordinate of square found
   */
  public static int[] checkCell(Piece[][] board, int[] coord, Piece piece, int line, Direction dir, boolean continuous, int target) {
    if (dir == null) {
      if (board[coord[0]][coord[1]] != piece) {
        return new int[]{0,0,-1};
      }
      ArrayList<Direction> directions = new ArrayList<>(Arrays.asList(Direction.values()));

      for (Direction direction : directions) {
        if (!Misc.inBounds(board, direction.move(coord))) {
          continue;
        }
        int[] result = checkCell(board, direction.move(coord), piece, 1, direction, continuous, target); //checks cells in all directions
        if (result[2] >= target) { //found line of sufficient length
          return result;
        }
      }
      return new int[]{0,0,-1};
    }
    if (board[coord[0]][coord[1]] == piece) { //found next piece in line
      if (Misc.inBounds(board, dir.move(coord))) { //move to next square in same direciton
        return checkCell(board, dir.move(coord), piece, line+1, dir, continuous, target);
      }
      if (continuous) { //reached edge, blocked
        return new int[]{0, 0,-1};
      }
      return new int[]{-1,-1,line+1}; //middle space already found
    }
    else if (board[coord[0]][coord[1]] == null) {
      if (continuous && Misc.inBounds(board, dir.move(coord))) {
        if (line < target) { //target length not found, check if more on other side of empty space
          return new int[]{coord[0], coord[1], checkCell(board, dir.move(coord), piece, line, dir, false, target)[2]};
        }
        return new int[]{coord[0], coord[1], line}; //target space found
      }
      if (continuous) {
        return new int[]{coord[0], coord[1], line};
      }
      return new int[]{0, 0, -1};
    }
    if (continuous) {
      return new int[]{0,0,-1};
    }
    return new int[]{0,0,line};
  }
  private static ArrayList<Integer[]> openTTTSpaces(Piece[][] board) {
    if (board.length != 3 || board[0].length != 3) { //board should be 3x3
      return new ArrayList<>(); //should not occur
    }
    int[] squareOrdering = {1,0,2}; //checks center squares first, increased optimization
    ArrayList<Integer[]> spaces = new ArrayList<>();
    for (int i : squareOrdering) {
      for (int j : squareOrdering) {
        if (board[i][j] == null) { //empty space found, available move
          spaces.add(new Integer[]{i, j});
        }
      }
    }
    return spaces;
  }
  private static ArrayList<Integer[]> openC4Spaces(Piece[][] board) {
    if (board.length != 6 || board[0].length != 7) { //board should be 6x7
      return new ArrayList<>(); //should not occur
    }
    int[] squareOrdering = {3,2,4,1,5,0,6}; //optimal order to check columns
    ArrayList<Integer[]> spaces = new ArrayList<>();
    for (int col : squareOrdering) {
      for (int row = board.length-1; row >= 0; row--) { //starts from bottom of column until empty space is found, only lowest space of each column is available due to gravity
        if (board[row][col] == null) { //empty space found
          spaces.add(new Integer[]{row, col});
          break;
        }
      }
    }
    return spaces;
  }
}
