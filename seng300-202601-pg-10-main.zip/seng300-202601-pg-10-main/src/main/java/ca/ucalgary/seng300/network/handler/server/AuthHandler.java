package ca.ucalgary.seng300.network.handler.server;

import ca.ucalgary.seng300.database.AccountDatabase;
import ca.ucalgary.seng300.database.LeaderboardDatabase;
import ca.ucalgary.seng300.network.message.Payload.Auth.Req;
import ca.ucalgary.seng300.network.message.Payload.Auth.Res;
import ca.ucalgary.seng300.network.ClientData;
import ca.ucalgary.seng300.network.message.Payload.Error;
import ca.ucalgary.seng300.platformcore.Leaderboard;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.platformcore.PlayerStats;
import ca.ucalgary.seng300.validation.account.AccountDatabaseManager;
import ca.ucalgary.seng300.validation.account.AccountValidation;
import ca.ucalgary.seng300.validation.account.results.AccountCreationResult;
import ca.ucalgary.seng300.validation.account.results.AccountValidationResult;
import ca.ucalgary.seng300.validation.account.results.ValidationResult;
import ca.ucalgary.seng300.validation.account.stubs.UserCredentials;
import ca.ucalgary.seng300.validation.account.stubs.CredentialsStoreStub;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;

public class AuthHandler extends ServerHandler<Req, Res> {
    private final AccountDatabase accountDatabase;
    private final LeaderboardDatabase leaderboardDatabase;
    
    public AuthHandler(
        AccountDatabase accountDatabase,
        LeaderboardDatabase leaderboardDatabase
    ) {
        this.accountDatabase = accountDatabase;
        this.leaderboardDatabase = leaderboardDatabase;
    }

    @Override
    public Res handle(Req req, ClientData clientData) {
        return switch (req) {
            case Req.Login      r -> handleLogin(r, clientData);
            case Req.Logout     r -> handleLogout(r);
            case Req.Signup     r -> handleSignUp(r);
            case Req.LoginToken r -> handleLoginToken(r, clientData);
        };
    }

    private void loadOnLogin(SessionToken token, ClientData clientData, String username) {
        Player player = new Player(token.userID, username);
        Leaderboard leaderboard = leaderboardDatabase.getData();
        PlayerStats stat = leaderboard.getPlayerStats(token.userID);
        player.setStats(stat);
        
        clientData.setPlayer(player);
        clientData.setSessionToken(token);
    }

    private Res handleLogin(Req.Login login, ClientData clientData) {
        String username = login.username();
        String password = login.password();

        AccountValidationResult result = accountDatabase.getData().getAccountValidation().validateLogin(username, password);

        if (!result.isValid) {
            return new Error(result.message);
        }
        
        AccountDatabaseManager manager = accountDatabase.getData();
        UserCredentials creds = manager.getUserCredentials(username);
        SessionToken token = manager.getSessionToken(creds.profile.userID);

        loadOnLogin(token, clientData, creds.profile.username);

        accountDatabase.save();

        return new Res.Login(creds.profile.userID, token);
    }

    private Res handleLogout(Req.Logout logout) {
        // TODO: integrate logout flow later
        return new Error("Logout not integrated yet.");
    }

    private Res handleSignUp(Req.Signup signUp) {
        String username = signUp.username();
        String password = signUp.password();
        
        AccountCreationResult result = accountDatabase.getData().createAccount(username, password);
        if (!result.success) {
            return new Error(result.message);
        }
        Leaderboard leaderboard = leaderboardDatabase.getData();
        leaderboard.addPlayer(result.userProfile.userID);

        accountDatabase.save();
        leaderboardDatabase.save();
        return new Res.Signup();
    }

    private Res handleLoginToken(Req.LoginToken loginToken, ClientData clientData) {
        SessionToken token = loginToken.token();
        AccountValidation tokenManager = accountDatabase.getData().getAccountValidation();
        ValidationResult result = tokenManager.validateToken(token);
        if (!result.isValid) {
            return new Error(result.message);
        }
        AccountDatabaseManager manager = accountDatabase.getData();
        CredentialsStoreStub credentialsStore = manager.getCredentialsStore();
        UserCredentials creds = credentialsStore.getCredentialsByUserID(token.userID);
        
        loadOnLogin(token, clientData, creds.profile.username);
        return new Res.LoginToken();
    }
}
