package ca.ucalgary.seng300.platformcore;

import java.io.Serializable;

public record MatchHistoryEntry(
        GameType gameType,
        String opponentName,
        MatchResult outcome,
        long finishedAtEpochMs,
        int eloBefore,
        int eloAfter
) implements Serializable {
    private static final long serialVersionUID = 1L;
}
