package ca.ucalgary.seng300.network;

import java.io.ObjectOutputStream;

import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;

public class ClientData {
    private ObjectOutputStream out;
    private Player player;
    private SessionToken sessionToken;

    public ClientData(ObjectOutputStream out) {
        this.out = out;
    }

    public ObjectOutputStream getOutStream() {
        return this.out;
    }

    public Player getPlayer() {
        return this.player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public SessionToken getSessionToken() {
        return this.sessionToken;
    }

    public void setSessionToken(SessionToken sessionToken) {
        this.sessionToken = sessionToken;
    }

    @Override
    public int hashCode() {
        return out.hashCode();
    }
}
