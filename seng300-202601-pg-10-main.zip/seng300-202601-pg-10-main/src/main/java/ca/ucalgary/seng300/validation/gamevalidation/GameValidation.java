package ca.ucalgary.seng300.validation.gamevalidation;

import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.game.GameMove;
import ca.ucalgary.seng300.platformcore.game.Piece;
import ca.ucalgary.seng300.platformcore.game.GameState;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.gamevalidation.enums.ValidationErrorCode;
import ca.ucalgary.seng300.validation.gamevalidation.results.*;

import java.io.Serializable;
import java.util.HashMap;

/**
 * GameValidation: Central logic unit for move and win validation
 */
public class GameValidation implements Serializable {
    private static final long serialVersionUID = 1L;

    //---MAIN---VALIDATORS---

    public MoveValidationResult validateMove(GameType gameType, GameState gameState, UserID currentPlayerID, GameMove move) {
        // NULL SAFETY
        if (gameState == null || move == null || gameState.getGameBoard() == null || gameState.getPlayerIDToPiece() == null || gameState.getPlayerIDToPiece().get(currentPlayerID) == null) {
            return new MoveValidationResult(false, ValidationErrorCode.ILLEGAL_MOVE, "Missing game data");
        }

        // UNIVERSAL CHECKS

        // 0.) Turn Authorization Check
        // We dont have id here yet
        // if (!java.util.Objects.equals(move.getPlayerID(), currentPlayerID)) {
        //     return new MoveValidationResult(false, ValidationErrorCode.INVALID_TURN, "It is not your turn");
        // }

        // 1.) Correct Player to Piece
        // Piece assignedPiece = gameState.getPlayerIDToPiece().get(currentPlayerID);
        // if (move.getPiece() != assignedPiece){
        //     return new MoveValidationResult(false, ValidationErrorCode.ILLEGAL_MOVE, "You cannot place your opponent's piece");
        // }

        // 2.) Universal Bounds Check
        if (!isWithinBounds(gameState, move))
            return new MoveValidationResult(false, ValidationErrorCode.OUT_OF_BOUNDS, "This move is out of bounds");

        // 3.) Universal Cell Occupancy Check
        if (isCellOccupied(gameState, move)) {
            return new MoveValidationResult(false, ValidationErrorCode.CELL_OCCUPIED, "This cell is already taken");
        }

        // GAME SPECIFIC ROUTING

        // 4.) TIC-TAC-TOE CHECK
        if (gameType == GameType.TICTACTOE) {
            return new MoveValidationResult(true, null, "Move Accepted");

        // 5.) CONNECT 4 CHECK
        } else if (gameType == GameType.CONNECTFOUR) {
            return validateConnect4Gravity(gameState, move);
        }
        return new MoveValidationResult(false, ValidationErrorCode.ILLEGAL_MOVE, "Unsupported Game");
    }

    public WinValidationResult validateWin(GameState gameState, HashMap<UserID, ? extends Piece> playerIDToPiece) {
        // NULL SAFETY
        if (gameState == null || playerIDToPiece == null) {
            return new WinValidationResult(false, false, null);
        }

        WinValidationResult result;
        GameType type = gameState.getGameType();

        // GAME SPECIFIC ROUTING

        // 1.) TIC-TAC-TOE CHECK
        if (type == GameType.TICTACTOE) {
            result = checkTicTacToeWin(gameState, playerIDToPiece);
        // 2.) CONNECT 4 CHECK
        } else if (type == GameType.CONNECTFOUR) {
            result = checkConnect4Win(gameState, playerIDToPiece);
        } else {
            return new WinValidationResult(false, false, null);
        }

        // UNIVERSAL CHECKS

        // 3.) DRAW CHECK
        if (!result.hasWinner() && isBoardFull(gameState.getGameBoard())) {
            return new WinValidationResult(false, true, null);
        }

        return result;
    }


    //---GENERAL---HELPERS---

    private boolean isWithinBounds(GameState gameState, GameMove move) {
        Piece[][] board = gameState.getGameBoard();
        int r = move.getPos().row;
        int c = move.getPos().column;
        return (r >= 0 && r < board.length && c >= 0 && c < board[0].length);
    }

    private boolean isCellOccupied(GameState gameState, GameMove move) {
        Piece[][] board = gameState.getGameBoard();
        return board[move.getPos().row][move.getPos().column] != null;
    }

    private UserID getPlayerFromPiece(Piece piece, HashMap<UserID, ? extends Piece> playerIDToPiece) {
        if (piece == null) {
            return null;
        }
        for (UserID id : playerIDToPiece.keySet()) {
            Piece assignedPiece = playerIDToPiece.get(id);
            if (assignedPiece == piece) {
                return id;
            }
        }
        return null;
    }

    // Checks every cell on the board to see if any legal moves remain, if not then the game has reached a draw
    public boolean isBoardFull(Piece[][] board) {
        // going through each row and checking each cell's piece (if it's an empty Piece then board isn't full)
        for (Piece[] row : board) {
            for (Piece p : row) {
                if (p == null) {
                    return false;
                }
            }
        }
        return true;
    }


    //---TIC-TAC-TOE---HELPERS---

    private WinValidationResult checkTicTacToeWin(GameState gameState, HashMap<UserID, ? extends Piece> playerIDToPiece) {
        Piece[][] board = gameState.getGameBoard();
        for (int i = 0; i < 3; i++) {
            if (board[i][0] != null && board[i][0] == board[i][1] && board[i][1] == board[i][2]) {
                return new WinValidationResult(true, false, getPlayerFromPiece(board[i][0], playerIDToPiece));
            }
            if (board[0][i] != null && board[0][i] == board[1][i] && board[1][i] == board[2][i]) {
                return new WinValidationResult(true, false, getPlayerFromPiece(board[0][i], playerIDToPiece));
            }
        }
        if (board[1][1] != null) {
            if ((board[0][0] == board[1][1] && board[1][1] == board[2][2]) || (board[0][2] == board[1][1] && board[1][1] == board[2][0])) {
                return new WinValidationResult(true, false, getPlayerFromPiece(board[1][1], playerIDToPiece));
            }
        }
        return new WinValidationResult(false, false, null);
    }


    //---CONNECT-4---HELPERS---

    private MoveValidationResult validateConnect4Gravity(GameState gameState, GameMove move) {
        int r = move.getPos().row;
        int c = move.getPos().column;
        Piece[][] board = gameState.getGameBoard();
        if (r < board.length - 1 && board[r + 1][c] == null) {
            return new MoveValidationResult(false, ValidationErrorCode.ILLEGAL_MOVE, "Connect 4 piece MUST fall to the bottom or rest on another piece");
        }
        return new MoveValidationResult(true, null, "Move Accepted");
    }

    private WinValidationResult checkConnect4Win(GameState gameState, HashMap<UserID, ? extends Piece> playerIDToPiece) {
        Piece[][] board = gameState.getGameBoard();
        int rows = board.length;
        int cols = board[0].length;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                Piece p = board[r][c];
                if (p == null) continue;
                if (c + 3 < cols && p == board[r][c + 1] && p == board[r][c + 2] && p == board[r][c + 3]) {
                    return new WinValidationResult(true, false, getPlayerFromPiece(p, playerIDToPiece));
                }
                if (r + 3 < rows && p == board[r + 1][c] && p == board[r + 2][c] && p == board[r + 3][c]) {
                    return new WinValidationResult(true, false, getPlayerFromPiece(p, playerIDToPiece));
                }
                if (r + 3 < rows && c - 3 >= 0 && p == board[r + 1][c - 1] && p == board[r + 2][c - 2] && p == board[r + 3][c - 3]) {
                    return new WinValidationResult(true, false, getPlayerFromPiece(p, playerIDToPiece));
                }
                if (r + 3 < rows && c + 3 < cols && p == board[r + 1][c + 1] && p == board[r + 2][c + 2] && p == board[r + 3][c + 3]) {
                    return new WinValidationResult(true, false, getPlayerFromPiece(p, playerIDToPiece));
                }
            }
        }
        return new WinValidationResult(false, false, null);
    }
}
