package ca.ucalgary.seng300.validation.account.stubs;

import java.io.Serializable;

public class UserCredentials implements Serializable {
    private static final long serialVersionUID = 1L;
    public UserProfile profile;
    public String hashedPassword;
    private long createdTime;
    private long lastValidationTime;

    public UserCredentials(UserProfile profile, String hashedPassword) {
        this.hashedPassword = hashedPassword;
        this.profile = profile;
        this.createdTime = System.currentTimeMillis();
        this.lastValidationTime = System.currentTimeMillis();
    }

    public long getCreatedTime() {
        return createdTime;
    }

    public long getLastValidationTime() {
        return lastValidationTime;
    }
}
