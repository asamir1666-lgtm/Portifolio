package ca.ucalgary.seng300.platformcore;

import java.io.Serializable;

import ca.ucalgary.seng300.validation.account.records.UserID;

public class LeaderboardExport implements Serializable {
    private static final long serialVersionUID = 1L;
    private UserID playerId;
    private PlayerStats playerStats;
    /** Optional display name (e.g. from account store); null when not resolved. */
    private String displayUsername;

    public LeaderboardExport(UserID playerId, PlayerStats playerStats) {
        this(playerId, playerStats, null);
    }

    public LeaderboardExport(UserID playerId, PlayerStats playerStats, String displayUsername) {
        this.playerId = playerId;
        this.playerStats = playerStats;
        this.displayUsername = displayUsername;
    }

    public UserID getPlayerId() {
        return playerId;
    }
    public PlayerStats getPlayerStats() {
        return playerStats;
    }

    public String getDisplayUsername() {
        return displayUsername;
    }
}
