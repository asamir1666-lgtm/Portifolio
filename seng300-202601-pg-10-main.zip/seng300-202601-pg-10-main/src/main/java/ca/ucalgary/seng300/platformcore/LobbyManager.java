package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.Config;
import ca.ucalgary.seng300.validation.account.records.UserID;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class LobbyManager implements Serializable {
    private static final long serialVersionUID = 1L;
    private static LobbyManager instance = null;

    private HashMap<LobbyID, LobbyRoom> lobbiesByID; // maps lobby ID to lobby

    private HashMap<String, LobbyRoom> lobbiesByJoinCode; //maps join code to lobby;

    private LobbyManager() {
        lobbiesByID = new HashMap<>();
        lobbiesByJoinCode = new HashMap<>();
    }

    public void reset() {
        lobbiesByID.clear();
        lobbiesByJoinCode.clear();
    }

    public Boolean IsPlayerInLobby(LobbyID lobbyID, UserID playerId) {
        LobbyRoom lobby = lobbiesByID.get(lobbyID);
        return lobby != null && lobby.hasPlayer(playerId);
    }

    public LobbyJoinResponse joinLobby(Player player, LobbyID lobbyID, String joinCode) {
        if (lobbyID != null && !lobbiesByID.containsKey(lobbyID)) {
            return new LobbyJoinResponse(false, "Lobby not found", LobbyResponseType.FAILURE);
        }
        if (!joinCode.isEmpty() && !lobbiesByJoinCode.containsKey(joinCode)) {
            return new LobbyJoinResponse(false, "Lobby not found", LobbyResponseType.FAILURE);
        }
        if (lobbyID == null && joinCode.isEmpty()) {
            return new LobbyJoinResponse(false, "ID or Join Code Required", LobbyResponseType.FAILURE);
        }

        LobbyRoom lobby;
        if (lobbyID == null) {
            lobby = lobbiesByJoinCode.get(joinCode);
        }
        else {
            lobby = lobbiesByID.get(lobbyID);
        }
        return lobby.admitPlayer(player, joinCode);
    }

    public static LobbyManager getInstance() {
        if (instance == null) {
            instance = new LobbyManager();
        }
        return instance;
    }


    public LobbyRoom newLobby(GameType game, int capacity){
        String joinCode = this.generateJoinCode();
        LobbyID ID = new LobbyID(game.toString() + UUID.randomUUID() + "-" + joinCode);
        LobbyRoom lobby = new LobbyRoom(ID, game, capacity, joinCode);
        this.addLobby(lobby);
        return lobby;
    }

    public Player getPlayer(GameType gameType, LobbyID lobbyID, UserID playerID) {
        if (!lobbiesByID.containsKey(lobbyID)) {
            throw new IllegalArgumentException("Lobby not found: " + lobbyID + " for game type: " + gameType);
        }
        LobbyRoom lobby = lobbiesByID.get(lobbyID);
        return lobby.getPlayer(playerID);
    }

    public LobbyRoom getLobby(LobbyID lobbyID) {
        if (!lobbiesByID.containsKey(lobbyID)) {
            throw new IllegalArgumentException("Lobby not found: " + lobbyID);
        }
        return lobbiesByID.get(lobbyID);
    }

    public List<LobbyRoom> getLobbies() {
        return new ArrayList<>(lobbiesByID.values());
    }

    public LobbyRoom getLobbyByJoinCode(String joinCode) {
        if (!lobbiesByJoinCode.containsKey(joinCode)) {
            throw new IllegalArgumentException("Lobby not found with join code: " + joinCode);
        }
        return lobbiesByJoinCode.get(joinCode);
    }

    public void addLobby(LobbyRoom lobby) {
        lobbiesByID.put(lobby.getID(), lobby);
        lobbiesByJoinCode.put(lobby.getJoinCode(), lobby);
    }

    public void removeLobby(LobbyRoom lobby) {
        if (lobbiesByID.containsKey(lobby.getID())) {
            lobbiesByID.remove(lobby.getID());
        }
        if (lobbiesByJoinCode.containsKey(lobby.getJoinCode())) {
            lobbiesByJoinCode.remove(lobby.getJoinCode());
        }
    }

    public Boolean validJoinCode(String joinCode) {
        return !lobbiesByJoinCode.containsKey(joinCode);
    }

    public String generateJoinCode() {
        char[] characters =
                "abcdefghijklmnopqrtstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();

        while (true) {
            StringBuilder newCode = new StringBuilder();
            for (int i = 0; i < Config.JOIN_CODE_LENGTH; i++) {
                newCode.append(characters[Misc.random(0, characters.length)]);
            }
            if (this.validJoinCode(newCode.toString())) {
                return newCode.toString();
            }
        }
    }

    /**
     * Cancels the rematch and redirects all players back to the dashboard, then
     * deletes the lobby.
     */
    public void cancelRematch(LobbyRoom lobby) {
        for (Player player : lobby.getPlayers()) {
            player.redirectToDashboard();
        }
        this.removeLobby(lobby);
    }

    public LobbyRoom getLobbyOrNull(LobbyID lobbyID) {
        if (lobbyID == null) {
            return null;
        }
        return lobbiesByID.get(lobbyID);
    }

    /** Lobby that currently contains this user, if any (canonical copy in {@link LobbyRoom#playerMap}). */
    public LobbyRoom getLobbyContainingPlayer(UserID userId) {
        if (userId == null) {
            return null;
        }
        for (LobbyRoom room : lobbiesByID.values()) {
            if (room.hasPlayer(userId)) {
                return room;
            }
        }
        return null;
    }

    public void handlePlayerDisconnected(Player player) {
        if (player == null) {
            return;
        }
        LobbyID lid = player.getLobbyId();
        if (lid == null) {
            return;
        }
        LobbyRoom lobby = lobbiesByID.get(lid);
        if (lobby == null) {
            player.redirectToDashboard();
            return;
        }
        LobbyState st = lobby.getState();
        boolean inMatch = (st == LobbyState.IN_GAME || st == LobbyState.GAME_OVER);

        lobby.removeDisconnectedPlayer(player);

        if (lobby.getPlayers().isEmpty()) {
            removeLobby(lobby);
            return;
        }
        if (inMatch) {
            lobby.dissolveAllPlayers();
            removeLobby(lobby);
            return;
        }
        boolean onlyBots = true;
        for (Player p : lobby.getPlayers()) {
            if (!p.isBot()) {
                onlyBots = false;
                break;
            }
        }
        if (onlyBots) {
            lobby.dissolveAllPlayers();
            removeLobby(lobby);
        }
    }
}