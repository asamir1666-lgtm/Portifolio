package ca.ucalgary.seng300.validation.account.stubs;

import java.io.Serializable;

import ca.ucalgary.seng300.validation.account.records.UserID;

public class SessionToken implements Serializable {
    private static final long serialVersionUID = 1L;
    public String tokenValue;
    public long createdAt;
    public UserID userID;


    public void init(String tokenValue, UserID userID) {
        this.tokenValue = tokenValue;
        this.createdAt = System.currentTimeMillis();
        this.userID = userID;
    }

    public SessionToken(String tokenValue, UserID userID) {
        init(tokenValue, userID);
    }

    public void setToken(SessionToken other) {
        this.tokenValue = other.tokenValue;
        this.createdAt = other.createdAt;
        this.userID = other.userID;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        SessionToken that = (SessionToken) obj;
        return tokenValue.equals(that.tokenValue);
    }
}
