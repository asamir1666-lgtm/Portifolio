package ca.ucalgary.seng300.network.handler.server;

import ca.ucalgary.seng300.network.message.Payload.Leaderboard.Res;
import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.LeaderboardExport;

import java.util.ArrayList;

import ca.ucalgary.seng300.database.AccountDatabase;
import ca.ucalgary.seng300.database.LeaderboardDatabase;
import ca.ucalgary.seng300.network.ClientData;
import ca.ucalgary.seng300.network.message.Payload.Leaderboard.Req;
import ca.ucalgary.seng300.validation.account.stubs.UserCredentials;

public class LeaderboardHandler extends ServerHandler<Req, Res> {
    private final LeaderboardDatabase leaderboardDatabase;
    private final AccountDatabase accountDatabase;

    public LeaderboardHandler(LeaderboardDatabase leaderboardDatabase, AccountDatabase accountDatabase) {
        this.leaderboardDatabase = leaderboardDatabase;
        this.accountDatabase = accountDatabase;
    }
    
    @Override
    public Res handle(Req req, ClientData clientData) {
        return switch (req) {
            case Req.Get r -> handleGetLeaderboard(r);
        };
    }

    public Res handleGetLeaderboard(Req.Get req) {
        GameType gameType = req.gameType();

        ArrayList<LeaderboardExport> entries = leaderboardDatabase.getData().getTopPlayers(-1, gameType);
        var store = accountDatabase.getData().getCredentialsStore();
        ArrayList<LeaderboardExport> enriched = new ArrayList<>(entries.size());
        for (LeaderboardExport e : entries) {
            UserCredentials creds = store.getCredentialsByUserID(e.getPlayerId());
            String name = creds != null && creds.profile != null
                    ? creds.profile.username
                    : e.getPlayerId().id();
            enriched.add(new LeaderboardExport(e.getPlayerId(), e.getPlayerStats(), name));
        }

        return new Res.Get(enriched);
    }
}

