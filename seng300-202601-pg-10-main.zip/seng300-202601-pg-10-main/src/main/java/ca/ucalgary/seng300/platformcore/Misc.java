package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.platformcore.game.Piece;

public class Misc {
  public static int random(int min, int max) {
    return (int)(Math.random() * (max - min) + min);
  }

  public static boolean inBounds(Piece[][] board, int[] coord) {
    return coord[0] >= 0 && coord[0] < board.length && coord[1] >= 0 && coord[1] < board[0].length;
  }

  public static Piece[][] copyBoard(Piece[][] board) {
    Piece[][] newBoard = new Piece[board.length][board[0].length];
    for (int i = 0; i < board.length; i++) {
      System.arraycopy(board[i], 0, newBoard[i], 0, board[0].length);
    }
    return newBoard;
  }
}
