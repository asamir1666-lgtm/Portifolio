package ca.ucalgary.seng300.platformcore.game.connectfour;

import ca.ucalgary.seng300.platformcore.game.GameMove;
import ca.ucalgary.seng300.platformcore.game.GridSpace;

public class ConnectFourMove extends GameMove {
    public ConnectFourMove(GridSpace grid) {
        super(grid);
    }
    public ConnectFourMove(GridSpace grid, ConnectFourPiece serverAssignedPiece) {
        super(grid, serverAssignedPiece);
    }
}
