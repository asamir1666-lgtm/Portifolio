package ca.ucalgary.seng300.network;

public enum DiscoveryType {
    SUBNET_SCAN,
    BROADCAST,
    MULTICAST
}
