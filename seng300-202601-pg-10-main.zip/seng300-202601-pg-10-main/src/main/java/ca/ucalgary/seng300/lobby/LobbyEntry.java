package ca.ucalgary.seng300.lobby;

import ca.ucalgary.seng300.platformcore.GameType;

public class LobbyEntry {
    // ID shouldn't change after lobby creation?
    private final String id;
    private final GameType game;
    private boolean isPublic;
    private String joinCode;
    // private ArrayList<Player> players;
    // private Player host;
    private int capacity;
    // private LobbyState state;
    //private int readyPlayers;



    public LobbyEntry(String id, GameType game, int capacity, String joinCode){
        this.id = id;
        this.game = game;
        this.capacity = capacity;
        this.joinCode = joinCode;
        //this.readyPlayers = readyPlayers;
    }

    public String getID(){
        return id;
    }
    public GameType getGame() {
        return game;
    }

    public boolean isPublic() {
        return isPublic;
    }
    public String getJoinCode() {
        return joinCode;
    }
    public int getCapacity(){
        return capacity;
    }
//    public int getReadyPlayers() {
//        return readyPlayers;
//    }
}

