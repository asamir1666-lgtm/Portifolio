package ca.ucalgary.seng300.platformcore;

/**
 * Standard two-player Elo update (K=32).
 */
public final class EloCalculator {
    private static final int K = 32;
    private static final int MIN_BOT_ELO = 850;
    private static final int MAX_BOT_ELO = 2150;

    private EloCalculator() {}

    /**
     * Representative Elo for a bot from its difficulty (1 = weakest, 10 = strongest).
     * For display or future use; the bot does not persist this rating.
     */
    public static int eloFromDifficulty(int difficulty) {
        int d = Math.max(1, Math.min(10, difficulty));
        return MIN_BOT_ELO + (d - 1) * (MAX_BOT_ELO - MIN_BOT_ELO) / 9;
    }

    /**
     * @param ratingA current rating of player A
     * @param ratingB current rating of player B
     * @param aWon true if A won (ignored if draw)
     * @param draw true if the game was a draw
     * @return [newRatingA, newRatingB]
     */
    public static int[] newRatingsAfterGame(int ratingA, int ratingB, boolean aWon, boolean draw) {
        double expA = 1.0 / (1.0 + Math.pow(10, (ratingB - ratingA) / 400.0));
        double expB = 1.0 - expA;
        double scoreA = draw ? 0.5 : (aWon ? 1.0 : 0.0);
        double scoreB = 1.0 - scoreA;
        int newA = (int) Math.round(ratingA + K * (scoreA - expA));
        int newB = (int) Math.round(ratingB + K * (scoreB - expB));
        return new int[] { newA, newB };
    }
}
