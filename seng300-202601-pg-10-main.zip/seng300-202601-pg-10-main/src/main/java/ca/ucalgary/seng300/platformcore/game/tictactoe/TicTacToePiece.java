package ca.ucalgary.seng300.platformcore.game.tictactoe;

import ca.ucalgary.seng300.platformcore.game.Piece;

public enum TicTacToePiece implements Piece {
    X,
    O;

    @Override
    public char getSymbol() {
        return switch (this) {
            case X -> 'X';
            case O -> 'O';
        };
    }

    @Override
    public Piece opposite() {
        return switch (this) {
            case X -> O;
            case O -> X;
        };
    }

    @Override
    public String toString() {
        return switch (this) {
            case X -> "X";
            case O -> "O";
        };
    }
}
