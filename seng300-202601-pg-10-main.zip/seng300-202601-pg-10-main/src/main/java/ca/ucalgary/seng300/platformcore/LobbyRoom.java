package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.logger.Logging;
import ca.ucalgary.seng300.platformcore.game.GameAbstract;
import ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToeGame;
import ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourGame;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Logger;

import ca.ucalgary.seng300.validation.account.records.UserID;

public class LobbyRoom implements Serializable {
  private static final long serialVersionUID = 1L;
  private LobbyID ID;
  private GameType game;
  private boolean isPublic;
  private String joinCode;
  private ArrayList<Player> players;
  private HashMap<UserID, Player> playerMap;
  private Player host;
  private int capacity;
  private LobbyState state;
  private int readyPlayers;
  private GameAbstract lobbyGame;
  private static final Logger logger = Logging.getLogger("Lobby");

  public LobbyRoom(LobbyID ID, GameType game, int capacity, String joinCode) {
    this.ID = ID;
    this.game = game;
    isPublic = true;
    players = new ArrayList<>();
    this.playerMap = new HashMap<>();
    host = null;
    this.capacity = capacity;
    this.readyPlayers = 0;
    this.state = LobbyState.WAITING_FOR_PLAYERS;
    this.joinCode = joinCode;
  }

  public String toString() {
    return ID.id();
  }

  public LobbyID getID() {return ID;}
  public void setID(LobbyID ID) {this.ID = ID;}

  public UserID getHostID() {
    if (host == null) {
      return null;
    }
    return host.getID();
  }

  public void addHost(Player player) {
    // WARNING: This bypass all the checks
    // Only use this for the host when creating the lobby, not for admitting players
    setHost(player);
    players.add(player);
    playerMap.put(player.getID(), player);
    player.joinLobby(ID);
  }

  public boolean hostStart(UserID hostID) {
    if (host == null) {
      logger.warning("Host start failed: No host assigned to lobby " + ID);
      return false;
    }
    if (!host.getID().equals(hostID)) {
      logger.warning("Host start failed: Player " + hostID + " is not the host of lobby " + ID);
      return false;
    }
    if (players.size() < 2) {
      logger.warning("Cannot start game: Not enough players in lobby " + ID);
      return false;
    }
    for (Player p : players) {
      if (!p.isReadyForMatch()) {
        logger.warning("Host start failed: not all players ready in lobby " + ID);
        return false;
      }
    }

    return startGame() != null;
  }

  public LobbyState getState() {
    return state;
  }

  public LobbyJoinResponse admitPlayer(Player player, String codeInput) {
    if (state.equals(LobbyState.WAITING_FOR_PLAYERS)) { //lobby must be waiting for players to add players
      if (!isPublic) {
        if (codeInput.isEmpty()) { //no access code entered
          return new LobbyJoinResponse(false, "Access code required", LobbyResponseType.PRIVATE);
        }
        else if (!codeInput.equals(joinCode)) {
          return new LobbyJoinResponse(false, "Incorrect access code", LobbyResponseType.PRIVATE);
        }
      }
      if (playerMap.containsKey(player.getID())) { //player is already in the lobby
        return new LobbyJoinResponse(false, "Player already in lobby", LobbyResponseType.FAILURE);
      }
      if (players.size() >= capacity) {
        return new LobbyJoinResponse(false, "Lobby is full", LobbyResponseType.FAILURE);
      }
      //user join attempt valid
      player.joinLobby(ID);
      if (players.isEmpty()) { //player is first in the lobby, set as host
        setHost(player);
      }
      players.add(player);
      playerMap.put(player.getID(), player);
      return new LobbyJoinResponse(true, "Successfully joined lobby " + ID, LobbyResponseType.SUCCESS);
    }
    else if (state.equals(LobbyState.FULL)) {
      return new LobbyJoinResponse(false, "Lobby is full", LobbyResponseType.FAILURE);
    }
    else { //lobby's game session is active
      return new LobbyJoinResponse(false, "Game is in progress", LobbyResponseType.FAILURE);
    }
  }

  public void removePlayer(Player player) {
    if (state.equals(LobbyState.WAITING_FOR_PLAYERS)) { //only removes player if lobby is not in a game
      player.leaveLobby();
      players.remove(player);
      playerMap.remove(player.getID());
    }
  }

  public boolean isPublic() {
    return isPublic;
  }

  public void removeDisconnectedPlayer(Player player) {
    if (!playerMap.containsKey(player.getID())) {
      return;
    }
    boolean wasHost = host != null && host.getID().equals(player.getID());
    players.remove(player);
    playerMap.remove(player.getID());
    player.redirectToDashboard();
    if (players.isEmpty()) {
      host = null;
      lobbyGame = null;
      return;
    }
    if (wasHost) {
      setHost(players.get(0));
    }
    if (state == LobbyState.IN_GAME || state == LobbyState.GAME_OVER) {
      lobbyGame = null;
    }
  }

  public void dissolveAllPlayers() {
    ArrayList<Player> copy = new ArrayList<>(players);
    for (Player p : copy) {
      p.redirectToDashboard();
    }
    players.clear();
    playerMap.clear();
    host = null;
    lobbyGame = null;
    state = LobbyState.WAITING_FOR_PLAYERS;
    readyPlayers = 0;
  }
  public ArrayList<Player> getPlayers() {return players;}
  public Player getPlayer(UserID playerID) {return playerMap.get(playerID);}
  public void setPublicity(boolean publicity) {isPublic = publicity;}
  public void setState(LobbyState newState) {state = newState;}
  public String getJoinCode() {return joinCode;}

  private void setHost(Player newHost) {host = newHost;}
  public GameType getGameType() {return game;}
  public GameAbstract<?> getGame() {return lobbyGame;}

  /**
   * Starts the game for all players in the lobby.
   * @return A new Game object representing the started game.
   */
  public GameAbstract<?> startGame() {
    if (!state.equals(LobbyState.WAITING_FOR_PLAYERS)) {
      throw new IllegalStateException("Cannot start game: Lobby is not waiting for players.");
    }
    if (players.size() < 2) {
      logger.warning("Cannot start game: Not enough players in lobby " + ID);
      return null;
    }
    this.readyPlayers = 0;
    for (Player player : players) {
      player.clearRematchVote();
      player.playGame();
    }
    this.state = LobbyState.IN_GAME;

    GameAbstract<?> lobbyGame = switch (game) {
      case TICTACTOE -> new TicTacToeGame( 3, 3, players.get(0), players.get(1));
      case CONNECTFOUR -> new ConnectFourGame( 6, 7, players.get(0), players.get(1));
      default -> null;
    };
    this.lobbyGame = lobbyGame;
    return lobbyGame;
  }

  public int getRemainingSpots() {
    return capacity - players.size();
  }

  /**
   * Allows a player to request a rematch after a game has ended. If the player is not already marked as ready for a rematch, they will be marked as ready and the number of ready players will be incremented. If all players in the lobby are ready for a rematch, the game will automatically start.
   * @param player The player requesting the rematch.
   */
  public int getReadyPlayers() {
    return readyPlayers;
  }

  /** Clears rematch votes when a match ends so a new round of votes can begin. */
  public void resetRematchState() {
    this.readyPlayers = 0;
    for (Player p : players) {
      p.clearRematchVote();
    }
  }

  public void requestRematch(Player player) {
    if (player.hasRematchVote()) return;
    player.markRematchVote();

    this.readyPlayers++;

    // Auto start if all players are ready, idk or we could let the host manually start the game
    if (this.readyPlayers == this.players.size()) {
      // Implement this later (idk if it should be needed)
      // startGame();
    }
  }
  public void requestRematch(UserID playerID) {
    if (!playerMap.containsKey(playerID)) {
      throw new IllegalArgumentException("Player with ID " + playerID + " not found in lobby.");
    }
    requestRematch(playerMap.get(playerID));
  }

  public void returnLobby(Player player) {
    player.joinLobby(ID);
    if (state == LobbyState.GAME_OVER) {
      state = LobbyState.WAITING_FOR_PLAYERS;
      lobbyGame = null;
      resetRematchState();
      for (Player p : players) {
        if (p.getState() == PlayerState.POST_GAME) {
          p.joinLobby(ID);
        }
      }
    }
  }

  public void returnLobby(UserID playerID) {
    if (!playerMap.containsKey(playerID)) {
      throw new IllegalArgumentException("Player with ID " + playerID + " not found in lobby.");
    }
    this.returnLobby(playerMap.get(playerID));
  }

  public void returnDashboard(Player player) {
    boolean wasHost = host != null && host.getID().equals(player.getID());
    player.redirectToDashboard();
    players.remove(player);
    playerMap.remove(player.getID());
    if (players.isEmpty()) {
      host = null;
      lobbyGame = null;
      return;
    }
    if (wasHost) {
      setHost(players.get(0));
    }
  }

  public void returnDashboard(UserID playerID) {
    if (!playerMap.containsKey(playerID)) {
      throw new IllegalArgumentException("Player with ID " + playerID + " not found in lobby.");
    }
    this.returnDashboard(playerMap.get(playerID));
  }

  public Boolean hasPlayer(UserID playerID) {
    return playerMap.containsKey(playerID);
  }
}
