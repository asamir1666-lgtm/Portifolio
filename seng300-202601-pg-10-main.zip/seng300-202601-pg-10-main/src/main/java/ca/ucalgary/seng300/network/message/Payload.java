package ca.ucalgary.seng300.network.message;

import java.io.Serializable;
import java.util.ArrayList;

import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.LeaderboardExport;
import ca.ucalgary.seng300.platformcore.LobbyID;
import ca.ucalgary.seng300.platformcore.LobbyJoinResponse;
import ca.ucalgary.seng300.platformcore.LobbyRoom;
import ca.ucalgary.seng300.platformcore.MatchHistoryEntry;
import ca.ucalgary.seng300.platformcore.PlayerStats;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;
import ca.ucalgary.seng300.validation.account.stubs.UserProfile;
import ca.ucalgary.seng300.platformcore.game.GameAbstract;
import ca.ucalgary.seng300.platformcore.game.GameMove;
import ca.ucalgary.seng300.platformcore.game.MoveResult;

public sealed interface Payload extends Serializable permits
        Payload.Auth, Payload.Lobby, Payload.Game, Payload.Matchmaking,
        Payload.Profile, Payload.Leaderboard,
        Payload.Request, Payload.Response
{
    non-sealed interface Request extends Payload {}
    interface Protected extends Request {}

    non-sealed interface Response extends Payload {}
    interface Pushable extends Response {}

    record Direct(UserID target, Response payload) implements Response {}

    /*
     * Auth
     */
    sealed interface Auth extends Payload permits Auth.Req, Auth.Res {
        sealed interface Req extends Auth, Request permits
                Auth.Req.Login, Auth.Req.Logout,
                Auth.Req.Signup, Auth.Req.LoginToken
        {
            record Login(String username, String password) implements Req {}
            record Logout(String token) implements Req {}
            record Signup(String username, String password) implements Req {}
            record LoginToken(SessionToken token) implements Req {}
        }

        sealed interface Res extends Auth, Response permits
                Auth.Res.Login, Auth.Res.Logout,
                Auth.Res.Signup, Auth.Res.LoginToken, Error
        {
            record Login(UserID id, SessionToken token) implements Res {}
            record Logout() implements Res {}
            record Signup() implements Res {}
            record LoginToken() implements Res {}
        }
    }

    /*
     * Lobby
     */
    sealed interface Lobby extends Payload permits Lobby.Req, Lobby.Res {
        sealed interface Req extends Lobby, Protected permits
            Lobby.Req.Create, Lobby.Req.Join, Lobby.Req.List,
            Lobby.Req.Leave, Lobby.Req.Start, Lobby.Req.Rematch,
            Lobby.Req.ReturnLobby, Lobby.Req.ReturnDashboard,
            Lobby.Req.AddBot, Lobby.Req.SetReady
        {
            record Create(GameType gameType, boolean isPublic) implements Req {}
            record Join(LobbyID lobbyId, String joinCode) implements Req {}
            record List() implements Req {}
            record Leave() implements Req {}
            record Rematch() implements Req {}
            record ReturnLobby() implements Req {}
            record ReturnDashboard() implements Req {}
            record Start() implements Req {}
            /** Bot AI strength 1 (weakest)–10 (strongest). Server clamps to that range. */
            record AddBot(int difficulty) implements Req {}
            /** In the waiting room: mark yourself ready / not ready before the host can start. */
            record SetReady(boolean ready) implements Req {}
        }

        sealed interface Res extends Lobby, Response permits
            Lobby.Res.Create, Lobby.Res.Join, Lobby.Res.List,
            Lobby.Res.Leave, Lobby.Res.Start, Lobby.Res.RematchVote,
            Lobby.Res.AllReady, Lobby.Res.ReturnedLobby, Lobby.Res.ReturnedDashboard,
            Lobby.Res.PlayerReady, Lobby.Res.LobbyUpdated,
            Lobby.Res.PlayerDisconnected,
            Error, Compound
        {
            record Create(LobbyRoom lobby) implements Res {}
            record Join(UserID playerJoin, LobbyRoom lobby, LobbyJoinResponse joinRes) implements Res, Pushable {}
            record List(LobbyRoom[] lobbies) implements Res {}
            record Leave() implements Res {}
            record RematchVote(UserID player) implements Res, Pushable {}
            record AllReady() implements Res, Pushable {}
            record LobbyUpdated(LobbyRoom lobby) implements Res, Pushable {}
            /** Current lobby snapshot when returning from post-game to the waiting room. */
            record ReturnedLobby(LobbyRoom lobby) implements Res {}
            record ReturnedDashboard() implements Res {}
            record Start() implements Res, Pushable {}
            record PlayerReady(UserID playerId, boolean ready) implements Res, Pushable {}
            record PlayerDisconnected(UserID disconnectedPlayer, boolean lobbyDissolved) implements Res {}
        }
    }

    /*
     * Game
     */
    sealed interface Game extends Payload permits Game.Req, Game.Res {
        sealed interface Req extends Game, Protected permits
            Game.Req.Move, Game.Req.State, Game.Req.Chat,
            Game.Req.Resign, Game.Req.DrawOffer, Game.Req.DrawRespond
        {
            record State() implements Req {}
            record Move(GameMove move) implements Req {}
            record Chat(String message) implements Req {}
            record Resign() implements Req {}
            record DrawOffer() implements Req {}
            record DrawRespond(boolean accept) implements Req {}
        }

        sealed interface Res extends Game, Response permits
            Game.Res.Move, Game.Res.State, Game.Res.Chat,
            Game.Res.DrawOfferPending, Game.Res.DrawDeclined,
            Error, Compound
        {
            record State(GameAbstract<?> game) implements Res {}
            record Move(
                    UserID playerMove,
                    GameMove move,
                    UserID newCurrentPlayer,
                    MoveResult result
            ) implements Res, Pushable {}
            record Chat(UserID userChat, String message) implements Res, Pushable {}
            record DrawOfferPending(UserID from) implements Res, Pushable {}
            record DrawDeclined(UserID by) implements Res, Pushable {}
        }
    }

    record Compound(Response[] responses) implements Lobby.Res, Game.Res {}

    /*
     * Matchmaking
     */
    sealed interface Matchmaking extends Payload permits Matchmaking.Req, Matchmaking.Res {
        sealed interface Req extends Matchmaking, Protected permits
                Matchmaking.Req.Join, Matchmaking.Req.Leave
        {
            record Join(GameType gameType) implements Req {}
            record Leave(GameType gameType) implements Req {}
        }

        sealed interface Res extends Matchmaking, Response permits
                Matchmaking.Res.Queued, Matchmaking.Res.Matched,
                Matchmaking.Res.Left, Error
        {
            record Queued() implements Res {}
            /** {@code lobby} is the full room after the server placed both players (do not send another Join). */
            record Matched(LobbyID lobbyId, UserID opponentId, LobbyRoom lobby) implements Res {}
            record Left() implements Res {}
        }
    }

    /*
     * Profile
     */
    sealed interface Profile extends Payload permits Profile.Req, Profile.Res {
        sealed interface Req extends Profile, Protected permits
                Profile.Req.Get, Profile.Req.Stats
        {
            record Get() implements Req {}
            record Stats() implements Req {}
        }

        sealed interface Res extends Profile, Response permits
                Profile.Res.Get, Profile.Res.Stats, Error
        {
            record Get(UserProfile profile) implements Res {}
            record Stats(PlayerStats stat, ArrayList<MatchHistoryEntry> matchHistory) implements Res {}
        }
    }

    /*
     * Leaderboard
     */
    sealed interface Leaderboard extends Payload permits Leaderboard.Req, Leaderboard.Res {
        sealed interface Req extends Leaderboard, Protected permits
                Leaderboard.Req.Get
        {
            record Get(GameType gameType, int topN) implements Req {}
        }

        sealed interface Res extends Leaderboard, Response permits
                Leaderboard.Res.Get, Error
        {
            record Get(ArrayList<LeaderboardExport> entries) implements Res {}
        }
    }

    /*
     * Generic error
     */
    record Error(String message) implements
            Auth.Res, Lobby.Res, Game.Res, Matchmaking.Res,
            Profile.Res, Leaderboard.Res, Request {}
}
