package ca.ucalgary.seng300.network;

import ca.ucalgary.seng300.Config;
import ca.ucalgary.seng300.database.AccountDatabase;
import ca.ucalgary.seng300.database.Database;
import ca.ucalgary.seng300.database.LeaderboardDatabase;
import ca.ucalgary.seng300.database.LobbyDatabase;

import java.io.*;
import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import ca.ucalgary.seng300.logger.Logging;
import ca.ucalgary.seng300.network.handler.server.AuthHandler;
import ca.ucalgary.seng300.network.handler.server.ErrorHandler;
import ca.ucalgary.seng300.network.handler.server.GameHandler;
import ca.ucalgary.seng300.network.handler.server.LeaderboardHandler;
import ca.ucalgary.seng300.network.handler.server.LobbyHandler;
import ca.ucalgary.seng300.network.handler.server.MatchmakingHandler;
import ca.ucalgary.seng300.network.handler.server.ProfileHandler;
import ca.ucalgary.seng300.network.message.Payload;
import ca.ucalgary.seng300.network.message.Payload.Compound;
import ca.ucalgary.seng300.network.message.Payload.Direct;
import ca.ucalgary.seng300.network.message.Payload.Lobby;
import ca.ucalgary.seng300.network.message.Payload.Request;
import ca.ucalgary.seng300.network.message.Payload.Response;
import ca.ucalgary.seng300.network.message.ServerRouter;
import ca.ucalgary.seng300.platformcore.LobbyID;
import ca.ucalgary.seng300.platformcore.LobbyManager;
import ca.ucalgary.seng300.platformcore.LobbyRoom;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.validation.account.records.UserID;

public class Server {
    private final Set<ClientData> clients = ConcurrentHashMap.newKeySet();
    private static final Logger logger = Logging.getLogger("NetworkServer");
    private final ServerRouter router = new ServerRouter();

    private final AccountDatabase accountDatabase = Database.getInstance(AccountDatabase.class);
    private final LeaderboardDatabase leaderboardDatabase = Database.getInstance(LeaderboardDatabase.class);
    private final LobbyDatabase lobbyDatabase = Database.getInstance(LobbyDatabase.class);

    public Server() {
        try {
            String ip = Util.getLocalIP();
            if (!ip.isEmpty()) {
                logger.info("Server public IP: " + ip);
            } else {
                logger.warning("Could not determine server IP address");
            }
        } catch (IOException e) {
            logger.warning("Error determining server IP address: " + e.getMessage());
        }

        accountDatabase.connect();
        lobbyDatabase.connect();
        leaderboardDatabase.connect();

        router.register(new AuthHandler(accountDatabase, leaderboardDatabase));
        router.register(new LobbyHandler(lobbyDatabase));
        router.register(new MatchmakingHandler(lobbyDatabase));
        router.register(new ErrorHandler());
        router.register(new ProfileHandler(accountDatabase, leaderboardDatabase));
        router.register(new GameHandler(lobbyDatabase, leaderboardDatabase));
        router.register(new LeaderboardHandler(leaderboardDatabase, accountDatabase));
    }

    public void start() throws Exception {
        start(null);
    }

    public void start(Runnable onReady) throws Exception {
        new Thread(this::runDiscovery, "udp-discovery").start();
        runGameServer(onReady);
    }

    public void send(ObjectOutputStream out, Response res) throws IOException {
        synchronized (out) {
            out.reset();
            out.writeObject(res);
            out.flush();
        }
    }

    private void pushToUser(UserID target, Response payload) {
        for (ClientData client : clients) {
            if (client.getPlayer() != null && client.getPlayer().getID().equals(target)) {
                try {
                    send(client.getOutStream(), payload);
                } catch (IOException e) {
                    logger.warning("Failed to push to player " + target);
                }
                return;
            }
        }
        logger.warning("No connected client found for target " + target);
    }

    private void broadcast(LobbyID lobbyId, Response payload, UserID exclude) {
        if (lobbyId == null) {
            logger.warning("broadcast called with null lobbyId; skipping");
            return;
        }
        logger.info("Broadcasting to lobby " + lobbyId + ": " + payload);
        LobbyManager lobbyManager = lobbyDatabase.getData();
        for (ClientData client : clients) {
            if (client.getPlayer() == null) {
                continue;
            }
            UserID clientId = client.getPlayer().getID();
            if ((exclude == null || !clientId.equals(exclude))
                    && lobbyManager.IsPlayerInLobby(lobbyId, clientId)) {
                try {
                    send(client.getOutStream(), payload);
                } catch (IOException e) {
                    logger.warning("Failed to broadcast to a client");
                }
            }
        }
    }

    private void dispatchResponses(Response res, ClientData clientData, ObjectOutputStream out)
            throws IOException {
        Response[] responses = res instanceof Compound c ? c.responses() : new Response[]{res};
        Player player = clientData.getPlayer();
        LobbyManager lobbyManager = lobbyDatabase.getData();
        for (Response r : responses) {
            switch (r) {
                case Response.Pushable p -> {
                    LobbyID lid = null;
                    if (p instanceof Lobby.Res.LobbyUpdated lu) {
                        lid = lu.lobby().getID();
                    } else if (p instanceof Lobby.Res.Join j) {
                        lid = j.lobby().getID();
                    } else if (player != null) {
                        lid = player.getLobbyId();
                        if (lid == null) {
                            LobbyRoom room = lobbyManager.getLobbyContainingPlayer(player.getID());
                            if (room != null) {
                                lid = room.getID();
                            }
                        }
                    }
                    if (lid == null) {
                        logger.warning("Pushable with no lobby id; sending direct to requester");
                        send(out, p);
                    } else {
                        broadcast(lid, p, null);
                    }
                }
                case Response.Direct d -> pushToUser(d.target(), d.payload());
                default -> send(out, r);
            }
        }
    }

    private void runDiscovery() {
        try (DatagramSocket socket = new DatagramSocket(Config.DISCOVERY_PORT)) {
            socket.setBroadcast(true);
            byte[] buf = new byte[256];
            logger.info("UDP Discovery listening on port: " + Config.DISCOVERY_PORT);

            while (true) {
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);

                String msg = new String(packet.getData(), 0, packet.getLength()).trim();
                if (msg.equals(Config.CLIENT_DISCOVERY_MESSAGE)) {
                    byte[] reply = Config.SERVER_REPLY_DISCOVERY.getBytes();
                    socket.send(new DatagramPacket(reply, reply.length, packet.getAddress(), packet.getPort()));
                    logger.info("Received discovery from " + packet.getAddress() + ", replied with server info");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void runGameServer(Runnable onReady) throws IOException {
        ExecutorService pool = Executors.newCachedThreadPool();

        try (ServerSocket server = new ServerSocket(Config.GAME_PORT)) {
            logger.info("Game server listening on TCP port: " + Config.GAME_PORT);
            if (onReady != null) {
                onReady.run();
            }
            while (true) {
                Socket client = server.accept();
                logger.info("Client connected: " + client.getInetAddress());
                pool.execute(() -> {
                    Thread.currentThread().setName("client-" + client.getInetAddress());
                    handleClient(client);
                });
            }
        }
    }

    private void handleClient(Socket client) {
        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        ClientData clientData = null;

        try {
            in = new ObjectInputStream(client.getInputStream());
            out = new ObjectOutputStream(client.getOutputStream());
            client.setTcpNoDelay(true);
            client.setKeepAlive(true);

            clientData = new ClientData(out);
            clients.add(clientData);

            while (true) {
                final Request req;
                try {
                    Object obj = in.readObject();
                    if (!(obj instanceof Request r)) {
                        logger.warning("Received invalid payload from client: " + obj.getClass());
                        continue;
                    }
                    req = r;
                } catch (EOFException e) {
                    logger.info("Client disconnected (EOF): " + client.getInetAddress());
                    break;
                } catch (ClassNotFoundException e) {
                    logger.log(Level.WARNING, "Unknown serialized type from client", e);
                    continue;
                } catch (IOException e) {
                    logger.info("Client read ended: " + client.getInetAddress() + " — " + e.getMessage());
                    break;
                }

                logger.info("Received: " + req);

                if (req instanceof Payload.Protected && clientData.getPlayer() == null) {
                    logger.warning("User is not authenticated, rejecting request");
                    try {
                        send(out, new Payload.Error("Authentication required"));
                    } catch (IOException e) {
                        break;
                    }
                    continue;
                }

                try {
                    Response res = router.route(req, clientData);
                    logger.info("Responding with: " + res);
                    dispatchResponses(res, clientData, out);
                } catch (IOException e) {
                    logger.info("Client write failed, closing connection: " + e.getMessage());
                    break;
                } catch (Exception e) {
                    logger.log(Level.WARNING, "Request handling failed: " + req.getClass().getSimpleName(), e);
                    logger.severe(e.getMessage());
                    try {
                        send(out, new Payload.Error("Server error"));
                    } catch (IOException io) {
                        break;
                    }
                }
            }
        } catch (IOException e) {
            logger.warning("Client I/O failed: " + client.getInetAddress() + " — " + e.getMessage());
        } finally {
            Player player = (clientData != null) ? clientData.getPlayer() : null;

            if (player != null) {
                try {
                    GameHandler gh = router.getHandler(GameHandler.class);
                    if (gh != null) gh.handleDisconnect(player);
                } catch (Exception e) {
                    logger.warning("Game disconnect cleanup failed: " + e.getMessage());
                }

                try {
                    LobbyHandler lh = router.getHandler(LobbyHandler.class);
                    if (lh != null) {
                        for (Response r : lh.handleDisconnect(player)) {
                            if (r instanceof Direct d) {
                                pushToUser(d.target(), d.payload());
                            }
                        }
                    }
                } catch (Exception e) {
                    logger.warning("Lobby disconnect cleanup failed: " + e.getMessage());
                }

                try {
                    MatchmakingHandler mm = router.getHandler(MatchmakingHandler.class);
                    if (mm != null) mm.unregisterPlayer(player);
                } catch (Exception e) {
                    logger.warning("Matchmaking disconnect cleanup failed: " + e.getMessage());
                }
            }

            if (out != null) {
                final ObjectOutputStream outFinal = out;
                clients.removeIf(c -> c.getOutStream() == outFinal);
            }
            try {
                client.close();
            } catch (IOException ignored) {
            }
        }
    }

    public static void main(String[] args) throws Exception {
        Server server = new Server();
        server.start();
    }
}
