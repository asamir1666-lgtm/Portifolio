package ca.ucalgary.seng300;

import ca.ucalgary.seng300.leaderboard.LeaderboardEntry;
import ca.ucalgary.seng300.leaderboard.LeaderboardStubData;
import ca.ucalgary.seng300.leaderboard.SeasonProgress;
import ca.ucalgary.seng300.leaderboard.UserStats;
import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;

import java.util.List;

public class Bridge extends BridgeBase {
    public Bridge(WebEngine engine) {
        super(engine);
    }

    public void attachBridge() {
        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.SUCCEEDED) {
                JSObject window = (JSObject) engine.executeScript("window");
                window.setMember("bridge", this);
            }
        });
    }

    public void navigateTo(String page) {
        var resource = getClass().getResource("/ca/ucalgary/seng300/views/" + page);

        if (resource == null) {
            System.out.println("Could not find page: " + page);
            return;
        }

        String url = resource.toExternalForm();
        Platform.runLater(() -> engine.load(url));
    }

    public void setUsername(String username){
        engine.executeScript("updateDashboardUI('" + username + "')");
    }

    public void log(String message) {
        System.out.println("[JS]: " + message);
    }

    public void handleNavigation(String action) {
        Platform.runLater(() -> {
            switch (action) {
                case "PROFILE":
                    navigateTo("view-profile.html");
                    break;
                case "LOBBY":
                    navigateTo("lobbyCreateMatch.html");
                    break;
                case "LEADERBOARD":
                    navigateTo("leaderboard.html");
                    break;
                case "LOGOUT":
                    navigateTo("login-signup.html");
                    break;
                case "WAITINGROOM":
                    navigateTo("waitingRoom.html");
                    break;
                case "CANCEL":
                    navigateTo("lobbyCreateMatch.html");
                    break;
                case "RETURNPRIVATE":
                    navigateTo("lobbyPrivate.html");
                    break;
                case "TICTACTOE":
                    navigateTo("tictactoe.html");
                    break;
                case "CONNECTFOUR":
                    navigateTo("connect4.html");
                    break;
                default:
                    navigateTo("dashboard.html");
                    engine.executeScript("window.alert('The page you want to go to doesnt exist')");
                    System.out.println("Unknown action: " + action);
            }
        });
    }

    public void sendUsernames(String u1, String u2) {
        engine.executeScript("startGame('" + u1 + "', '" + u2 + "')");
    }

    public void sendLeaderboardData() {
        List<LeaderboardEntry> entries = LeaderboardStubData.getLeaderboardEntries();
        engine.executeScript(
                "if(typeof renderLeaderboard==='function')renderLeaderboard("
                        + convertEntriesToJsArray(entries) + ");");
    }

    public void sendUserStats() {
        UserStats stats = LeaderboardStubData.getUserStats();
        engine.executeScript(
                "if(typeof setUserStats==='function')setUserStats(" + convertUserStatsToJsObject(stats) + ");");
    }

    public void sendSeasonProgress() {
        SeasonProgress progress = LeaderboardStubData.getSeasonProgress();
        engine.executeScript(
                "if(typeof setSeasonProgress==='function')setSeasonProgress("
                        + convertSeasonProgressToJsObject(progress) + ");");
    }

    private List<LeaderboardEntry> getLeaderboardEntries() {
        throw new UnsupportedOperationException("TODO: implement leaderboard entries retrieval from platform core");
    }

    private UserStats getUserStats() {
        throw new UnsupportedOperationException("TODO: implement user stats retrieval from platform core");
    }

    private SeasonProgress getSeasonProgress() {
        throw new UnsupportedOperationException("TODO: implement season progress retrieval from platform core");
    }

    private String convertEntriesToJsArray(List<LeaderboardEntry> entries) {
        StringBuilder sb = new StringBuilder("[");

        for (int i = 0; i < entries.size(); i++) {
            LeaderboardEntry entry = entries.get(i);

            sb.append("{")
                    .append("rank:").append(entry.getRank()).append(",")
                    .append("player:\"").append(escapeJs(entry.getPlayer())).append("\",")
                    .append("elo:").append(entry.getElo()).append(",")
                    .append("wins:").append(entry.getWins()).append(",")
                    .append("losses:").append(entry.getLosses()).append(",")
                    .append("winRate:\"").append(escapeJs(entry.getWinRate())).append("\"")
                    .append("}");

            if (i < entries.size() - 1) {
                sb.append(",");
            }
        }

        sb.append("]");
        return sb.toString();
    }

    private String convertUserStatsToJsObject(UserStats stats) {
        return "{"
                + "currentRank:\"" + escapeJs(stats.getCurrentRank()) + "\","
                + "eloRating:" + stats.getEloRating() + ","
                + "wins:" + stats.getWins() + ","
                + "losses:" + stats.getLosses() + ","
                + "winRate:\"" + escapeJs(stats.getWinRate()) + "\","
                + "totalGamesPlayed:" + stats.getTotalGamesPlayed()
                + "}";
    }

    private String convertSeasonProgressToJsObject(SeasonProgress progress) {
        return "{"
                + "nextRank:\"" + escapeJs(progress.getNextRank()) + "\","
                + "eloNeeded:" + progress.getEloNeeded() + ","
                + "seasonEndsIn:\"" + escapeJs(progress.getSeasonEndsIn()) + "\""
                + "}";
    }

    private String escapeJs(String value) {
        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");
    }


    public void renderLoginUI() {
        navigateTo("login-signup.html");
    }

    public void renderManageProfileUI() {
        navigateTo("ManageProfile.html");
    }


    public void onSaveProfile(String username, String email,
                              String currentPassword, String newPassword, String confirmPassword) {
        System.out.println("Save Profile clicked: " + username);
    }
}
