package ca.ucalgary.seng300.network.handler.client;

import ca.ucalgary.seng300.network.message.Payload.Error;
import ca.ucalgary.seng300.network.message.Payload.Matchmaking.Req;
import ca.ucalgary.seng300.network.message.Payload.Matchmaking.Res;
import ca.ucalgary.seng300.platformcore.GameType;

import java.util.Objects;
import java.util.function.Consumer;

// Client-side handler for matchmaking responses from the server.
// UI team: set callbacks before calling client.connect(), then use the
// convenience methods to send requests

public class MatchmakingHandler extends ClientHandler<Res> {

    private Consumer<Res.Queued>  onQueued;
    private Consumer<Res.Matched> onMatched;
    private Consumer<Res.Left>    onLeft;
    private Consumer<Error>       onError;

    public void setOnQueued  (Consumer<Res.Queued> cb)  { this.onQueued  = cb; }
    public void setOnMatched (Consumer<Res.Matched> cb) { this.onMatched = cb; }
    public void setOnLeft    (Consumer<Res.Left> cb)    { this.onLeft    = cb; }
    public void setOnError   (Consumer<Error> cb)       { this.onError   = cb; }

    @Override
    public void handle(Res serverResponse) {
        switch (serverResponse) {
            case Res.Queued r  -> onQueued.accept(r);
            case Res.Matched r -> onMatched.accept(r);
            case Res.Left r    -> onLeft.accept(r);
            case Error e       -> onError.accept(e);
        }
    }

    // Sends a request to join the matchmaking queue for the given game type.
    // The server will reply with either Res.Queued (waiting) or Res.Matched (match found).
    public void joinQueue(GameType gameType) {
        this.sender.accept(new Req.Join(gameType));
    }

    // Sends a request to leave the matchmaking queue.
    // The server will reply with Res.Left to confirm removal.
    public void leaveQueue(GameType gameType) {
        this.sender.accept(new Req.Leave(gameType));
    }

    @Override
    public void validate() {
        Objects.requireNonNull(onQueued,  "MatchmakingHandler: onQueued not set");
        Objects.requireNonNull(onMatched, "MatchmakingHandler: onMatched not set");
        Objects.requireNonNull(onLeft,    "MatchmakingHandler: onLeft not set");
        Objects.requireNonNull(onError,   "MatchmakingHandler: onError not set");
    }
}