package ca.ucalgary.seng300.network.handler.server;

import ca.ucalgary.seng300.network.ClientData;
import ca.ucalgary.seng300.network.message.Payload.Request;
import ca.ucalgary.seng300.network.message.Payload.Response;

public abstract class ServerHandler<Req extends Request, Res extends Response> {
    public abstract Res handle(Req payload, ClientData clientData);
}