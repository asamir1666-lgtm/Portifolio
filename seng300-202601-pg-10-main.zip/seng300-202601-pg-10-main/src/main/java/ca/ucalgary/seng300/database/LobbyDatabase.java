package ca.ucalgary.seng300.database;

import ca.ucalgary.seng300.Config;
import ca.ucalgary.seng300.platformcore.LobbyRoom;
import ca.ucalgary.seng300.platformcore.LobbyManager;

public class LobbyDatabase extends Database<LobbyManager> {
    private LobbyDatabase() { super(Config.LOBBY_FILE); }

    @Override
    protected LobbyManager getDefaultData() {
        return LobbyManager.getInstance();
    }
}
