package ca.ucalgary.seng300.database;

import ca.ucalgary.seng300.Config;

/**
 * Client-side store for saved logins
 */
public class SessionStore extends Database<SessionAccounts> {
    private SessionStore() {
        super(Config.SESSION_ACCOUNTS_FILE);
    }

    @Override
    protected SessionAccounts getDefaultData() {
        return new SessionAccounts();
    }
}
