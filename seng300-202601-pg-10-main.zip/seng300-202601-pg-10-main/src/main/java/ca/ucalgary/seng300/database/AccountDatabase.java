package ca.ucalgary.seng300.database;

import ca.ucalgary.seng300.Config;
import ca.ucalgary.seng300.validation.account.AccountDatabaseManager;
import ca.ucalgary.seng300.validation.account.AccountValidation;
import ca.ucalgary.seng300.validation.account.stubs.CredentialsStoreStub;
import ca.ucalgary.seng300.validation.account.stubs.TokenManager;

public class AccountDatabase extends Database<AccountDatabaseManager> {
    private AccountDatabase() { super(Config.ACCOUNT_FILE); }

    @Override
    protected AccountDatabaseManager getDefaultData() {
        return new AccountDatabaseManager(
        	new AccountValidation(new CredentialsStoreStub(), new TokenManager())
        );
    }
}
