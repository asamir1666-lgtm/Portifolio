package ca.ucalgary.seng300.validation.account.results;

import ca.ucalgary.seng300.validation.account.enums.AccountErrorCode;

public class OperationResult {
    public boolean success;
    public String message;
    public AccountErrorCode errorCode;

    public OperationResult(boolean success, String message, AccountErrorCode errorCode) {
        this.success = success;
        this.message = message;
        this.errorCode = errorCode;
    }

    public static OperationResult success() {
        return new OperationResult(true, null, null);
    }

    public static OperationResult failure(String message, AccountErrorCode errorCode) {
        return new OperationResult(false, message, errorCode);
    }
}
