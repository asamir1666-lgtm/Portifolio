package ca.ucalgary.seng300.platformcore.game.connectfour;

import ca.ucalgary.seng300.platformcore.game.MoveResult;
import ca.ucalgary.seng300.validation.account.records.UserID;

public class ConnectFourResult extends MoveResult {
    private final int col;

    private ConnectFourResult(boolean accepted, String errorMessage,
                              boolean hasWinner, boolean isDraw,
                              UserID winnerID, UserID loserID,
                              int col) {
        super(accepted, errorMessage, hasWinner, isDraw, winnerID, loserID);
        this.col = col;
    }

    public static ConnectFourResult error(int col, String errorMessage) {
        return new ConnectFourResult(false, errorMessage, false, false, null, null, col);
    }

    public static ConnectFourResult ongoing(int col) {
        return new ConnectFourResult(true, null, false, false, null, null, col);
    }

    public static ConnectFourResult draw(int col) {
        return new ConnectFourResult(true, null, false, true, null, null, col);
    }

    public static ConnectFourResult gameOver(int col, UserID winnerID, UserID loserID) {
        return new ConnectFourResult(true, null, true, false, winnerID, loserID, col);
    }

    public int getCol() { return col; }
}
