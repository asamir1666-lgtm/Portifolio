package ca.ucalgary.seng300.platformcore;

import java.io.Serializable;
import java.util.Map;

import ca.ucalgary.seng300.Config;

public class PlayerStats implements Serializable {
    private static final long serialVersionUID = 1L;
    private final Map<GameType, GameStats> statsPerGame;

    public PlayerStats() {
    	this.statsPerGame = new java.util.EnumMap<>(GameType.class);
		for (GameType type : GameType.values())
        {
            statsPerGame.put(type, new GameStats(Config.DEFAULT_ELO));
        }
	}

	public void setGameStats(GameType gameType, GameStats stats) {
		statsPerGame.put(gameType, stats);
	}

	public GameStats getStatsForGame(GameType gameType) {
		return statsPerGame.get(gameType);
	}

	public void updateStatsForGame(GameType gameType, GameStats newStats) {
		statsPerGame.put(gameType, newStats);
	}
}
