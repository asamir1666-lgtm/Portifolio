package ca.ucalgary.seng300.leaderboard;

//will need to change class name depending on platform core
public class LeaderboardEntry {
    private final int rank;
    private final String player;
    private final int elo;
    private final int wins;
    private final int losses;
    private final String winRate;

    public LeaderboardEntry(int rank, String player, int elo, int wins, int losses, String winRate) {
        this.rank = rank;
        this.player = player;
        this.elo = elo;
        this.wins = wins;
        this.losses = losses;
        this.winRate = winRate;
    }

    public int getRank() {
        return rank;
    }

    public String getPlayer() {
        return player;
    }

    public int getElo() {
        return elo;
    }

    public int getWins() {
        return wins;
    }

    public int getLosses() {
        return losses;
    }

    public String getWinRate() {
        return winRate;
    }
}
