package ca.ucalgary.seng300.platformcore.game;

import java.io.Serializable;

public class GridSpace implements Serializable {
    private static final long serialVersionUID = 1L;

    public int row;
    public int column;

    public GridSpace(int row, int column) {
        this.row = row;
        this.column = column;
    }

    public String toString() {
        return row + ", " + column;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof GridSpace other)) {
            return false;
        }
        return row == other.row && column == other.column;
    }

    @Override
    public int hashCode() {
        return 31 * row + column;
    }
}
