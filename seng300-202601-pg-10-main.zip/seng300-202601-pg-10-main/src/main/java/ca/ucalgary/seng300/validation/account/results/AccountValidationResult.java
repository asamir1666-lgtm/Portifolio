package ca.ucalgary.seng300.validation.account.results;

import ca.ucalgary.seng300.validation.account.enums.AccountErrorCode;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;
import ca.ucalgary.seng300.validation.account.stubs.UserProfile;

public class AccountValidationResult extends ValidationResult {
    public UserProfile userProfile;
    public SessionToken token;

    public AccountValidationResult(boolean isValid, AccountErrorCode errorCode, String message, UserProfile userProfile, SessionToken token) {
        super(isValid, errorCode, message);
        this.userProfile = userProfile;
        this.token = token;
    }
}
