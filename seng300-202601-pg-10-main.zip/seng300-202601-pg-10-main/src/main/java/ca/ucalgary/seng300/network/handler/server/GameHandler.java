package ca.ucalgary.seng300.network.handler.server;

import ca.ucalgary.seng300.network.message.Payload.Game.Res;
import ca.ucalgary.seng300.network.message.Payload.Game.Req;
import ca.ucalgary.seng300.network.message.Payload.Error;
import ca.ucalgary.seng300.network.message.Payload.Compound;
import ca.ucalgary.seng300.platformcore.LobbyID;
import ca.ucalgary.seng300.platformcore.LobbyRoom;
import ca.ucalgary.seng300.platformcore.Bot;
import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.LobbyManager;
import ca.ucalgary.seng300.platformcore.LobbyState;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.platformcore.PlayerState;
import ca.ucalgary.seng300.platformcore.game.GameAbstract;
import ca.ucalgary.seng300.platformcore.game.GameMove;
import ca.ucalgary.seng300.platformcore.game.GridSpace;
import ca.ucalgary.seng300.platformcore.game.MoveResult;
import ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourMove;
import ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourPiece;
import ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToeMove;
import ca.ucalgary.seng300.platformcore.Leaderboard;
import ca.ucalgary.seng300.platformcore.MatchHistoryEntry;
import ca.ucalgary.seng300.platformcore.MatchResult;
import ca.ucalgary.seng300.platformcore.EloCalculator;
import ca.ucalgary.seng300.database.LobbyDatabase;
import ca.ucalgary.seng300.database.LeaderboardDatabase;
import ca.ucalgary.seng300.network.ClientData;
import ca.ucalgary.seng300.validation.account.records.UserID;

import java.util.ArrayList;
import java.util.Optional;
import java.util.logging.Logger;

import ca.ucalgary.seng300.logger.Logging;

public class GameHandler extends ServerHandler<Req, Res> {
    private static final Logger logger = Logging.getLogger("GameHandler");
    private final LobbyDatabase lobbyDatabase;
    private final LeaderboardDatabase leaderboardDatabase;

    public GameHandler(LobbyDatabase lobbyDatabase, LeaderboardDatabase leaderboardDatabase) {
        this.lobbyDatabase = lobbyDatabase;
        this.leaderboardDatabase = leaderboardDatabase;
    }
    
    @Override
    public Res handle(Req req, ClientData clientData) {
        return switch (req) {
            case Req.State r        -> handleState(r, clientData);
            case Req.Move r         -> handleMove(r, clientData);
            case Req.Chat r         -> chatMessageHandler(r, clientData);
            case Req.Resign r       -> handleResign(r, clientData);
            case Req.DrawOffer r    -> handleDrawOffer(r, clientData);
            case Req.DrawRespond r  -> handleDrawRespond(r, clientData);
        };
    }

    private Res chatMessageHandler(Req.Chat chat, ClientData clientData) {
        Player player = clientData.getPlayer();
        if (player == null) {
            return new Error("Player not found.");
        }
        return new Res.Chat(player.getID(), chat.message());
    }

    private GameMove preprocessMove(GameMove move, GameAbstract<?> game, Player player) {
        return switch (game.getGameType()) {
            case TICTACTOE      -> new TicTacToeMove(move.getPos());
            case CONNECTFOUR    -> {
                ConnectFourPiece piece = (ConnectFourPiece) game.getPlayerPieceMapping().get(player.getID());
                yield new ConnectFourMove(move.getPos(), piece);
            }
        };
    }

    private GameMove sentinelMoveForTerminal(GameType gameType) {
        return switch (gameType) {
            case TICTACTOE -> new GameMove(new GridSpace(-1, -1));
            case CONNECTFOUR -> new GameMove(new GridSpace(0, -1));
        };
    }

    private Res handleResign(Req.Resign req, ClientData clientData) {
        Player player = clientData.getPlayer();
        if (player == null) {
            return new Error("Player not found.");
        }
        LobbyID lid = player.getLobbyId();
        if (lid == null) {
            return new Error("Not in a game");
        }
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby;
        try {
            lobby = manager.getLobby(lid);
        } catch (IllegalArgumentException e) {
            return new Error("Not in a game");
        }
        GameAbstract<?> lobbyGame = lobby.getGame();
        if (lobbyGame == null) {
            return new Error("Game has not started yet");
        }
        GameType gameType = lobbyGame.getGameType();
        MoveResult result = lobbyGame.resign(player);
        if (!result.isAccepted()) {
            return new Error(result.getErrorMessage());
        }
        applyGameOver(lobby, gameType, result);
        UserID nextId = result.getWinnerID() != null ? result.getWinnerID() : player.getID();
        GameMove move = sentinelMoveForTerminal(gameType);
        Res.Move moveResult = new Res.Move(
                player.getID(),
                preprocessMove(move, lobbyGame, player),
                nextId,
                result
        );
        lobbyDatabase.save();
        return moveResult;
    }

    private Res handleDrawOffer(Req.DrawOffer req, ClientData clientData) {
        Player player = clientData.getPlayer();
        if (player == null) {
            return new Error("Player not found.");
        }
        LobbyID lid = player.getLobbyId();
        if (lid == null) {
            return new Error("Not in a game");
        }
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby;
        try {
            lobby = manager.getLobby(lid);
        } catch (IllegalArgumentException e) {
            return new Error("Not in a game");
        }
        GameAbstract<?> lobbyGame = lobby.getGame();
        if (lobbyGame == null) {
            return new Error("Game has not started yet");
        }
        Optional<String> err = lobbyGame.tryOfferDraw(player);
        if (err.isPresent()) {
            return new Error(err.get());
        }
        lobbyDatabase.save();
        return new Res.DrawOfferPending(player.getID());
    }

    private Res handleDrawRespond(Req.DrawRespond req, ClientData clientData) {
        Player player = clientData.getPlayer();
        if (player == null) {
            return new Error("Player not found.");
        }
        LobbyID lid = player.getLobbyId();
        if (lid == null) {
            return new Error("Not in a game");
        }
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby;
        try {
            lobby = manager.getLobby(lid);
        } catch (IllegalArgumentException e) {
            return new Error("Not in a game");
        }
        GameAbstract<?> lobbyGame = lobby.getGame();
        if (lobbyGame == null) {
            return new Error("Game has not started yet");
        }
        GameType gameType = lobbyGame.getGameType();
        if (req.accept()) {
            MoveResult result = lobbyGame.acceptDraw(player);
            if (!result.isAccepted()) {
                return new Error(result.getErrorMessage());
            }
            applyGameOver(lobby, gameType, result);
            GameMove move = sentinelMoveForTerminal(gameType);
            Res.Move moveResult = new Res.Move(
                    player.getID(),
                    preprocessMove(move, lobbyGame, player),
                    player.getID(),
                    result
            );
            lobbyDatabase.save();
            return moveResult;
        }
        Optional<String> declineErr = lobbyGame.tryDeclineDraw(player);
        if (declineErr.isPresent()) {
            return new Error(declineErr.get());
        }
        lobbyDatabase.save();
        return new Res.DrawDeclined(player.getID());
    }

    private void applyGameOver(LobbyRoom lobby, GameType gameType, MoveResult result) {
        lobby.resetRematchState();
        lobby.setState(LobbyState.GAME_OVER);
        for (Player p : lobby.getPlayers()) {
            p.setState(PlayerState.POST_GAME);
        }
        finalizeMatchStats(lobby, gameType, result);
    }

    private void finalizeMatchStats(LobbyRoom lobby, GameType gameType, MoveResult result) {
        ArrayList<Player> players = lobby.getPlayers();
        if (players.size() < 2) {
            return;
        }
        Player p0 = players.get(0);
        Player p1 = players.get(1);
        Leaderboard lb = leaderboardDatabase.getData();
        long t = System.currentTimeMillis();

        if (result.isDraw()) {
            int old0 = p0.getGameStats(gameType).getEloRating();
            int old1 = p1.getGameStats(gameType).getEloRating();
            int[] newR = EloCalculator.newRatingsAfterGame(old0, old1, false, true);
            if (!p0.isBot()) {
                p0.recordResult(gameType, MatchResult.DRAW, newR[0]);
            }
            if (!p1.isBot()) {
                p1.recordResult(gameType, MatchResult.DRAW, newR[1]);
            }
            int after0 = p0.isBot() ? old0 : newR[0];
            int after1 = p1.isBot() ? old1 : newR[1];
            appendHistory(lb, p0, p1, gameType, MatchResult.DRAW, t, old0, after0);
            appendHistory(lb, p1, p0, gameType, MatchResult.DRAW, t, old1, after1);
        } else if (result.hasWinner()) {
            UserID winnerId = result.getWinnerID();
            if (winnerId == null) {
                return;
            }
            Player winner = lobby.getPlayer(winnerId);
            if (winner == null) {
                if (winnerId.equals(p0.getID())) {
                    winner = p0;
                } else if (winnerId.equals(p1.getID())) {
                    winner = p1;
                } else {
                    return;
                }
            }
            Player loser = null;
            for (Player p : players) {
                if (!p.equals(winner)) {
                    loser = p;
                    break;
                }
            }
            if (loser == null) {
                return;
            }
            int oldW = winner.getGameStats(gameType).getEloRating();
            int oldL = loser.getGameStats(gameType).getEloRating();
            int[] newR = EloCalculator.newRatingsAfterGame(oldW, oldL, true, false);
            if (!winner.isBot()) {
                winner.recordResult(gameType, MatchResult.WIN, newR[0]);
            }
            if (!loser.isBot()) {
                loser.recordResult(gameType, MatchResult.LOSS, newR[1]);
            }
            int afterW = winner.isBot() ? oldW : newR[0];
            int afterL = loser.isBot() ? oldL : newR[1];
            appendHistory(lb, winner, loser, gameType, MatchResult.WIN, t, oldW, afterW);
            appendHistory(lb, loser, winner, gameType, MatchResult.LOSS, t, oldL, afterL);
        }

        leaderboardDatabase.save();
    }

    private void appendHistory(Leaderboard lb, Player self, Player opponent, GameType gameType,
                               MatchResult outcome, long t, int eloBefore, int eloAfter) {
        if (self.isBot()) {
            return;
        }
        String opp = opponent.isBot() ? "Bot" : opponent.getUsername();
        lb.recordMatch(self.getID(), new MatchHistoryEntry(gameType, opp, outcome, t, eloBefore, eloAfter));
    }

    public void handleDisconnect(Player player) {
        if (player == null) return;
        LobbyID lid = player.getLobbyId();
        if (lid == null) return;

        LobbyManager mgr = lobbyDatabase.getData();
        LobbyRoom lobby = mgr.getLobbyOrNull(lid);
        if (lobby == null || lobby.getState() != LobbyState.IN_GAME) return;

        GameType gameType = lobby.getGameType();
        Player opponent = null;
        for (Player p : lobby.getPlayers()) {
            if (!p.equals(player)) {
                opponent = p;
                break;
            }
        }
        if (opponent == null) return;

        int rw = opponent.getGameStats(gameType).getEloRating();
        int rl = player.getGameStats(gameType).getEloRating();
        int[] newR = EloCalculator.newRatingsAfterGame(rw, rl, true, false);
        if (!opponent.isBot()) {
            opponent.recordResult(gameType, MatchResult.WIN, newR[0]);
        }
        if (!player.isBot()) {
            player.recordResult(gameType, MatchResult.LOSS, newR[1]);
        }
        int afterOpp = opponent.isBot() ? rw : newR[0];
        int afterPl = player.isBot() ? rl : newR[1];
        Leaderboard lb = leaderboardDatabase.getData();
        long t = System.currentTimeMillis();
        appendHistory(lb, opponent, player, gameType, MatchResult.WIN, t, rw, afterOpp);
        appendHistory(lb, player, opponent, gameType, MatchResult.LOSS, t, rl, afterPl);
        leaderboardDatabase.save();
    }

    public Res handleMove(Req.Move req, ClientData clientData) {
        Player player = clientData.getPlayer();
        if (player == null) {
            return new Error("Player not found.");
        }
        LobbyID lid = player.getLobbyId();
        if (lid == null) {
            return new Error("Not in a game");
        }
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby;
        try {
            lobby = manager.getLobby(lid);
        } catch (IllegalArgumentException e) {
            return new Error("Not in a game");
        }
        GameAbstract<?> lobbyGame = lobby.getGame();
        if (lobbyGame == null) {
            return new Error("Game has not started yet");
        }
        GameType gameType = lobbyGame.getGameType();
        
        MoveResult result = lobbyGame.makeMove(req.move(), player);
        if (!result.isAccepted()){
            return new Error("Invalid move");
        }
        Player nextPlayer = lobbyGame.getCurrentPlayer();

        boolean terminal = result.hasWinner() || result.isDraw();
        if (terminal) {
            applyGameOver(lobby, gameType, result);
        }

        GameMove moveToSend = preprocessMove(req.move(), lobbyGame, player);
        Res.Move moveResult = new Res.Move(
            player.getID(),
            moveToSend,
            nextPlayer.getID(),
            result
        );

        Res.Move botRes = null;
        if (!terminal && nextPlayer.isBot()) {
            GameMove botMove = ((Bot) nextPlayer).makeMove(lobbyGame.getGameState(), player);
            MoveResult botResult = lobbyGame.makeMove(botMove, nextPlayer);

            if (botResult.isAccepted()) {
                GameMove botMoveToSend = preprocessMove(botMove, lobbyGame, nextPlayer);
                boolean botTerminal = botResult.hasWinner() || botResult.isDraw();
                if (botTerminal) {
                    applyGameOver(lobby, gameType, botResult);
                }
                botRes = new Res.Move(
                    nextPlayer.getID(),
                    botMoveToSend,
                    lobbyGame.getNextPlayer().getID(),
                    botResult
                );
            } else {
                logger.severe("Bot move was rejected. Bot: "
                        + nextPlayer.getID() + ", move: " + botMove);
            }
        }

        lobbyDatabase.save();
        if (botRes != null) {
            return new Compound(new Res[] { moveResult, botRes });
        }
        return moveResult;
    }

    public Res handleState(Req.State req, ClientData clientData) {
        Player player = clientData.getPlayer();
        if (player == null) {
            return new Error("Player not found.");
        }
        LobbyID lobbyId = player.getLobbyId();
        if (lobbyId == null) {
            return new Error("Not in a game");
        }
        LobbyManager manager = lobbyDatabase.getData();
        LobbyRoom lobby;
        try {
            lobby = manager.getLobby(lobbyId);
        } catch (IllegalArgumentException e) {
            return new Error("Not in a game");
        }
        GameAbstract<?> lobbyGame = lobby.getGame();

        if (lobbyGame == null) {
            return new Error("Game has not started yet");
        }

        return new Res.State(lobbyGame);
    }
}
