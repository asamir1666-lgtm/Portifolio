package ca.ucalgary.seng300.platformcore.game;

import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.gamevalidation.GameValidation;
import ca.ucalgary.seng300.validation.gamevalidation.results.WinValidationResult;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Optional;

public abstract class GameAbstract<P extends Piece> implements Serializable {
    private static final long serialVersionUID = 1L;
    private final GameType gameType;
    private final int rowSize;
    private final int colSize;
    protected final Board board;
    protected final Player[] players;
    protected final HashMap<UserID, P> playerPieceMapping = new HashMap<>();
    protected final GameValidation validator = new GameValidation();
    protected GameStatus status;
    protected Player currentPlayer;
    protected GameState gameState;
    protected String lastMoveError;
    protected UserID pendingDrawOfferFrom;

    protected GameAbstract(GameType gameType, int rowSize, int colSize, Player p1, Player p2) {
        this.gameType = gameType;
        this.rowSize = rowSize;
        this.colSize = colSize;
        this.players = new Player[]{p1, p2};
        this.board = new Board(rowSize, colSize);
        this.status = GameStatus.ONGOING;
        this.currentPlayer = p1;
    }

    public GameState getGameState() {
        return gameState;
    }

    public int getColSize() { return colSize; }
    public int getRowSize() { return rowSize; }
    public GameType getGameType() { return gameType; }
    public GameStatus getStatus() { return status; }
    public Player getCurrentPlayer() { return currentPlayer; }

    public HashMap<UserID, P> getPlayerPieceMapping() { return playerPieceMapping; }

    public Player[] getPlayers() { return players; }

    public abstract MoveResult makeMove(GameMove move, Player player);

    public Player getNextPlayer() {
        return (currentPlayer == players[0]) ? players[1] : players[0];
    }

    public Player hasWin() {
        if (status == GameStatus.PLAYER_ONE_WON) return players[0];
        if (status == GameStatus.PLAYER_TWO_WON) return players[1];
        return null;
    }

    protected void switchPlayer() {
        currentPlayer = getNextPlayer();
    }

    public Piece currentPlayerPiece() {
        return playerPieceMapping.get(currentPlayer.getID());
    }

    protected void clear() {
        for (int r = 0; r < rowSize; r++) {
            for (int c = 0; c < colSize; c++) {
                board.updateCell(r, c, null);
            }
        }
    }

    protected void updateState() {
        gameState = createGameState();
        WinValidationResult winResult = validator.validateWin(gameState, playerPieceMapping);
        if (winResult.hasWinner()) {
            status = (currentPlayer == players[0]) ? GameStatus.PLAYER_ONE_WON : GameStatus.PLAYER_TWO_WON;
            return;
        }
        if (winResult.isTie()) {
            status = GameStatus.DRAW;
            return;
        }
        status = GameStatus.ONGOING;
        switchPlayer();
    }

    protected Piece[][] copyBoard() {
        Piece[][] copy = new Piece[rowSize][colSize];
        for (int r = 0; r < rowSize; r++) {
            for (int c = 0; c < colSize; c++) {
                copy[r][c] = board.getCellPiece(r, c);
            }
        }
        return copy;
    }

    protected GameState createGameState() {
        return new GameState(
            gameType,
            new UserID[]{players[0].getID(), players[1].getID()},
            playerPieceMapping,
            copyBoard()
        );
    }

    protected boolean isPlayerInGame(Player player) {
        return player != null && (player.equals(players[0]) || player.equals(players[1]));
    }

    protected Player getPlayerById(UserID id) {
        if (id == null) {
            return null;
        }
        if (players[0].getID().equals(id)) {
            return players[0];
        }
        if (players[1].getID().equals(id)) {
            return players[1];
        }
        return null;
    }

    protected Player getOpponent(Player player) {
        if (player == null) {
            return null;
        }
        if (player.equals(players[0])) {
            return players[1];
        }
        if (player.equals(players[1])) {
            return players[0];
        }
        return null;
    }

    public MoveResult resign(Player player) {
        if (status != GameStatus.ONGOING) {
            return resignFailure("Game not active");
        }
        if (!isPlayerInGame(player)) {
            return resignFailure("Not a player");
        }
        pendingDrawOfferFrom = null;
        Player winner = getOpponent(player);
        status = GameStatus.QUIT;
        clear();
        return resignSuccess(winner.getID(), player.getID());
    }

    public Optional<String> tryOfferDraw(Player player) {
        if (status != GameStatus.ONGOING) {
            return Optional.of("Game not active");
        }
        if (!isPlayerInGame(player)) {
            return Optional.of("Not a player");
        }
        if (pendingDrawOfferFrom != null) {
            if (pendingDrawOfferFrom.equals(player.getID())) {
                return Optional.of("You already offered a draw");
            }
            return Optional.of("Respond to the pending draw offer first");
        }
        pendingDrawOfferFrom = player.getID();
        return Optional.empty();
    }

    public Optional<String> tryDeclineDraw(Player player) {
        if (pendingDrawOfferFrom == null) {
            return Optional.of("No draw offer pending");
        }
        Player offerer = getPlayerById(pendingDrawOfferFrom);
        if (offerer == null) {
            return Optional.of("Internal error");
        }
        if (!getOpponent(offerer).equals(player)) {
            return Optional.of("Only the opponent can respond");
        }
        pendingDrawOfferFrom = null;
        return Optional.empty();
    }

    public MoveResult acceptDraw(Player responder) {
        if (pendingDrawOfferFrom == null) {
            return drawFailure("No draw offer pending");
        }
        Player offerer = getPlayerById(pendingDrawOfferFrom);
        if (offerer == null || !getOpponent(offerer).equals(responder)) {
            return drawFailure("Only the opponent can accept");
        }
        pendingDrawOfferFrom = null;
        status = GameStatus.DRAW;
        return drawAgreedSuccess();
    }

    protected abstract MoveResult resignSuccess(UserID winner, UserID loser);
    protected abstract MoveResult resignFailure(String msg);
    protected abstract MoveResult drawAgreedSuccess();
    protected abstract MoveResult drawFailure(String msg);
}
