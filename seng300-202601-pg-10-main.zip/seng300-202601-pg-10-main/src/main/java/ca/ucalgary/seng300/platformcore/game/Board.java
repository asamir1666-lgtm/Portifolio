package ca.ucalgary.seng300.platformcore.game;

import java.io.Serializable;

public class Board implements Serializable {
    private static final long serialVersionUID = 1L;
    private final int rowSize;
    private final int colSize;
    private final Piece[][] grid;

    public Board(int rowSize, int colSize) {
        this.rowSize = rowSize;
        this.colSize = colSize;
        this.grid = new Piece[rowSize][colSize];
    }

    public int getRowSize() { return rowSize; }
    public int getColSize() { return colSize; }

    public void updateCell(int row, int col, Piece piece) {
        grid[row][col] = piece;
    }

    public Piece getCellPiece(int row, int col) {
        return grid[row][col];
    }
}
