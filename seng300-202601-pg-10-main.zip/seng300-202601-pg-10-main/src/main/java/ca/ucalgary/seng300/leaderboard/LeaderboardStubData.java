package ca.ucalgary.seng300.leaderboard;

import java.util.List;

public final class LeaderboardStubData {

    private LeaderboardStubData() {
    }

    public static List<LeaderboardEntry> getLeaderboardEntries() {
        return List.of(
                new LeaderboardEntry(1, "ShadowMaster", 2847, 1543, 287, "84.3%"),
                new LeaderboardEntry(2, "QuantumAce", 2792, 1421, 312, "82.0%"),
                new LeaderboardEntry(3, "NeonPhantom", 2741, 1388, 334, "80.6%"),
                new LeaderboardEntry(4, "BlazeFury", 2698, 1276, 358, "78.1%"),
                new LeaderboardEntry(5, "CyberVortex", 2654, 1198, 389, "75.5%"),
                new LeaderboardEntry(6, "DarkKnight87", 2612, 1142, 412, "73.5%"),
                new LeaderboardEntry(7, "EliteSniper", 2589, 1087, 441, "71.1%"),
                new LeaderboardEntry(8, "StormBreaker", 2543, 1034, 468, "68.8%"),
                new LeaderboardEntry(9, "TitanSlayer", 2512, 987, 493, "66.7%"),
                new LeaderboardEntry(10, "VoidWalker", 2487, 943, 521, "64.4%")
        );
    }

    public static UserStats getUserStats() {
        return new UserStats("#847", 1876, 234, 189, "55.3%", 423);
    }

    public static SeasonProgress getSeasonProgress() {
        return new SeasonProgress("#846", 12, "14 days");
    }
}