package ca.ucalgary.seng300.platformcore.game;

import java.io.Serializable;

import ca.ucalgary.seng300.validation.account.records.UserID;

public abstract class MoveResult implements Serializable {
    private static final long serialVersionUID = 1L;
    private final boolean accepted;
    private final String errorMessage;
    private final boolean hasWinner;
    private final boolean isDraw;
    private final UserID winnerID;
    private final UserID loserID;

    protected MoveResult(boolean accepted, String errorMessage,
                         boolean hasWinner, boolean isDraw,
                         UserID winnerID, UserID loserID) {
        this.accepted = accepted;
        this.errorMessage = errorMessage;
        this.hasWinner = hasWinner;
        this.isDraw = isDraw;
        this.winnerID = winnerID;
        this.loserID = loserID;
    }

    public boolean isAccepted() { return accepted; }
    public String getErrorMessage() { return errorMessage; }
    public boolean hasWinner() { return hasWinner; }
    public boolean isDraw() { return isDraw; }
    public UserID getWinnerID() { return winnerID; }
    public UserID getLoserID() { return loserID; }
}
