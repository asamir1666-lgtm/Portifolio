package ca.ucalgary.seng300.validation.gamevalidation.results;

import java.io.Serializable;

import ca.ucalgary.seng300.validation.gamevalidation.enums.ValidationErrorCode;

public class MoveValidationResult implements Serializable {
    private static final long serialVersionUID = 1L;

    private boolean isValid;
    private ValidationErrorCode errorCode;
    private String message;

    public MoveValidationResult(boolean isValid, ValidationErrorCode errorCode, String message) {
        this.isValid = isValid;
        this.errorCode = errorCode;
        this.message = message;
    }

    public boolean isValid() { return isValid; }

    public ValidationErrorCode getErrorCode() { return errorCode; }

    public String getMessage() { return message; }


}
