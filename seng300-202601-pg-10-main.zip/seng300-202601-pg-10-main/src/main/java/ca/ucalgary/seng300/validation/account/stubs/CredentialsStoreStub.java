package ca.ucalgary.seng300.validation.account.stubs;

import ca.ucalgary.seng300.validation.account.AccountValidation;
import ca.ucalgary.seng300.validation.account.records.UserID;

import java.io.Serializable;
import java.util.HashMap;

public class CredentialsStoreStub implements Serializable {
    private static final long serialVersionUID = 1L;
    private HashMap<String, UserCredentials> credentialsStore = new HashMap<>();

    public HashMap<String, UserCredentials> getCredentialsStore() {
        return credentialsStore;
    }

    public UserCredentials getCredentialsByUserID(UserID userID) {
        for (UserCredentials creds : credentialsStore.values()) {
            if (creds.profile.userID.equals(userID)) {
                return creds;
            }
        }
        return null;
    }

    // this returns credentials for the given username or null if not found
    public UserCredentials getCredentials(String username) {
        return credentialsStore.get(username);
    }

    //it will return true if the username is already registered
    public boolean containsUsername(String username){
        return credentialsStore.containsKey(username);
    }

    // it saves the credentials. returns false if username already exists.
    public boolean saveCredentials(UserCredentials credentials) {
        if (credentialsStore.containsKey(credentials.profile.username)){
            return false;
        }
        credentialsStore.put(credentials.profile.username,credentials);
        return true;
    }

    // this removes credentials for the given username and returns false if not found
    public boolean deleteCredentials(String username){
        if (!credentialsStore.containsKey(username)) {
            return false;
        }
        credentialsStore.remove(username);
        return true;
    }

    // it updates the stored username key (for username change)
    public boolean updateUsername(String oldUsername,String newUsername){
        UserCredentials creds =credentialsStore.get(oldUsername);
        if (creds == null) return false;
        credentialsStore.remove(oldUsername);
        creds.profile.username = newUsername;
        credentialsStore.put(newUsername, creds);
        return true;
    }

    // this will replaces the stored hashed password for user
    public boolean updatePassword(String username, String newHashedPassword) {
        UserCredentials creds = credentialsStore.get(username);
        if(creds == null) return false;
        creds.hashedPassword = newHashedPassword;
        return true;
    }

    // it hashes plain-text password using SHA-256 (delegates to AccountValidation)
    public String hashPassword(String plainText) {
        return AccountValidation.hashPassword(plainText);
    }
}
