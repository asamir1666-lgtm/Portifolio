package ca.ucalgary.seng300.network.handler.client;

import java.util.function.Consumer;

import ca.ucalgary.seng300.network.handler.Validatable;
import ca.ucalgary.seng300.network.message.Payload.Response;
import ca.ucalgary.seng300.network.message.Payload.Request;

public abstract class ClientHandler<Res extends Response> implements Validatable {
    protected Consumer<Request> sender;
    
    public void setSender(Consumer<Request> sender) {
        this.sender = sender;
    }
    
    public abstract void handle(Res serverResponse);
}
