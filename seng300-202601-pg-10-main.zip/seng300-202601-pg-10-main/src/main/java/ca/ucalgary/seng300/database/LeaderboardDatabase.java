package ca.ucalgary.seng300.database;

import ca.ucalgary.seng300.platformcore.Leaderboard;
import ca.ucalgary.seng300.Config;

/*
 * LeaderboardDatabase is responsible for managing the leaderboard data
 * It extends the Database class to utilize common database functionalities.
 */
public class LeaderboardDatabase extends Database<Leaderboard> {
    private LeaderboardDatabase() {
        super(Config.LEADERBOARD_FILE);
    }

	@Override
	protected Leaderboard getDefaultData() {
	    return new Leaderboard();
	}
}
