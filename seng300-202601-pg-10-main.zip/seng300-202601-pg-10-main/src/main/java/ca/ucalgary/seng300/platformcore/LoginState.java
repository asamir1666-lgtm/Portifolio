package ca.ucalgary.seng300.platformcore;

/**
 this may be not needed but just added here because it may be usefull for lobby or
 possibly implementing a timeout sort of thing. (This could also be done by Validation)
*/

public enum LoginState {
    LOGGED_OUT,
    LOGGED_IN,
    LOGIN_PENDING,
    LOGIN_FAILED
}
