package ca.ucalgary.seng300.validation.gamevalidation.enums;

public enum ValidationErrorCode {

    INVALID_TURN,
    OUT_OF_BOUNDS,
    CELL_OCCUPIED,
    ILLEGAL_MOVE

}
