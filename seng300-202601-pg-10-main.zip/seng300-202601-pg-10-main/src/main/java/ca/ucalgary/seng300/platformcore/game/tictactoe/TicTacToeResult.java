package ca.ucalgary.seng300.platformcore.game.tictactoe;

import ca.ucalgary.seng300.platformcore.game.MoveResult;
import ca.ucalgary.seng300.validation.account.records.UserID;

public class TicTacToeResult extends MoveResult {
    private final int row;
    private final int col;

    private TicTacToeResult(boolean accepted, String errorMessage,
                            boolean hasWinner, boolean isDraw,
                            UserID winnerID, UserID loserID,
                            int row, int col) {
        super(accepted, errorMessage, hasWinner, isDraw, winnerID, loserID);
        this.row = row;
        this.col = col;
    }

    public static TicTacToeResult error(int row, int col, String errorMessage) {
        return new TicTacToeResult(false, errorMessage, false, false, null, null, row, col);
    }

    public static TicTacToeResult ongoing(int row, int col) {
        return new TicTacToeResult(true, null, false, false, null, null, row, col);
    }

    public static TicTacToeResult draw(int row, int col) {
        return new TicTacToeResult(true, null, false, true, null, null, row, col);
    }

    public static TicTacToeResult gameOver(int row, int col, UserID winnerID, UserID loserID) {
        return new TicTacToeResult(true, null, true, false, winnerID, loserID, row, col);
    }

    public int getRow() { return row; }
    public int getCol() { return col; }
}
