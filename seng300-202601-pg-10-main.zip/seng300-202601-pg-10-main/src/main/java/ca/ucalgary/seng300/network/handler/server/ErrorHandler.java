package ca.ucalgary.seng300.network.handler.server;

import ca.ucalgary.seng300.network.ClientData;
import ca.ucalgary.seng300.network.message.Payload.Error;
import ca.ucalgary.seng300.logger.Logging;

import java.util.logging.Logger;

public class ErrorHandler extends ServerHandler<Error, Error> {
    private static final Logger logger = Logging.getLogger("ErrorHandler");

    @Override
    public Error handle(Error payload, ClientData clientData) {
        logger.severe("Error received: " + payload.message());
        return new Error("Error received: " + payload.message());
    }
}


