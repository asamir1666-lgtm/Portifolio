package ca.ucalgary.seng300.platformcore;

public enum LobbyResponseType {
  SUCCESS, //user entered into lobby
  FAILURE, //user cannot join lobby
  PRIVATE //user must enter access code
}
