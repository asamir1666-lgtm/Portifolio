package ca.ucalgary.seng300;

import ca.ucalgary.seng300.network.Client;
import ca.ucalgary.seng300.network.handler.client.MatchmakingHandler;
import ca.ucalgary.seng300.platformcore.GameType;
import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;


public class MatchmakingBridge extends BridgeBase
{

    private final MatchmakingHandler matchmakingHandler;
    private final LobbyBridge lobbyBridge;

    private GameType currentQueuedGameType;

    public MatchmakingBridge(WebEngine engine, Client client) {
        this(engine, client, null);
    }

    public MatchmakingBridge(WebEngine engine, Client client, LobbyBridge lobbyBridge) {
        super(engine);
        this.matchmakingHandler = client.router.getHandler(MatchmakingHandler.class);
        this.lobbyBridge = lobbyBridge;
        setUpHandlers();
    }

    public void attachBridge()
    {
        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.SUCCEEDED) {
                JSObject window = (JSObject) engine.executeScript("window");
                window.setMember("matchmakingBridge", this);
            }
        });
    }

    private void setUpHandlers()
    {
        // Server confirmed the player is now in the queue — show a spinner / waiting UI
        matchmakingHandler.setOnQueued(res -> {
            Platform.runLater(() ->
                    engine.executeScript(
                            "if(typeof onMatchmakingQueued==='function') onMatchmakingQueued()"
                    )
            );
        });

        matchmakingHandler.setOnMatched(res -> {
            String opponentId = res.opponentId().id();
            Platform.runLater(() -> {
                engine.executeScript(
                        "if(typeof onMatchFound==='function') onMatchFound('" + escapeJs(opponentId) + "')"
                );
                if (lobbyBridge != null) {
                    lobbyBridge.enterLobbyFromMatchmaking(res.lobby());
                }
            });
        });

        // Server confirmed the player left the queue
        matchmakingHandler.setOnLeft(res -> {
            currentQueuedGameType = null;
            Platform.runLater(() ->
                    engine.executeScript(
                            "if(typeof onMatchmakingLeft==='function') onMatchmakingLeft()"
                    )
            );
        });

        // Something went wrong so surface the error to the UI
        matchmakingHandler.setOnError(err -> {
            Platform.runLater(() -> {
                String msg = escapeJs(err.message());
                engine.executeScript(
                        "if(typeof onMatchmakingError==='function') onMatchmakingError('" + msg + "')"
                );
            });
        });
    }


    // Join the matchmaking queue for the given game type string.
    public void joinQueue(String gameTypeStr) {
        try {
            GameType gameType = GameType.valueOf(gameTypeStr.toUpperCase());
            currentQueuedGameType = gameType;
            matchmakingHandler.joinQueue(gameType);
        } catch (IllegalArgumentException e) {
            Platform.runLater(() ->
                    engine.executeScript(
                            "if(typeof onMatchmakingError==='function') onMatchmakingError('Unknown game type: " + escapeJs(gameTypeStr) + "')"
                    )
            );
        }
    }

    // Leave the matchmaking queue for the given game type string.
    public void leaveQueue(String gameTypeStr) {
        GameType gameType = null;
        try {
            if (gameTypeStr != null && !gameTypeStr.isBlank()) {
                gameType = GameType.valueOf(gameTypeStr.toUpperCase());
            }
        } catch (IllegalArgumentException ignored) {}

        if (gameType == null) {
            gameType = currentQueuedGameType;
        }
        if (gameType == null) {
            return;
        }
        matchmakingHandler.leaveQueue(gameType);
        currentQueuedGameType = null;
    }

    // Leave using the last queued game type — convenience for JS pages that
    public void leaveCurrentQueue() {
        if (currentQueuedGameType != null) {
            matchmakingHandler.leaveQueue(currentQueuedGameType);
            currentQueuedGameType = null;
        }
    }

    private String escapeJs(String value) {
        if (value == null) return "";
        return value
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }
}