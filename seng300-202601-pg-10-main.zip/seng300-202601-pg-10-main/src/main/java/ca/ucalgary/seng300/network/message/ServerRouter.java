package ca.ucalgary.seng300.network.message;

import ca.ucalgary.seng300.network.ClientData;
import ca.ucalgary.seng300.network.handler.server.ServerHandler;
import ca.ucalgary.seng300.network.message.Payload.Request;
import ca.ucalgary.seng300.network.message.Payload.Response;

public class ServerRouter extends AbstractRouter<ServerHandler<?, ?>> {
    @SuppressWarnings("unchecked")
    public Response route(Request req, ClientData clientData) {
        ServerHandler<Request, Response> h = (ServerHandler<Request, Response>) resolveUnknown(req.getClass());
        if (h == null) throw new IllegalStateException("No handler for: " + req.getClass());
        return h.handle(req, clientData);
    }
}