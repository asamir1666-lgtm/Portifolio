package ca.ucalgary.seng300.platformcore;

public enum Direction {
  NORTHWEST(-1, -1), NORTH(-1, 0), NORTHEAST(-1, 1),
  WEST(0, -1), EAST(0, 1),
  SOUTHWEST(1, -1), SOUTH(1, 0), SOUTHEAST(1, 1);

  private final int rowChange;

  private final int columnChange;

  Direction(int rowChange, int columnChange) {
    this.rowChange = rowChange;
    this.columnChange = columnChange;
  }

  public int getRowChange() {return rowChange;}
  public int getColumnChange() {return columnChange;}

  public int[] move(int[] coordinate) {
    return new int[] {coordinate[0] + rowChange, coordinate[1] + columnChange};
  }
}
