package ca.ucalgary.seng300.platformcore.game;

import java.io.Serializable;

public interface Piece extends Serializable {
    @Override
    public String toString();
    char getSymbol();

    Piece opposite();
}
