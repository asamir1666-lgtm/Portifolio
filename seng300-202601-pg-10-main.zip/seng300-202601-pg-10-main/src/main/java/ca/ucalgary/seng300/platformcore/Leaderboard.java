package ca.ucalgary.seng300.platformcore;

import java.io.Serializable;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.HashMap;

import ca.ucalgary.seng300.logger.Logging;
import ca.ucalgary.seng300.validation.account.records.UserID;

/**
 * Class representing the leaderboard, which maintains player statistics and
 * rankings.
 */
public class Leaderboard implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final int MAX_MATCH_HISTORY = 50;

    // Map of player IDs to their corresponding GameStats
    private HashMap<UserID, PlayerStats> playerStatsMap;
    private HashMap<UserID, ArrayList<MatchHistoryEntry>> matchHistory;
    private static final Logger logger = Logging.getLogger("Leaderboard");

    public Leaderboard() {
        this.playerStatsMap = new HashMap<>();
        this.matchHistory = new HashMap<>();
    }

    public void updateGameStats(UserID playerId, PlayerStats newPlayerStats) {
        playerStatsMap.put(playerId, newPlayerStats);
    }
    public void addPlayer(UserID playerId) {
        if (playerStatsMap.containsKey(playerId)) {
            throw new IllegalArgumentException("Player ID already exists in leaderboard: " + playerId);
        }
        playerStatsMap.put(playerId, new PlayerStats());
    }

    public HashMap<UserID, PlayerStats> getPlayerStatsMap() { return playerStatsMap; }

    public PlayerStats getPlayerStats(UserID playerId) {
        if (!playerStatsMap.containsKey(playerId)) {
            throw new IllegalArgumentException("Player ID not found in leaderboard: " + playerId);
        }
        return playerStatsMap.get(playerId);
    }

    public void recordMatch(UserID playerId, MatchHistoryEntry entry) {
        if (matchHistory == null) {
            matchHistory = new HashMap<>();
        }
        matchHistory.computeIfAbsent(playerId, k -> new ArrayList<>()).add(0, entry);
        ArrayList<MatchHistoryEntry> list = matchHistory.get(playerId);
        while (list.size() > MAX_MATCH_HISTORY) {
            list.remove(list.size() - 1);
        }
    }

    public ArrayList<MatchHistoryEntry> getMatchHistory(UserID playerId) {
        if (matchHistory == null) {
            return new ArrayList<>();
        }
        ArrayList<MatchHistoryEntry> list = matchHistory.get(playerId);
        if (list == null) {
            return new ArrayList<>();
        }
        return new ArrayList<>(list);
    }

    /**
     * Retrieves the top N players from the leaderboard based on their ELO
     * ratings.
     *
     * @param topN The number of top players to retrieve. (-1 for all players)
     * @return An ArrayList of GameStats representing the top players.
     */
    public ArrayList<LeaderboardExport> getTopPlayers(int topN, GameType gameType) {
        final ArrayList<LeaderboardExport> topPlayers = new ArrayList<>();
        for (UserID playerId : playerStatsMap.keySet()) {
            PlayerStats stats = playerStatsMap.get(playerId);
            topPlayers.add(new LeaderboardExport(playerId, stats));
        }
        topPlayers.sort((a, b) -> Integer.compare(
            b.getPlayerStats().getStatsForGame(gameType).getEloRating(),
            a.getPlayerStats().getStatsForGame(gameType).getEloRating())
        );
        int ceil = topPlayers.size();
        if (topN != -1) {
            ceil = Math.min(topN, topPlayers.size());
        }
        return new ArrayList<>(topPlayers.subList(0, ceil));
    }
}
