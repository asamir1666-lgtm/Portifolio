package ca.ucalgary.seng300;

import javafx.scene.web.WebEngine;

public class ChatBridge extends BridgeBase {

    public ChatBridge(WebEngine engine) {
        super(engine);
    }

    public void sendMessage(String message) {
        // TODO: forward to Platform Core once confirmed
        System.out.println("Message sent: " + message);
    }

    public void receiveMessage(String sender, String message) {
        // TODO: call platform core to get real messages
        engine.executeScript("receiveMessage('" + sender + "', '" + message + "')");
    }
}