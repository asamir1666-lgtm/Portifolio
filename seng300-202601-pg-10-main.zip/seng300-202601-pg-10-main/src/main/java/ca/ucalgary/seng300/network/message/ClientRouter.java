package ca.ucalgary.seng300.network.message;

import java.util.function.Consumer;

import ca.ucalgary.seng300.network.handler.client.ClientHandler;
import ca.ucalgary.seng300.network.message.Payload.Compound;
import ca.ucalgary.seng300.network.message.Payload.Request;
import ca.ucalgary.seng300.network.message.Payload.Response;

public class ClientRouter extends AbstractRouter<ClientHandler<?>> {
    public void validateAll(){
        for (ClientHandler<?> h : handlers.values()) {
            h.validate();
        }
    }
    
    @SuppressWarnings("unchecked")
    public void route(Response res) {
        if (res instanceof Compound c) {
            for (Response inner : c.responses()) {
                route(inner);
            }
            return;
        }
        ClientHandler<Response> h = (ClientHandler<Response>) resolveUnknown(res.getClass());
        if (h == null) throw new IllegalStateException("No handler: " + res.getClass());
        h.handle(res);
    }

    public void wireAll(Consumer<Request> sender) {
        for (ClientHandler<?> h : handlers.values()) {
            h.setSender(sender);
        }
    }
}

