package ca.ucalgary.seng300.network.handler;

public interface Validatable {
    void validate();
}
