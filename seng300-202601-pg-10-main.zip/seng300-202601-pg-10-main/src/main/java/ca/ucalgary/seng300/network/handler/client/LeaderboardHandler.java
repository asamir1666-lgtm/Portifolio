package ca.ucalgary.seng300.network.handler.client;

import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.network.message.Payload.Leaderboard.Req;
import ca.ucalgary.seng300.network.message.Payload.Leaderboard.Res;

import java.util.Objects;
import java.util.function.Consumer;

public class LeaderboardHandler extends ClientHandler<Res> {
    private Consumer<Res.Get>   onGet;
    private Consumer<Res.Error> onError;

    public void setOnGetLeaderboard(Consumer<Res.Get> cb)   { this.onGet = cb; }
    public void setOnError(Consumer<Res.Error> cb)          { this.onError = cb; }

    @Override
    public void handle(Res serverResponse) {
        switch (serverResponse) {
            case Res.Get r      -> onGet.accept(r);
            case Res.Error e    -> onError.accept(e);
        }
    }

    public void getLeaderboard(GameType gameType, int topN) {
        this.sender.accept(new Req.Get(gameType, topN));
    }

    @Override
    public void validate() {
        Objects.requireNonNull(this.onGet,      "Get Leaderboard callback must be set");
        Objects.requireNonNull(this.onError,    "Get Leaderboard error callback must be set");
    }
}
