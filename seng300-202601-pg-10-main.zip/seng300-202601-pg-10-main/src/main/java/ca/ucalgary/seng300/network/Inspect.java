package ca.ucalgary.seng300.network;

import java.util.Random;

import ca.ucalgary.seng300.database.AccountDatabase;
import ca.ucalgary.seng300.database.Database;
import ca.ucalgary.seng300.database.LeaderboardDatabase;
import ca.ucalgary.seng300.database.LobbyDatabase;
import ca.ucalgary.seng300.database.SessionAccounts;
import ca.ucalgary.seng300.database.SessionStore;
import ca.ucalgary.seng300.network.handler.server.AuthHandler;
import ca.ucalgary.seng300.platformcore.GameStats;
import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.Leaderboard;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.platformcore.LobbyManager;
import ca.ucalgary.seng300.platformcore.LobbyRoom;
import ca.ucalgary.seng300.platformcore.PlayerStats;
import ca.ucalgary.seng300.validation.account.AccountDatabaseManager;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.account.stubs.CredentialsStoreStub;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;
import ca.ucalgary.seng300.validation.account.stubs.TokenManager;
import ca.ucalgary.seng300.validation.account.stubs.UserCredentials;
import ca.ucalgary.seng300.network.message.Payload.Auth.Req;

public class Inspect {
    private static AccountDatabase accountDb = Database.getInstance(AccountDatabase.class);
    private static SessionStore sessionStore = Database.getInstance(SessionStore.class);
    private static LeaderboardDatabase leaderboardDatabase = Database.getInstance(LeaderboardDatabase.class);
    private static LobbyDatabase lobbyDatabase = Database.getInstance(LobbyDatabase.class);

    private static AuthHandler authHandler = new AuthHandler(accountDb, leaderboardDatabase);
    private static Random random = new Random(42); // Fixed seed for reproducibility

    public static void printSession(SessionToken token) {
        System.out.println("Session Token:");
        System.out.println("  User ID: " + token.userID);
        System.out.println("  Token Value: " + token.tokenValue);
        System.out.println("  Created At: " + token.createdAt);
    }

    public static void inspectActiveSessions() {
        AccountDatabaseManager manager = accountDb.getData();
        TokenManager tokenManager = manager.getTokenManager();
        for (UserID userId : tokenManager.getTokenStore().keySet()) {
            System.out.println("Active session for user: " + userId);
            printSession(tokenManager.getToken(userId));
        }
    }

    public static void inspectCurrentSession() {
        SessionAccounts acc = sessionStore.getData();
        SessionToken t = acc.getActiveToken();
        if (t != null && t.tokenValue != null && !t.tokenValue.isEmpty()) {
            System.out.println("Current active session:");
            printSession(t);
        } else {
            System.out.println("No active session found.");
        }
    }

    public static void inspectAccounts() {
        AccountDatabaseManager manager = accountDb.getData();
        System.out.println("Registered accounts:");
        CredentialsStoreStub credsStore = manager.getCredentialsStore();
        
        for (String username: credsStore.getCredentialsStore().keySet()) {
            UserCredentials creds = credsStore.getCredentials(username);
            System.out.println("    User ID: " + creds.profile.userID);
            System.out.println("    Username: " + creds.profile.username);
            System.out.println("    Hashed Password: " + creds.hashedPassword);
        }
    }

    public static void writeStats(String username, PlayerStats newStats){
        AccountDatabaseManager manager = accountDb.getData();
        CredentialsStoreStub credsStore = manager.getCredentialsStore();
        UserCredentials creds = credsStore.getCredentials(username);
        if (creds == null) {
            System.out.println("User not found: " + username);
            return;
        }
        Leaderboard ldb = leaderboardDatabase.getData();
        ldb.updateGameStats(creds.profile.userID, newStats);
        leaderboardDatabase.save();
    }

    public static void inspectLeaderboard() {
        Leaderboard ldb = leaderboardDatabase.getData();
        for (UserID userId : ldb.getPlayerStatsMap().keySet()) {
            System.out.println("Stats for user: " + userId);
            PlayerStats stats = ldb.getPlayerStats(userId);
            for (GameType gameType : GameType.values()) {
                GameStats gameStats = stats.getStatsForGame(gameType);
                System.out.println("  " + gameType + ": ELO=" + gameStats.getEloRating() +
                                   ", Wins=" + gameStats.getWins() +
                                   ", Losses=" + gameStats.getLosses() +
                                   ", Draws=" + gameStats.getDraws());
            }
        }
    }
    public static void signUp(String username, String password) {
        authHandler.handle(new Req.Signup(username, password), null);
    }
    public static void login(String username, String password) {
        authHandler.handle(new Req.Login(username, password), null);
    }

    public static PlayerStats randomStats() {
        PlayerStats stats = new PlayerStats();
        for (GameType gameType : GameType.values()) {
            stats.setGameStats(gameType, new GameStats(
                1000 + random.nextInt(500), // ELO between 1000 and 1500
                random.nextInt(50),          // Wins between 0 and 49
                random.nextInt(50),          // Losses between 0 and 49
                random.nextInt(50)           // Draws between 0 and 49
            ));
        }
        return stats;
    }
    public static void inspectLobby(String joinCode) {
        LobbyManager lobbyManager = lobbyDatabase.getData();
        LobbyRoom lobby = lobbyManager.getLobbyByJoinCode(joinCode);
        System.out.println("Lobby ID: " + lobby.getID());
        System.out.println("Game Type: " + lobby.getGameType());
        System.out.println("Spots left: " + lobby.getRemainingSpots());
        System.out.println("Current Players:");
        lobby.getPlayers().forEach(player -> {
            System.out.println("  Player ID: " + player.getID());
            System.out.println("  Username: " + player.getUsername());
        });
    }

    public static void main(String[] args) {
        // Fixed seed for reproducibility
        
        accountDb.connect();
        sessionStore.connect();
        leaderboardDatabase.connect();
        lobbyDatabase.connect();

        // inspectActiveSessions();
        // inspectCurrentSession();
        inspectAccounts();
        // signUp("Bilal", "password123");
        // signUp("Alice", "password456");
        
        // login("Bilal", "password123");
        // login("Alice", "password456");

        // writeStats("Bilal", randomStats());
        // writeStats("Alice", randomStats());
        // PlayerStats newStats = new PlayerStats();
        // newStats.setGameStats(GameType.TICTACTOE, new GameStats(1000, 5, 3, 7));
        // newStats.setGameStats(GameType.CONNECTFOUR, new GameStats(1100, 8, 2, 9));
        // writeStats("Bilal", newStats);
        //
        // inspectLeaderboard();
        // inspectLobby("aOMv2V");
    }
}
