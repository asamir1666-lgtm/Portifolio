package ca.ucalgary.seng300.network;

import java.io.*;
import java.net.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;
import java.util.Scanner;

import ca.ucalgary.seng300.Config;
import ca.ucalgary.seng300.database.Database;
import ca.ucalgary.seng300.database.SessionAccounts;
import ca.ucalgary.seng300.database.SessionStore;
import ca.ucalgary.seng300.logger.Logging;
import ca.ucalgary.seng300.network.handler.client.*;
import ca.ucalgary.seng300.network.message.ClientRouter;
import ca.ucalgary.seng300.network.message.Payload;
import ca.ucalgary.seng300.network.message.Payload.Request;
import ca.ucalgary.seng300.network.message.Payload.Response;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;
import ca.ucalgary.seng300.platformcore.GameType;

public class Client {
    private Socket socket;
    private ObjectOutputStream out;
    private final static Logger logger = Logging.getLogger("NetworkClient");
    private final InetAddress serverAddress;
    private final String clientId = Util.getRandomClientId();
    private final SessionStore sessionStore = Database.getInstance(SessionStore.class);        

    public final ClientRouter router = new ClientRouter();

    public Client(String serverIP) throws UnknownHostException {
        this.serverAddress = InetAddress.getByName(serverIP);
        registerRouters();
    }

    public Client() throws IOException {
        this.serverAddress = switch (Config.DISCOVERY_METHOD) {
            case BROADCAST      -> discoverServerBroadcast();
            case SUBNET_SCAN    -> discoverServerSubnetScan();
            case MULTICAST      -> throw new UnsupportedOperationException("Multicast discovery not implemented yet");
        };
        registerRouters();
    }

    private void registerRouters() {
        this.router.register(new GameHandler());
        this.router.register(new LobbyHandler());
        this.router.register(new AuthHandler());
        this.router.register(new ProfileHandler());
        this.router.register(new LeaderboardHandler());
        this.router.register(new MatchmakingHandler());

        this.router.wireAll(this::send);
    }

    private InetAddress discoverServerBroadcast() throws IOException {
        // We need to find the server ip
        try (DatagramSocket udp = new DatagramSocket()) {
            udp.setBroadcast(true);
            udp.setSoTimeout(3000);

            byte[] msg = Config.CLIENT_DISCOVERY_MESSAGE.getBytes();
            DatagramPacket request =
                new DatagramPacket(msg, msg.length, InetAddress.getByName("255.255.255.255"), Config.DISCOVERY_PORT);

            byte[] buf = new byte[256];
            DatagramPacket reply = new DatagramPacket(buf, buf.length);

            for (int i = 0; i < Config.MAX_RETRY_ATTEMPTS; i++) {
                logger.info("Attempting discovery... (" + (i + 1) + "/" + Config.MAX_RETRY_ATTEMPTS + ")");
                // Yells any server out here?
                udp.send(request);
                try {
                    udp.receive(reply);
                    String response = new String(reply.getData(), 0, reply.getLength()).trim();
                    // Is this the server I want
                    if (response.equals(Config.SERVER_REPLY_DISCOVERY)) {
                        logger.info("Received discovery reply from " + reply.getAddress());
                        return reply.getAddress();
                    }
                } catch (SocketTimeoutException e) {
                    logger.warning("No discovery response, retrying...");
                }
            }
            throw new IOException("Invalid discovery response");
        }
    }

    private InetAddress discoverServerSubnetScan() throws IOException {
        try (DatagramSocket udp = new DatagramSocket()) {
            udp.setSoTimeout(15000);

            AtomicReference<InetAddress> found = new AtomicReference<>(null);

            // Listen if anyone tried to reply back
            Thread listener = new Thread(() -> {
                byte[] buf = new byte[256];
                try {
                    while (found.get() == null) {
                        DatagramPacket reply = new DatagramPacket(buf, buf.length);
                        udp.receive(reply);
                        String resp = new String(reply.getData(), 0, reply.getLength()).trim();
                        if (resp.equals(Config.SERVER_REPLY_DISCOVERY)) {
                            found.set(reply.getAddress());
                        }
                    }
                } catch (SocketTimeoutException | SocketException ignored) {
                } catch (IOException e) {
                    e.printStackTrace();
                    return;
                }
            }, "udp-discovery-listener-subnet" + clientId);

            listener.setDaemon(true);
            listener.start();

            // Brute force scan the subnet for any servers (pls dont ban me)
            String[] localIP = Util.getLocalIP().split("\\.");
            byte[] msg = Config.CLIENT_DISCOVERY_MESSAGE.getBytes();
            for (int c = 0; c < 256 && found.get() == null; c++) {
                logger.info("Scanning subnet... (" + c + "/255)");
                for (int d = 1; d < 255 && found.get() == null; d++) {
                    String A = localIP[0];
                    String B = localIP[1];
                    String target = String.format("%s.%s.%d.%d", A, B, c, d);
                    InetAddress addr = InetAddress.getByName(target);
                    udp.send(new DatagramPacket(msg, msg.length, addr, Config.DISCOVERY_PORT));
                }
                // Relax
                Thread.sleep(10);
            }

            listener.join(5000);

            if (found.get() != null) return found.get();
            throw new IOException("Server not found");

        } catch (InterruptedException e) {
            throw new IOException("Discovery interrupted", e);
        }
    }

    private void handleServerMessage() {
        try (ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {
            while (true) {
                Object obj = in.readObject();
                if (!(obj instanceof Response)) {
                    logger.warning("Received unknown message type from server: " + obj.getClass().getName());
                    continue;
                }
                logger.info("Received response from server: " + obj);
                Response res = (Response) obj;
                router.route(res);
            }
        } catch (IOException | ClassNotFoundException e) {
            logger.warning("Connection to server lost: " + e.getMessage());
        }
    }

    // Default to validate before connect
    public void connect() throws IOException {
        connect(false);
    }

    public void connect(Boolean skipValidation) throws IOException {
        socket = new Socket(this.serverAddress, Config.GAME_PORT);
        out = new ObjectOutputStream(socket.getOutputStream());
        logger.info("Connected to server at " + this.serverAddress);

        if (!skipValidation) {
            this.router.validateAll();
        }

        // Listen to response from server and update state or do something
        new Thread(this::handleServerMessage, "tcp-listener" + clientId).start();
    }

    public void send(Request req) { 
        try {
            out.writeObject(req);
        } catch (IOException e) {
            logger.warning("Failed to send request to server");
        }
    }

    public static void main(String[] args) throws Exception {
        Client client;
        if (args.length > 0) {
            InetAddress addr = InetAddress.getByName(args[0]);
            client = new Client(addr.getHostAddress());
        } else {
            client = new Client();
        }
        client.connect(true);
        SessionStore store = Database.getInstance(SessionStore.class);
        store.connect();
        
        AuthHandler authHandler = client.router.getHandler(AuthHandler.class);
        authHandler.setOnSignup(res -> {
            System.out.println("Signup successful!");
        });
        authHandler.setOnLogin(res -> {
            System.out.println("Login successful! Token: " + res.token());
            SessionAccounts acc = store.getData();
            acc.addOrUpdate(res.id(), res.token(), null);
            store.save();
        });
        authHandler.setOnLoginToken(res -> {
            System.out.println("Login with token successful!");
        });
        authHandler.setOnError(res -> {
            System.out.println("Error: " + res.message());
        });
        
        LobbyHandler lobbyHandler = client.router.getHandler(LobbyHandler.class);
        lobbyHandler.setOnCreate(res -> {
            System.out.println("Lobby created with ID: " + res.lobby().getID());
        });
        lobbyHandler.setOnJoin(res -> {
            System.out.println("Joined lobby with ID: " + res.lobby().getID());
            System.out.println("Players in lobby:");
            res.lobby().getPlayers().forEach(p -> System.out.println("- " + p.getUsername()));
        });
        
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.print("> ");
            String message = sc.nextLine();
            if (message.equalsIgnoreCase("exit")) {
                break;
            }
            if (message.startsWith("signup")) {
                String[] parts = message.split(" ");
                if (parts.length < 2) {
                    System.out.println("Usage: signup <username> <password>");
                    continue;
                }
                String username = parts[1];
                String password = "a1234567"; //default
                if (parts.length == 3) {
                    password = parts[2];
                }
                Request req = new Payload.Auth.Req.Signup(username, password);
                client.send(req);
                continue;
            }
            if (message.startsWith("login")) {
                String[] parts = message.split(" ");
                if (parts.length < 2) {
                    System.out.println("Usage: login <username> <password>");
                    continue;
                }
                String username = parts[1];
                String password = "a1234567"; //default
                if (parts.length == 3) {
                    password = parts[2];
                }
                Request req = new Payload.Auth.Req.Login(username, password);
                client.send(req);
                continue;
            }
            if (message.startsWith("tokenlogin")) {
                SessionToken myToken = store.getData().getActiveToken();
                if (myToken == null) {
                    System.out.println("No saved session token.");
                    continue;
                }
                Request req = new Payload.Auth.Req.LoginToken(myToken);
                client.send(req);
                continue;
            }

            if (message.startsWith("createlobby")) {
                if (message.split(" ").length != 2) {
                    System.out.println("Usage: createlobby <gametype>");
                    continue;
                }
                GameType gameType = GameType.valueOf(message.split(" ")[1].toUpperCase());
                Request req = new Payload.Lobby.Req.Create(gameType, true);
                client.send(req);
                continue;
            }
            if (message.startsWith("joinlobby")) {
                String[] parts = message.split(" ");
                if (parts.length != 2) {
                    System.out.println("Usage: joinlobby <joinCode>");
                    continue;
                }
                String joinCode = parts[1];
                Request req = new Payload.Lobby.Req.Join(null, joinCode);
                client.send(req);
                continue;
            }
            // Request req = new Payload.Lobby.Req.Chat("123", message);
            // client.send(req);
        }
        sc.close();
        client.socket.close();
    }
}
