package ca.ucalgary.seng300.platformcore.game;

public enum GameStatus {
    ONGOING,
    PLAYER_ONE_WON,
    PLAYER_TWO_WON,
    DRAW,
    QUIT
}
