package ca.ucalgary.seng300.validation.account;

import ca.ucalgary.seng300.validation.account.enums.AccountErrorCode;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.account.results.AccountValidationResult;
import ca.ucalgary.seng300.validation.account.results.ValidationResult;
import ca.ucalgary.seng300.validation.account.stubs.CredentialsStoreStub;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;
import ca.ucalgary.seng300.validation.account.stubs.TokenManager;
import ca.ucalgary.seng300.validation.account.stubs.UserCredentials;
import ca.ucalgary.seng300.validation.account.stubs.UserProfile;

import java.security.MessageDigest;
import java.util.regex.Pattern;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class AccountValidation implements Serializable {
    private static final long serialVersionUID = 1L;

    //token expiry: 3 days in milliseconds
    private static final long TOKEN_EXPIRY_MS = 3L * 24 * 60 * 60 * 1000;

    //username: 3–20 chars,alphanumeric + underscores only
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_]{3,20}$");

    //password: 8–64 chars,at least 1 letter and 1 digit
    private static final Pattern PASSWORD_PATTERN = Pattern.compile("^(?=.*[A-Za-z])(?=.*\\d).{8,64}$");


    private CredentialsStoreStub credentialsStore;
    private TokenManager tokenStore;


    public AccountValidation(CredentialsStoreStub credentialsStore, TokenManager tokenStore) {
        this.credentialsStore = credentialsStore;
        this.tokenStore = tokenStore;
    }

    public CredentialsStoreStub getCredentialsStore() {
        return credentialsStore;
    }

    public TokenManager getTokenStore() {
        return tokenStore;
    }


    /**
     * Validates login attempt. On success: creates session token, stores it and returns it with the userProfile.
     *  and On failure: returns an appropriate error code.
     */

    public AccountValidationResult validateLogin(String username, String password) {

        // check format first
        if (!checkFormat(username, password)) {
            return new AccountValidationResult(false, AccountErrorCode.INVALID_FORMAT, "Username or password format is invalid.", null, null);
        }

        // look up user in credentials store
        UserCredentials creds = getUserCredentials(username);
        if (creds == null) {
            return new AccountValidationResult(false, AccountErrorCode.USER_NOT_FOUND, "No account found with that username.", null, null);
        }

        // Verify password matches stored hash
        if (!compareHashedPassword(password, creds.hashedPassword)) {
            return new AccountValidationResult(false, AccountErrorCode.INVALID_CREDENTIALS, "Incorrect password.", null, null);
        }

        // Issue session token and store it
        SessionToken tokenValue = generateSessionToken(creds.profile.userID);
        UserProfile profile = creds.profile;
        tokenStore.writeToken(profile.userID, tokenValue);

        return new AccountValidationResult(true, null,
                "Login successful.", creds.profile, tokenValue);
    }


   /**
    * Validates a registration request. checks format rules and username availability.
    * it does NOT create the account. (AccountDatabaseManager does that after this returns success.)
    */

    public ValidationResult validateRegistration(String username, String password) {

        //first format check
        if (!checkFormat(username, password)) {
            return new ValidationResult(false, AccountErrorCode.INVALID_FORMAT,
                    "Username must be 3–20 alphanumeric/underscore characters. "
                            + "Password must be 8–64 characters with at least one letter and one digit.");
        }

        // username availability
        if (!isUsernameAvailable(username)) {
            return new ValidationResult(false, AccountErrorCode.USERNAME_TAKEN,
                    "That username is already taken.");
        }

        return new ValidationResult(true, null, "Registration input is valid.");
    }


    /**
     * Validates that the given token belongs to the user and has not expired.
     * its used in platformCore / other services to authorise read only actions.
     */
    public ValidationResult validateToken(SessionToken token) {
        if (token == null) {
            return new ValidationResult(false, AccountErrorCode.SESSION_NOT_FOUND,
                    "No active session found for this user.");
        }

        SessionToken stored = tokenStore.getToken(token.userID);
        if (stored == null) {
            return new ValidationResult(false, AccountErrorCode.SESSION_NOT_FOUND,
                    "No active session found for this user.");
        }

        if (!stored.tokenValue.equals(token.tokenValue)) {
            return new ValidationResult(false, AccountErrorCode.INVALID_TOKEN,
                    "Token does not match the active session.");
        }

        if (isTokenExpired(stored)) {
            tokenStore.removeToken(token.userID);
            return new ValidationResult(false, AccountErrorCode.TOKEN_EXPIRED,
                    "Session has expired. Please log in again.");
        }
        return new ValidationResult(true, null, "Token is valid.");
    }

    /**
     * Ends the session for the given user by removing their token.
     * Validates the token first to ensure the caller owns the session.
     */

    public ValidationResult endSessionToken(SessionToken token) {
        ValidationResult check = validateToken(token);
        if (!check.isValid) {
            return check; // propagate the specific error
        }

        tokenStore.removeToken(token.userID);
        return new ValidationResult(true, null, "Session ended successfully.");
    }

    /**
     * validates username change request.
     * it will Check: active token, correct password, new username format and availability.
     */

    public ValidationResult validateProfileEditUsername(String username, String password, String newUsername) {

        // verify the user exists and password is correct
        ValidationResult authCheck = authenticateUser(username, password);
        if (!authCheck.isValid) return authCheck;

        // validate the new username format
        if (newUsername == null || !USERNAME_PATTERN.matcher(newUsername).matches()) {
            return new ValidationResult(false, AccountErrorCode.INVALID_FORMAT,
                    "New username must be 3–20 alphanumeric/underscore characters.");
        }

        // make sure the new username isn't already taken
        if (!isUsernameAvailable(newUsername)) {
            return new ValidationResult(false, AccountErrorCode.USERNAME_TAKEN,
                    "That username is already taken.");
        }

        return new ValidationResult(true, null, "Username update is valid.");
    }

    /**
     * Validates password-change request.
     * it will checks: user exists, old password correct, new password meets format rules.
     */

    public ValidationResult validateProfileEditPassword(String username, String password, String newPassword) {

        // Verify the user exists and current password is correct
        ValidationResult authCheck = authenticateUser(username,password);
        if (!authCheck.isValid) return authCheck;

        // validate the new password format
        if (newPassword == null || !PASSWORD_PATTERN.matcher(newPassword).matches()) {
            return new ValidationResult(false, AccountErrorCode.INVALID_FORMAT,
                    "New password must be 8–64 characters with at least one letter and one digit.");
        }

        // ensure new password is actually different
        UserCredentials creds = getUserCredentials(username);
        if (compareHashedPassword(newPassword, creds.hashedPassword)) {
            return new ValidationResult(false, AccountErrorCode.PASSWORD_MISMATCH,
                    "New password must differ from the current password.");
        }
        return new ValidationResult(true, null, "Password update is valid.");
    }


    // Private helpers

    // Looks up credentials by username. Returns null if not found.
    public UserCredentials getUserCredentials(String username) {
        return credentialsStore.getCredentials(username);
    }

    // Returns true if the username is not yet registered
    private boolean isUsernameAvailable(String username) {
        return !credentialsStore.containsUsername(username);
    }

    // Hashes the plain-text input and compares it to the stored hash. never compares plain text directly, always hash first.
    private boolean compareHashedPassword(String input, String storedHash) {
        String hashedInput = hashPassword(input);
        if (hashedInput == null) return false;
        return hashedInput.equals(storedHash);
    }

    // checks both username and password meet format requirements
    private boolean checkFormat(String username, String password) {
        if (username == null || password == null) return false;
        return USERNAME_PATTERN.matcher(username).matches()
                && PASSWORD_PATTERN.matcher(password).matches();
    }
    // it returns true if the token was issued more than TOKEN_EXPIRY_MS ago,
    // sessionToken stores its creation time so we can check age.

    private boolean isTokenExpired(SessionToken token) {
        return (System.currentTimeMillis() - token.createdAt) > TOKEN_EXPIRY_MS;
    }


    // Verifies a user exists and their password is correct. Used by profile-edit methods. */
    private ValidationResult authenticateUser(String username, String password) {
        if (password == null) {
            return new ValidationResult(false, AccountErrorCode.INVALID_CREDENTIALS, "Incorrect password.");
        }

        UserCredentials creds = getUserCredentials(username);
        if (creds == null) {
            return new ValidationResult(false, AccountErrorCode.USER_NOT_FOUND,
                    "No account found with that username.");
        }
        if (!compareHashedPassword(password, creds.hashedPassword)) {
            return new ValidationResult(false, AccountErrorCode.INVALID_CREDENTIALS,
                    "Incorrect password.");
        }
        return new ValidationResult(true, null, "Authenticated.");
    }

    // public helpers

    public SessionToken generateSessionToken(UserID userID) {
        // generates random token using userID and current time, hashed with SHA-256
        String rawToken = userID.id() + System.currentTimeMillis();
        String hashedPassword = hashPassword(rawToken);
        return new SessionToken(hashedPassword, userID);
    }

    public static String hashPassword(String plainText) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(plainText.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }
}
