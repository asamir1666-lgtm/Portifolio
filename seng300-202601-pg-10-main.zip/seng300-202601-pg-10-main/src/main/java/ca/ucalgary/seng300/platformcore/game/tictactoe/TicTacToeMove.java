package ca.ucalgary.seng300.platformcore.game.tictactoe;

import ca.ucalgary.seng300.platformcore.game.GameMove;
import ca.ucalgary.seng300.platformcore.game.GridSpace;

public class TicTacToeMove extends GameMove {
    public TicTacToeMove(GridSpace grid) {
        super(grid);
    }
}
