package ca.ucalgary.seng300.network.handler.client;

import ca.ucalgary.seng300.network.message.Payload.Compound;
import ca.ucalgary.seng300.network.message.Payload.Error;
import ca.ucalgary.seng300.network.message.Payload.Lobby.Res;
import ca.ucalgary.seng300.network.message.Payload.Lobby.Req;
import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.LobbyID;

import java.util.Objects;
import java.util.function.Consumer;

public class LobbyHandler extends ClientHandler<Res> {

    private Consumer<Res.Create>            onCreate;
    private Consumer<Res.Join>              onJoin;
    private Consumer<Res.Leave>             onLeave;
    private Consumer<Res.List>              onList;
    private Consumer<Res.Start>             onStart;
    private Consumer<Res.RematchVote>       onRematchVote;
    private Consumer<Res.AllReady>          onAllReady;
    private Consumer<Res.ReturnedLobby>     onReturnedLobby;
    private Consumer<Res.ReturnedDashboard> onReturnedDashboard;
    private Consumer<Res.LobbyUpdated>         onLobbyUpdated;
    private Consumer<Res.PlayerReady>         onPlayerReady;
    private Consumer<Res.PlayerDisconnected>  onPlayerDisconnected;
    private Consumer<Error>                   onError;

    public void setOnCreate             (Consumer<Res.Create> cb)            { this.onCreate             = cb; }
    public void setOnJoin               (Consumer<Res.Join> cb)              { this.onJoin               = cb; }
    public void setOnLeave              (Consumer<Res.Leave> cb)             { this.onLeave              = cb; }
    public void setOnList               (Consumer<Res.List> cb)              { this.onList               = cb; }
    public void setOnStart              (Consumer<Res.Start> cb)             { this.onStart = cb; }
    public void setOnRematchVote        (Consumer<Res.RematchVote> cb)       { this.onRematchVote        = cb; }
    public void setOnAllReady           (Consumer<Res.AllReady> cb)          { this.onAllReady           = cb; }
    public void setOnReturnedLobby      (Consumer<Res.ReturnedLobby> cb)     { this.onReturnedLobby      = cb; }
    public void setOnReturnedDashboard  (Consumer<Res.ReturnedDashboard> cb) { this.onReturnedDashboard  = cb; }
    public void setOnLobbyUpdated       (Consumer<Res.LobbyUpdated> cb)      { this.onLobbyUpdated       = cb; }
    public void setOnPlayerReady        (Consumer<Res.PlayerReady> cb)       { this.onPlayerReady        = cb; }
    public void setOnPlayerDisconnected (Consumer<Res.PlayerDisconnected> cb){ this.onPlayerDisconnected = cb; }
    public void setOnError              (Consumer<Error> cb)                 { this.onError              = cb; }

    @Override
    public void handle(Res serverResponse) {
        switch (serverResponse) {
            case Compound c -> throw new IllegalStateException(
                    "Client received Compound; server should unpack and send responses individually");
            case Res.Create r            -> onCreate.accept(r);
            case Res.Join r              -> onJoin.accept(r);
            case Res.Leave r             -> onLeave.accept(r);
            case Res.List r              -> onList.accept(r);
		    case Res.Start r             -> onStart.accept(r);
            case Res.RematchVote r       -> onRematchVote.accept(r);
            case Res.AllReady r          -> onAllReady.accept(r);
            case Res.ReturnedLobby r     -> onReturnedLobby.accept(r);
            case Res.ReturnedDashboard r -> onReturnedDashboard.accept(r);
            case Res.LobbyUpdated r      -> onLobbyUpdated.accept(r);
            case Res.PlayerReady r       -> onPlayerReady.accept(r);
            case Res.PlayerDisconnected r-> { if (onPlayerDisconnected != null) onPlayerDisconnected.accept(r); }
            case Res.Error e             -> onError.accept(e);
        }
    }

    public void createLobby(GameType gameType, boolean isPublic) {
        this.sender.accept(new Req.Create(gameType, isPublic));
    }

    public void joinLobby(LobbyID lobbyId, String joinCode) {
        this.sender.accept(new Req.Join(lobbyId, joinCode));
    }
    public void startGame() {
        Req.Start req = new Req.Start();
        this.sender.accept(req);
    }

    public void leaveLobby() {
        this.sender.accept(new Req.Leave());
    }

    public void listLobbies() {
        this.sender.accept(new Req.List());
    }

    public void requestRematch() {
        this.sender.accept(new Req.Rematch());
    }

    public void returnToLobby() {
        this.sender.accept(new Req.ReturnLobby());
    }

    public void returnToDashboard() {
        this.sender.accept(new Req.ReturnDashboard());
    }

    public void addBot(int difficulty) {
        this.sender.accept(new Req.AddBot(difficulty));
    }

    public void setReady(boolean ready) {
        this.sender.accept(new Req.SetReady(ready));
    }

    @Override
    public void validate() {
        Objects.requireNonNull(onCreate,            "LobbyHandler: onCreate not set");
        Objects.requireNonNull(onJoin,              "LobbyHandler: onJoin not set");
        Objects.requireNonNull(onLeave,             "LobbyHandler: onLeave not set");
        Objects.requireNonNull(onList,              "LobbyHandler: onList not set");
        Objects.requireNonNull(onStart,             "LobbyHandler: onStart not set");
        Objects.requireNonNull(onRematchVote,       "LobbyHandler: onRematchVote not set");
        Objects.requireNonNull(onAllReady,          "LobbyHandler: onAllReady not set");
        Objects.requireNonNull(onReturnedLobby,     "LobbyHandler: onReturnedLobby not set");
        Objects.requireNonNull(onReturnedDashboard, "LobbyHandler: onReturnedDashboard not set");
        Objects.requireNonNull(onLobbyUpdated,      "LobbyHandler: onLobbyUpdated not set");
        Objects.requireNonNull(onPlayerReady,       "LobbyHandler: onPlayerReady not set");
        Objects.requireNonNull(onError,             "LobbyHandler: onError not set");
    }
}
