package ca.ucalgary.seng300.platformcore.game.tictactoe;

import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.platformcore.game.*;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.gamevalidation.results.MoveValidationResult;

public class TicTacToeGame extends GameAbstract<TicTacToePiece> {
    private static final int DEFAULT_SIZE = 3;
    private static final int QUIT_COORDINATE = -1;

    public TicTacToeGame(int rowSize, int colSize, Player p1, Player p2) {
        super(
            GameType.TICTACTOE,
            rowSize < 1 ? DEFAULT_SIZE : rowSize,
            colSize < 1 ? DEFAULT_SIZE : colSize,
            p1, p2
        );
        playerPieceMapping.put(p1.getID(), TicTacToePiece.X);
        playerPieceMapping.put(p2.getID(), TicTacToePiece.O);
        clear();
        gameState = createGameState();
    }

    @Override
    public TicTacToeResult makeMove(GameMove move, Player player) {
        if (player == null || !player.equals(currentPlayer)) {
            return TicTacToeResult.error(QUIT_COORDINATE, QUIT_COORDINATE, "It's not your turn!");
        }

        if (move == null || move.getPos() == null) {
            return TicTacToeResult.error(QUIT_COORDINATE, QUIT_COORDINATE, "Missing move data");
        }

        int row = move.getPos().row;
        int col = move.getPos().column;

        if (row == QUIT_COORDINATE) {
            return quit();
        }

        Player movingPlayer = currentPlayer;
        if (handleMove(move)) {
            if (status == GameStatus.DRAW) {
                return TicTacToeResult.draw(row, col);
            }
            if (hasWin() != null) {
                return finish(movingPlayer);
            }
            return TicTacToeResult.ongoing(row, col);
        }
        return TicTacToeResult.error(row, col, lastMoveError);
    }

    private boolean handleMove(GameMove move) {
        int row = move.getPos().row;
        int col = move.getPos().column;
        
        move.setServerAssignedPiece(currentPlayerPiece());

        MoveValidationResult result = validator.validateMove(
            getGameType(), gameState, currentPlayer.getID(), move
        );

        if (!result.isValid()) {
            lastMoveError = result.getMessage();
            return false;
        }

        board.updateCell(row, col, currentPlayerPiece());
        updateState();
        return true;
    }

    public TicTacToeResult quit() {
        return (TicTacToeResult) resign(currentPlayer);
    }

    @Override
    protected MoveResult resignSuccess(UserID winner, UserID loser) {
        return TicTacToeResult.gameOver(QUIT_COORDINATE, QUIT_COORDINATE, winner, loser);
    }

    @Override
    protected MoveResult resignFailure(String msg) {
        return TicTacToeResult.error(QUIT_COORDINATE, QUIT_COORDINATE, msg);
    }

    @Override
    protected MoveResult drawAgreedSuccess() {
        return TicTacToeResult.draw(QUIT_COORDINATE, QUIT_COORDINATE);
    }

    @Override
    protected MoveResult drawFailure(String msg) {
        return TicTacToeResult.error(QUIT_COORDINATE, QUIT_COORDINATE, msg);
    }

    private TicTacToeResult finish(Player winner) {
        Player loser = (winner == players[0]) ? players[1] : players[0];
        return TicTacToeResult.gameOver(QUIT_COORDINATE, QUIT_COORDINATE, winner.getID(), loser.getID());
    }
}
