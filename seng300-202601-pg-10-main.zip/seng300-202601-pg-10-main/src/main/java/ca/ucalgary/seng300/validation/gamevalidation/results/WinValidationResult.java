package ca.ucalgary.seng300.validation.gamevalidation.results;

import ca.ucalgary.seng300.validation.account.records.UserID;

public class WinValidationResult {
    private boolean hasWinner;
    private boolean isTie;
    private UserID winnerID;

    public WinValidationResult(boolean hasWinner, boolean isTie, UserID winnerID) {
        this.hasWinner = hasWinner;
        this.isTie = isTie;
        this.winnerID = winnerID;
    }

    public boolean hasWinner() { return hasWinner; }
    public boolean isTie() { return isTie; }
    public UserID getWinnerID() { return winnerID; }
}
