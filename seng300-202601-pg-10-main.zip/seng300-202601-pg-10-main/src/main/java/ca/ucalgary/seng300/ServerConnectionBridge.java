package ca.ucalgary.seng300;

import ca.ucalgary.seng300.logger.Logging;
import ca.ucalgary.seng300.network.Client;
import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * First-run UI for choosing how to reach the game server (local / IP / LAN discovery).
 */
public class ServerConnectionBridge extends BridgeBase {
    private static final java.util.logging.Logger logger = Logging.getLogger("ServerConnection");

    /** Incremented on each new user connect attempt; stale callbacks ignore results. */
    private final AtomicInteger connectionAttempt = new AtomicInteger(0);

    private boolean autoConnectAttempted;

    public ServerConnectionBridge(WebEngine engine) {
        super(engine);
    }

    public void attachBridge() {
        engine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState != Worker.State.SUCCEEDED) {
                return;
            }
            String loc = engine.getLocation();
            if (loc == null || !loc.contains("server-connection")) {
                return;
            }
            JSObject window = (JSObject) engine.executeScript("window");
            window.setMember("serverConnectionBridge", this);
            tryStartupAutoConnect();
        });
    }

    private void tryStartupAutoConnect() {
        if (autoConnectAttempted) {
            return;
        }
        String mode = MainApp.getStartupConnectMode();
        if ("none".equals(mode)) {
            return;
        }
        autoConnectAttempted = true;
        switch (mode) {
            case "local" -> connectLocal();
            case "auto" -> connectDiscover();
            case "ip" -> {
                String ip = MainApp.getStartupConnectIp();
                if (ip != null && !ip.isBlank()) {
                    connectWithIp(ip.trim());
                }
            }
            default -> { /* none */ }
        }
    }

    /** Connect to game server on this machine. */
    public void connectLocal() {
        int attempt = startAttempt();
        setUiStatus(attempt, "busy", "Connecting to localhost…");
        runConnectAsync(attempt, "localhost", () -> new Client("localhost"));
    }

    /** Connect to a server at the given host or IP. */
    public void connectWithIp(String hostOrIp) {
        if (hostOrIp == null || hostOrIp.isBlank()) {
            reportUiErrorNoAttempt("Enter a host or IP address.");
            return;
        }
        String h = hostOrIp.trim();
        int attempt = startAttempt();
        setUiStatus(attempt, "busy", "Connecting to " + h + "…");
        runConnectAsync(attempt, h, () -> new Client(h));
    }

    /** Discover a server on the LAN (UDP discovery / subnet scan per {@link Client}). */
    public void connectDiscover() {
        int attempt = startAttempt();
        setUiStatus(
                attempt,
                "busy",
                "Searching the LAN for a server… This can take 10–20 seconds."
        );
        new Thread(() -> {
            try {
                Client c = new Client();
                c.connect(true);
                Platform.runLater(() -> finishSuccess(attempt, c));
            } catch (Exception e) {
                Platform.runLater(() -> finishError(attempt, e.getMessage()));
            }
        }, "connect-discover").start();
    }

    private int startAttempt() {
        return connectionAttempt.incrementAndGet();
    }

    private boolean isStale(int attempt) {
        return attempt != connectionAttempt.get();
    }

    private void runConnectAsync(int attempt, String threadLabel, ClientSupplier supplier) {
        new Thread(() -> {
            try {
                Client c = supplier.get();
                c.connect(true);
                Platform.runLater(() -> finishSuccess(attempt, c));
            } catch (Exception e) {
                Platform.runLater(() -> finishError(attempt, e.getMessage()));
            }
        }, "connect-" + threadLabel).start();
    }

    private void finishSuccess(int attempt, Client c) {
        if (isStale(attempt)) {
            return;
        }
        MainApp.onServerConnected(c);
    }

    private void finishError(int attempt, String message) {
        if (isStale(attempt)) {
            return;
        }
        String m = message != null ? message : "Connection failed";
        logger.warning(m);
        setUiStatus(attempt, "error", m);
    }

    /** Validation error without starting a new attempt id (does not clear a running attempt). */
    private void reportUiErrorNoAttempt(String message) {
        String m = message != null ? message : "Connection failed";
        logger.warning(m);
        Platform.runLater(() -> {
            String msg = escapeJs(m);
            engine.executeScript("if(typeof setConnectionStatus==='function')setConnectionStatus('error','" + msg + "')");
        });
    }

    private void setUiStatus(int attempt, String kind, String message) {
        Platform.runLater(() -> {
            if (isStale(attempt)) {
                return;
            }
            String msg = escapeJs(message);
            String k = escapeJs(kind);
            engine.executeScript("if(typeof setConnectionStatus==='function')setConnectionStatus('" + k + "','" + msg + "')");
        });
    }

    @FunctionalInterface
    private interface ClientSupplier {
        Client get() throws Exception;
    }

    private static String escapeJs(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", "");
    }
}
