package ca.ucalgary.seng300.platformcore.game;

import java.io.Serializable;
import java.util.Objects;

public class GameMove implements Serializable {
    private static final long serialVersionUID = 1L;
    private GridSpace pos;

    private Piece serverAssignedPiece;

    public GameMove(GridSpace pos) {
        this.pos = pos;
    }

    public GameMove(GridSpace pos, Piece serverAssignedPiece) {
        this.pos = pos;
        this.serverAssignedPiece = serverAssignedPiece;
    }

    public GridSpace getPos() { return pos; }

    public Piece getServerAssignedPiece() { return serverAssignedPiece; }

    public void setServerAssignedPiece(Piece piece) {
        this.serverAssignedPiece = piece;
    }

    public void setRow(int row) {
        this.pos.row = row;
    }

    public String toString() {
        return (pos != null ? pos.toString() : "null") + " -> " + serverAssignedPiece;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        GameMove move = (GameMove) obj;
        if (pos == null) {
            return move.pos == null && Objects.equals(serverAssignedPiece, move.serverAssignedPiece);
        }
        if (move.pos == null) {
            return false;
        }
        return pos.row == move.pos.row
                && pos.column == move.pos.column
                && Objects.equals(serverAssignedPiece, move.serverAssignedPiece);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pos, serverAssignedPiece);
    }
}
