package ca.ucalgary.seng300.platformcore.game.connectfour;

import ca.ucalgary.seng300.platformcore.game.Piece;

public enum ConnectFourPiece implements Piece {
    RED,
    YELLOW;

    @Override
    public Piece opposite() {
        return switch (this) {
            case RED -> YELLOW;
            case YELLOW -> RED;
        };
    }

    @Override
    public String toString() {
        return switch (this) {
            case RED -> "RED";
            case YELLOW -> "YELLOW";
        };
    }

    @Override
    public char getSymbol() {
        return switch (this) {
            case RED -> 'R';
            case YELLOW -> 'Y';
        };
    }
}
