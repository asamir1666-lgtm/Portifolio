package ca.ucalgary.seng300.platformcore;

public enum MatchResult
{
    WIN, LOSS, DRAW;
}
