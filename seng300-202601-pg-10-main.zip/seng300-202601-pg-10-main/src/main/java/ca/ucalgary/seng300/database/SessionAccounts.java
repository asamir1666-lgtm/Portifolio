package ca.ucalgary.seng300.database;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;

public class SessionAccounts implements Serializable {
    private static final long serialVersionUID = 1L;

    private final LinkedHashMap<String, SessionToken> byUserId = new LinkedHashMap<>();
    private final LinkedHashMap<String, String> usernames = new LinkedHashMap<>();
    private String activeUserId;

    public int size() {
        return byUserId.size();
    }

    public void addOrUpdate(UserID userId, SessionToken token, String username) {
        if (userId == null || token == null) {
            return;
        }
        String id = userId.id();
        SessionToken copy = new SessionToken(token.tokenValue, token.userID);
        copy.createdAt = token.createdAt;
        byUserId.put(id, copy);
        if (username != null && !username.isBlank()) {
            usernames.put(id, username.trim());
        }
        activeUserId = id;
    }

    public void setActiveUserId(String userId) {
        if (userId != null && byUserId.containsKey(userId)) {
            activeUserId = userId;
        }
    }

    public String getActiveUserId() {
        return activeUserId;
    }

    public SessionToken getTokenForUser(String userId) {
        if (userId == null) {
            return null;
        }
        return byUserId.get(userId);
    }

    public SessionToken getActiveToken() {
        if (activeUserId == null) {
            return null;
        }
        return byUserId.get(activeUserId);
    }

    public SessionToken getOnlyToken() {
        if (byUserId.size() != 1) {
            return null;
        }
        return byUserId.values().iterator().next();
    }

    public String getOnlyUserId() {
        if (byUserId.size() != 1) {
            return null;
        }
        return byUserId.keySet().iterator().next();
    }

    public String displayName(String userId) {
        if (userId == null) {
            return "";
        }
        String u = usernames.get(userId);
        if (u != null && !u.isEmpty()) {
            return u;
        }
        return userId.length() > 10 ? userId.substring(0, 8) + "…" : userId;
    }

    public void removeAccount(String userId) {
        if (userId == null) {
            return;
        }
        byUserId.remove(userId);
        usernames.remove(userId);
        if (userId.equals(activeUserId)) {
            activeUserId = byUserId.isEmpty() ? null : byUserId.keySet().iterator().next();
        }
    }

    public List<Map.Entry<String, SessionToken>> orderedEntries() {
        return new ArrayList<>(byUserId.entrySet());
    }
}
