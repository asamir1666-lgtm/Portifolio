package ca.ucalgary.seng300.platformcore.game;

import ca.ucalgary.seng300.platformcore.Misc;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.platformcore.GameType;

import java.io.Serializable;
import java.util.HashMap;

public class GameState implements Serializable {
    private static final long serialVersionUID = 1L;
    private Piece[][] gameBoard;
    private GameType gameType;
    private UserID[] playerIDs;
    private HashMap<UserID, ? extends Piece> playerIDToPiece;

    public GameState(GameType gameType, UserID[] playerIDs, HashMap<UserID, ? extends Piece> playerIDToPiece, Piece[][] gameBoard) {
        this.gameType = gameType;
        this.playerIDs = playerIDs;
        this.playerIDToPiece = playerIDToPiece;
        this.gameBoard = gameBoard;
    }

    public GameState(GameState state) {
        gameType = state.gameType;
        playerIDs = state.playerIDs;
        playerIDToPiece = state.playerIDToPiece;
        gameBoard = Misc.copyBoard(state.gameBoard);
    }

    public Piece[][] getGameBoard() { return gameBoard; }
    public GameType getGameType() { return gameType; }
    public UserID[] getPlayerIDs() { return playerIDs; }
    public HashMap<UserID, ? extends Piece> getPlayerIDToPiece() { return playerIDToPiece; }
}
