package ca.ucalgary.seng300.database;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.ParameterizedType;

import ca.ucalgary.seng300.Config;

/**
 * Abstract class representing a generic database 
 * This class provides basic functionality for handling file based databases
 */
public abstract class Database <T extends Serializable> {
    private static final HashMap<Class<? extends Database<?>>, Database<?>> instances = new HashMap<>();
    
    protected final Class<T> type;
    protected String databaseName;

    private T data;

    @SuppressWarnings("unchecked")
    protected Database(String databaseName) {
        this.type = (Class<T>) ((ParameterizedType) getClass()
            .getGenericSuperclass())
            .getActualTypeArguments()[0];
        this.databaseName = databaseName;
    }

    /**
     * Read the serialized data from the database file
     * @param file The file to read from
     * @return The deserialized data from the file
     * @throws RuntimeException if the file cannot be read
    */
    private T deserialize(File file) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            Object obj = in.readObject();
            if (!type.isInstance(obj)) {
                throw new RuntimeException("Expected " + type.getName() + ", got " + obj.getClass().getName());
            }
            return type.cast(obj);
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException("Failed to read " + this.databaseName, e);
        }
    }

    /**
     * Serialize the given data and write it to the database file
     * @param data The data to serialize and write
     * @param file The file to write to
     * @throws RuntimeException if the file cannot be written to
    */
    private void serialize(T data, File file) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
            out.writeObject(data);
        } catch (IOException e) {
            throw new RuntimeException("Failed to write " + this.databaseName, e);
        }
    }

    // Need to implement this so it knows the default data to 
    // initialize the database with if the file is empty
    protected abstract T getDefaultData();

    /**
     * Retrieves the current state of the database data.
     * If the data has not been loaded, this method will throw an IllegalStateException.
     * @return The current state of the database data.
     */
    public T getData() {
        if (this.data == null) {
            throw new IllegalStateException("Database not connected. Please connect to the database before reading.");
        }
        return this.data;
    }

    /**
     * Saves the current state of the serialized data to the file system.
     * This method should be called after any modifications to the database data to ensure that changes are persisted.
     */
    public void save() {
        serialize(this.data, this.getDatabaseFile());
    }

    /**
     * Retrieves the singleton instance of the specified database class.
     * If an instance does not already exist, it will create a new one and store it in the instances map.
     * @param dbClass The class of the database to retrieve an instance of.
     * @return The singleton instance of the specified database class.
     */
    public static <D extends Database<?>> D getInstance(Class<D> dbClass) {
        if (!instances.containsKey(dbClass)) {
            try {
                Constructor<D> constructor = dbClass.getDeclaredConstructor();
                constructor.setAccessible(true);
                instances.put(dbClass, constructor.newInstance());
            } catch (Exception e) {
                throw new RuntimeException("Failed to create instance of " + dbClass.getName(), e);
            }
        }
        return dbClass.cast(instances.get(dbClass));
    }

    /** Clears singleton cache so the next {@link #getInstance} creates fresh objects (for tests). */
    public static void resetInstances() {
        instances.clear();
    }

    /**
     * Retrieves the file associated with this database. 
     * If the file does not exist, it will be created.
     * @return The File object representing the database file.
     * @throws RuntimeException if the file cannot be created.
     */
    private File getDatabaseFile() {
        File folder = new File(Config.DATABASE_FOLDER);
        if (!folder.exists()) folder.mkdirs();
        File file = new File(folder, this.databaseName);
        try {
            if (!file.exists()) file.createNewFile();
        } catch (IOException e) {
            throw new RuntimeException("Cannot create database file: " + this.databaseName, e);
        }
        return file;
    }
    
    /**
     * Initializes the database by loading data from the file.
     * If the file is empty or corrupt, it initializes the database with default data
     * and saves it to the file system.
     */
    public void connect() {
        File file = this.getDatabaseFile();
        if (file.length() > 0) {
            try {
                this.data = deserialize(file);
                return;
            } catch (RuntimeException e) {
                System.err.println("[Database] Failed to load " + this.databaseName
                        + " (file may be corrupt or incompatible after a code change): " + e.getMessage());
                System.err.println("[Database] Re-initializing " + this.databaseName + " with defaults.");
            }
        }
        this.data = this.getDefaultData();
        this.save();
    }
}
