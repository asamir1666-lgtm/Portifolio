package ca.ucalgary.seng300.network.handler.server;

import ca.ucalgary.seng300.database.LobbyDatabase;
import ca.ucalgary.seng300.network.ClientData;
import ca.ucalgary.seng300.network.message.Payload;
import ca.ucalgary.seng300.network.message.Payload.Error;
import ca.ucalgary.seng300.network.message.Payload.Matchmaking.Req;
import ca.ucalgary.seng300.network.message.Payload.Matchmaking.Res;
import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.LobbyRoom;
//import ca.ucalgary.seng300.platformcore.LobbyDatabase;
import ca.ucalgary.seng300.platformcore.LobbyManager;
import ca.ucalgary.seng300.platformcore.Match;
import ca.ucalgary.seng300.platformcore.MatchQueue;
import ca.ucalgary.seng300.platformcore.MatchmakingManager;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.platformcore.PlayerState;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class MatchmakingHandler extends ServerHandler<Req, Payload.Response> {
    private final Map<GameType, MatchmakingManager> managers = new EnumMap<>(GameType.class);
    private final ca.ucalgary.seng300.database.LobbyDatabase lobbyDatabase;

    public MatchmakingHandler(ca.ucalgary.seng300.database.LobbyDatabase lobbyDatabase) {
        this.lobbyDatabase = lobbyDatabase;
        for (GameType type : GameType.values()) {
            managers.put(type, new MatchmakingManager(type, new MatchQueue()));
        }
    }

    @Override
    public Payload.Response handle(Req req, ClientData clientData) {
        return switch (req) {
            case Req.Join r  -> handleJoin(r, clientData);
            case Req.Leave r -> handleLeave(r, clientData);
        };
    }

    private Payload.Response handleJoin(Req.Join join, ClientData clientData) {
        Player player = clientData.getPlayer();
        if (player.getLobbyId() != null || player.getState() != PlayerState.DASHBOARD) {
            return new Error("Player must be on dashboard to join matchmaking.");
        }

        GameType gameType = join.gameType();
        MatchmakingManager manager = managers.get(gameType);
        if (manager == null) {
            return new Error("Unsupported game type: " + gameType);
        }

        Optional<Match> maybeMatch = manager.joinAndMatch(player);
        if (maybeMatch.isEmpty()) {
            return new Res.Queued();
        }

        Match match = maybeMatch.get();
        List<Player> players = match.getPlayers();

        Player opponent = players.stream()
                .filter(p -> !p.equals(player))
                .findFirst()
                .orElse(null);

        if (opponent == null) {
            return new Error("Match formed but opponent was missing.");
        }

        LobbyManager lobbyManager = lobbyDatabase.getData();
        LobbyRoom lobby = lobbyManager.newLobby(gameType, 2);

        lobby.addHost(player);
        lobby.admitPlayer(opponent, "");

        lobbyDatabase.save();

        return new Payload.Compound(new Payload.Response[] {
                new Res.Matched(lobby.getID(), opponent.getID(), lobby),
                new Payload.Direct(opponent.getID(), new Res.Matched(lobby.getID(), player.getID(), lobby))
        });
    }

    private Payload.Response handleLeave(Req.Leave leave, ClientData clientData) {
        Player player = clientData.getPlayer();
        if (player == null) {
            return new Error("Player not found. Please log in first.");
        }

        MatchmakingManager manager = managers.get(leave.gameType());
        if (manager == null) {
            return new Error("Unsupported game type: " + leave.gameType());
        }

        manager.leave(player);
        return new Res.Left();
    }

    public void unregisterPlayer(Player player) {
        if (player == null) return;
        for (MatchmakingManager manager : managers.values()) {
            manager.leave(player);
        }
    }
}
