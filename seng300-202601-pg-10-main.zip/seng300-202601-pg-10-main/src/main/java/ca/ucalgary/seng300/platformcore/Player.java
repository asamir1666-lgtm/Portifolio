package ca.ucalgary.seng300.platformcore;

import java.io.Serializable;

import ca.ucalgary.seng300.validation.account.records.UserID;

public class Player implements Serializable {
    private static final long serialVersionUID = 1L;
    private PlayerState state;
    private UserID ID;
    private PlayerStats stats;
    private LobbyID lobbyId;
    private String username;
    private boolean isBot;
    /** Set after a game ends; cleared when a new match starts in the lobby. */
    private boolean rematchVote;

    public Player (UserID id, String username)
    {
        this.ID = id;
        this.isBot = false;
        this.username = username;
        this.stats = new PlayerStats();
        this.state = PlayerState.DASHBOARD;
    }

    public void setAsBot() {
        this.isBot = true;
    }

    public boolean isBot() {
        return isBot;
    }

    public UserID getID() {
        return ID;
    }

	public String getUsername() {
        return username;
    }

	public void setID(UserID iD) {
		ID = iD;
	}

    public LobbyID getLobbyId() {
        return lobbyId;
    }

    public Player(PlayerStats statsPerGame) {
        this.stats = statsPerGame;
        this.state = PlayerState.DASHBOARD;
    }

    public PlayerState getState() {
        return state;
    }

    public boolean isReadyForMatch() {
        return state == PlayerState.READY_FOR_MATCH;
    }

    public void playGame(){
        // Dont know if UI has the ready yet?
        // if (state != PlayerState.READY_FOR_MATCH) {
        //     throw new IllegalStateException("Player must be ready for match to play game");
        // }
        this.state = PlayerState.IN_GAME;
    }

    public void joinLobby(LobbyID lobbyId) {
        assert state == PlayerState.DASHBOARD || state == PlayerState.POST_GAME
                : "Player must be on dashboard or post-game to join lobby";
        this.lobbyId = lobbyId;
        this.state = PlayerState.IN_LOBBY;
    }

    public void leaveLobby() {
        assert state == PlayerState.IN_LOBBY || state == PlayerState.READY_FOR_MATCH
                : "Player must be in lobby to leave lobby";
        this.lobbyId = null;
        this.state = PlayerState.DASHBOARD;
    }

    public void readyForMatch() {
        assert state == PlayerState.IN_LOBBY : "Player must be in lobby to be ready for match";
        state = PlayerState.READY_FOR_MATCH;
    }

    /** Return to not-ready while still in the waiting room (before the match starts). */
    public void cancelReady() {
        if (state == PlayerState.READY_FOR_MATCH) {
            state = PlayerState.IN_LOBBY;
        }
    }

    public void redirectToDashboard() {
        this.lobbyId = null;
        this.state = PlayerState.DASHBOARD;
    }

    public void setState(PlayerState state) {
        assert state != PlayerState.READY_FOR_MATCH : "Use readyForMatch() for READY_FOR_MATCH";
        this.state = state;
    }

    public PlayerStats getStats() {
        return stats;
    }

    public GameStats getGameStats(GameType gameType) {
        return stats.getStatsForGame(gameType);
    }

    public void setGameStats(GameType gameType, GameStats stats) {
        this.stats.updateStatsForGame(gameType, stats);
    }

    public void setStats(PlayerStats stats) {
        this.stats = stats;
    }

    public boolean hasRematchVote() {
        return rematchVote;
    }

    public void markRematchVote() {
        assert state == PlayerState.POST_GAME : "Rematch vote only after a finished game";
        this.rematchVote = true;
    }

    public void clearRematchVote() {
        this.rematchVote = false;
    }

    public void recordResult(GameType gameType, MatchResult result, int newElo) {
        GameStats stats = getGameStats(gameType);

        switch (result) {
            case WIN -> stats.recordWin();
            case LOSS -> stats.recordLoss();
            case DRAW -> stats.recordDraws();
        }
        stats.setEloRating(newElo);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Player other)) return false;
        return ID.equals(other.ID);
    }

    @Override
    public int hashCode() {
        return ID.hashCode();
    }

    @Override
    public String toString() {
        return "Player{id=" + ID + "}";
    }
}
