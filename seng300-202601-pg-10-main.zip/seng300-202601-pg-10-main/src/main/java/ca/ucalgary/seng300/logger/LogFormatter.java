package ca.ucalgary.seng300.logger;

import java.util.logging.*;
import java.time.*;
import java.time.format.*;

public class LogFormatter extends Formatter {
    private static final DateTimeFormatter dtf = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
                         .withZone(ZoneId.systemDefault());

    @Override
    public String format(LogRecord record) {
        String timestamp = dtf.format(Instant.ofEpochMilli(record.getMillis()));
        String thread = Thread.currentThread().getName();
        String source = record.getLoggerName()
                            .replaceAll(".*\\.", "");

        return String.format("[%s] [%s] [%s] [%s] %s%n",
            timestamp,
            record.getLevel(),
            thread,
            source,
            formatMessage(record)
        );
    }
}
