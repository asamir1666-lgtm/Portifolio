package ca.ucalgary.seng300.platformcore;

/*
 * ELO-based matchmaking strategy with time-based tolerance widening.
 * When a player first enters the queue, only opponents within a tight ELO window
 * are considered. As the player waits longer, the acceptable ELO difference
 * gradually increases to a defined maximum so that long-waiting players
 * are eventually matched rather than left in queue indefinitely.
*/

import java.util.List;
import java.util.Optional;

public class EloMatchmaking implements MatchMakerStrategy
{
    private static final int BASE_ELO_DIFF = 100;

    private static final int MAX_ELO_DIFF = 500; // can't go above this at any cost

    private static final int ELO_GROWTH_PER_SECOND = 10;

    private final GameType gameType;

    public EloMatchmaking (GameType gameType)
    {
        this.gameType = gameType;
    }

    @Override
    public Optional<List<Player>> pickPlayersForMatch(List<QueueEntry> queueSnapshot)
    {
        int size = queueSnapshot.size();

        if (size < 2)
        {
            return Optional.empty();
        }

        for (int i = 0; i < size; i ++)
        {
            QueueEntry entry1 = queueSnapshot.get(i);
            Player player1 = entry1.getPlayer();
            int allowedDiff = computeAllowedDiff(entry1.getWaitSeconds());

            for (int j = i + 1; j < size; j++)
            {
                QueueEntry entry2 = queueSnapshot.get(j);
                Player player2 = entry2.getPlayer();

                if (isCompatible(player1, player2, allowedDiff))
                {
                    return Optional.of(List.of(player1, player2));
                }
            }
        }
        return Optional.empty();
    }


    private int computeAllowedDiff(long waitSeconds)
    {
        int diff = BASE_ELO_DIFF + (int)(waitSeconds * ELO_GROWTH_PER_SECOND);
        return Math.min(diff, MAX_ELO_DIFF);
    }

    private boolean isCompatible (Player player1, Player player2, int allowedDiff)
    {
        int player1Diff = player1.getGameStats(gameType).getEloRating();
        int player2Diff = player2.getGameStats(gameType).getEloRating();

        return Math.abs(player1Diff-player2Diff) <= allowedDiff;

    }
}

