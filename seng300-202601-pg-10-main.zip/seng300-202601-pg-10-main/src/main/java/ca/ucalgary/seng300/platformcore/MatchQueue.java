package ca.ucalgary.seng300.platformcore;

// Matchmaking queue for Players. Tracks what players are activiely queued and stores their QueueEntry

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.locks.ReentrantLock;

public class MatchQueue
{
    private final LinkedHashMap<Player, QueueEntry> queue = new LinkedHashMap<>();
    private final ReentrantLock lock = new ReentrantLock();

    // add a player to the queue, if the player is already queued, this is a no-op and returns false. Return true if
    // the player was successfully added, false if already in queue
    public boolean enqueue(Player player)
    {
        lock.lock();

        try{
            if (queue.containsKey(player))
            {
                return false;
            }
            queue.put(player, new QueueEntry(player));
            return true;
        }
        finally
        {
            lock.unlock();
        }
    }

    public boolean remove(Player player)
    {
        lock.lock();
        try {
            return queue.remove(player) != null;
        } finally {
            lock.unlock();
        }
    }

    // atomically removes all matched players from the queue. if any of the matched players are no longer in the queue, nothing is removed
    // and false is returned preventing races where a player leaves between snapshot and removal. returns true if all players are present
    // and successfully removed

    public boolean removeMatchedPlayers(Collection<Player> players)
    {
        Objects.requireNonNull(players);
        lock.lock();
        try
        {
            if (!queue.keySet().containsAll(players))
            {
                return false;
            }
            players.forEach(queue::remove);
            return true;
        }
        finally
        {
            lock.unlock();
        }
    }

    // returns an immutable snapshot of the current queue entries. the snapshot includes insertion order and wait-time
    // info so strategies can apply time-based ELO widening.
    public List<QueueEntry> snapshot()
    {
        lock.lock();
        try
        {
            return List.copyOf(queue.values());
        }
        finally
        {
            lock.unlock();
        }
    }

    // returns the current number of players in the queue
    public int size()
    {
        lock.lock();
        try
        {
            return queue.size();
        }
        finally
        {
            lock.unlock();
        }
    }
}
