package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.platformcore.QueueEntry;

import java.util.List;
import java.util.Optional;

// Strategy interface for picking a set of players from the current queue to form a match.
public interface MatchMakerStrategy
{
    Optional<List<Player>> pickPlayersForMatch(List<QueueEntry> queueSnapshot);
}
