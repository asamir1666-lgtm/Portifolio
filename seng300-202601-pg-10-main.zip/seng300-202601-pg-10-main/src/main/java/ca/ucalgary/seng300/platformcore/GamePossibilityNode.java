package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.platformcore.game.GameMove;
import ca.ucalgary.seng300.platformcore.game.GameState;
import ca.ucalgary.seng300.platformcore.game.Piece;
import ca.ucalgary.seng300.validation.gamevalidation.GameValidation;
import ca.ucalgary.seng300.validation.gamevalidation.results.WinValidationResult;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class GamePossibilityNode implements Serializable {
  private final GameState gameState;
  private final GameType gameType;
  private final Player player;
  private final Player opponent;
  private final ArrayList<GamePossibilityNode> children;
  private final GameMove move;
  private int height;
  private ArrayList<GameMove> bestMoves;
  private final int difficulty;

  public GamePossibilityNode(GameState gameState, GameMove move, Player player, Player opponent, int height, int difficulty) {
    this.gameState = gameState;
    gameType = gameState.getGameType();
    this.move = move;
    if (move != null) {
      gameState.getGameBoard()[move.getPos().row][move.getPos().column] = move.getServerAssignedPiece();
    }
    this.player = player;
    this.opponent = opponent;
    children = new ArrayList<>();
    this.difficulty = difficulty;
    this.height = height;
    bestMoves = new ArrayList<>();
  }

  public GamePossibilityNode getChild(GameState state) {
    for (GamePossibilityNode child : children) {
      if (child.gameState.equals(state)) {
        return child;
      }
    }
    return null;
  }

  /**
   * evaluates the score of a node
   * @param alpha set to Integer.MIN_VALUE
   * @param beta set to Integer.MAX_VALUE
   * @return evaluation score
   */
  public int evaluateNode(int alpha, int beta) { //algorithm assistance from AI
    GameValidation validation = new GameValidation();

    if (height == 0 || validation.validateWin(gameState, gameState.getPlayerIDToPiece()).hasWinner()) {
      return getTerminalScore();
    }

    boolean isBot = player instanceof Bot;
    int bestScore = isBot ? Integer.MIN_VALUE : Integer.MAX_VALUE;

    ArrayList<GameMove> bestMoves = new ArrayList<>();
    int maxChildren = 5;

    ArrayList<GameMove> possibleMoves = Bot.getPossibleMoves(gameState, getPlayerPiece(player));
    for (Piece piece : new ArrayList<>(List.of(getPlayerPiece(player), getPlayerPiece(opponent)))) {
      GameMove forcedMove = Bot.findForcedMove(gameState.getGameBoard(), piece, getPlayerPiece(player), gameType == GameType.TICTACTOE ? 3 : 4);
      if (forcedMove != null) {
        double mistakeThreshold = 0.7 * Math.exp((double) difficulty / 20); //chance of finding forced move - 75% at difficulty 2, 100% at difficulty 7
        Random rand = new Random();
        if (rand.nextDouble() <= mistakeThreshold) {
          possibleMoves = new ArrayList<>(List.of(forcedMove)); //replaces move set with forced move if one exists
          break;
        }
      }
    }

    for (GameMove move : possibleMoves) {
      GameState newState = new GameState(gameState);
      newState.getGameBoard()[move.getPos().row][move.getPos().column] = move.getServerAssignedPiece();

      GamePossibilityNode child = new GamePossibilityNode(newState, move, opponent, player, height - 1, difficulty);
      int score = child.evaluateNode(alpha, beta);

      //optional - only stores good children
      if (children.size() < maxChildren || (isBot && score >= bestScore) || (!isBot && score <= bestScore)) {
        children.add(child);
      }

      if (isBot) {
        if (score >= bestScore) {
          bestScore = score;
          bestMoves.addFirst(move);
          if (bestMoves.size() > maxChildren) {
            bestMoves.removeLast();
          }
        }

        alpha = Math.max(alpha, bestScore);

      } else {
        if (score <= bestScore) {
          bestScore = score;
          bestMoves.addFirst(move);
          if (bestMoves.size() > maxChildren) {
            bestMoves.removeLast();
          }
        }

        if (bestMoves.isEmpty()) {
          bestMoves.add(move);
        }

        beta = Math.min(beta, bestScore);
      }

      if (alpha >= beta) {
        break;
      }
    }

    this.bestMoves = bestMoves;
    return bestScore;
  }

  public int getTerminalScore() {
    GameValidation validation = new GameValidation();
    WinValidationResult result = validation.validateWin(gameState, gameState.getPlayerIDToPiece());
    Player bot = player instanceof Bot ? player : opponent;

    if (result.hasWinner()) {
      if (result.getWinnerID().equals(bot.getID())) { //bot won
        return 10000;
      }
      else { //human won
        return -10000;
      }
    }
    else if (validation.isBoardFull(gameState.getGameBoard())) {
      return 0; //draw
    }
    if (gameType == GameType.CONNECTFOUR) {
      return BotWeightDetection.C4_advancedPlayerScore(gameState, getPlayerPiece(getBot(player, opponent)));
    }
    return BotWeightDetection.TTT_calculatePlayerScore(gameState, getPlayerPiece(getBot(player, opponent)));
  }

  public GameMove chooseMove() { //algorithm assistance from AI, chooses move with chance of choosing suboptimal moves based on difficulty
    if (bestMoves == null || bestMoves.isEmpty()) {
      ArrayList<GameMove> fallback = Bot.getPossibleMoves(gameState, getPlayerPiece(getBot(player, opponent)));
      if (!fallback.isEmpty()) {
        return fallback.get(new Random().nextInt(fallback.size()));
      }
      throw new IllegalStateException("No legal moves available for bot");
    }

    double mistakeChance = 0.5*Math.pow((double) (10 - difficulty)/7, 2);
    mistakeChance = Math.clamp(mistakeChance, 0, 1); //clamps chance to [0,1]

    Random rand = new Random();

    if (rand.nextDouble() > mistakeChance) {
      return bestMoves.getFirst();
    }

    double lambda = 0.6 + 5 * (1-mistakeChance);
    int numMoves = bestMoves.size();

    double[] weights = new double[numMoves];
    double sum = 0;

    for (int k = 1; k < numMoves; k++) {
      weights[k] = Math.exp(-lambda * (k-1));
      sum += weights[k];
    }

    double r = rand.nextDouble() * sum;
    double cumulative = 0;

    for (int k = 1; k < numMoves; k++) {
      cumulative += weights[k];
      if (r <= cumulative) {
        return bestMoves.get(k);
      }
    }

    return bestMoves.getFirst();
  }

  private Piece getPlayerPiece(Player player) {
    return gameState.getPlayerIDToPiece().get(player.getID());
  }

  private Player getBot(Player player1, Player player2) {
    return player1 instanceof Bot ? player1 : player2;
  }

  public void setHeight(int height) {
    this.height = height;
  }
}
