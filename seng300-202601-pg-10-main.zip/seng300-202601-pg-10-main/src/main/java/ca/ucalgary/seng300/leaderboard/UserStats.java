package ca.ucalgary.seng300.leaderboard;

//will need to change class name depending on platform core
public class UserStats {
    private final String currentRank;
    private final int eloRating;
    private final int wins;
    private final int losses;
    private final String winRate;
    private final int totalGamesPlayed;

    public UserStats(String currentRank, int eloRating, int wins, int losses, String winRate, int totalGamesPlayed) {
        this.currentRank = currentRank;
        this.eloRating = eloRating;
        this.wins = wins;
        this.losses = losses;
        this.winRate = winRate;
        this.totalGamesPlayed = totalGamesPlayed;
    }

    public String getCurrentRank() {
        return currentRank;
    }

    public int getEloRating() {
        return eloRating;
    }

    public int getWins() {
        return wins;
    }

    public int getLosses() {
        return losses;
    }

    public String getWinRate() {
        return winRate;
    }

    public int getTotalGamesPlayed() {
        return totalGamesPlayed;
    }
}
