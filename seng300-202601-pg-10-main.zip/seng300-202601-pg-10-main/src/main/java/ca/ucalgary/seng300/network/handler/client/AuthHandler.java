package ca.ucalgary.seng300.network.handler.client;

import java.util.Objects;
import java.util.function.Consumer;

import ca.ucalgary.seng300.network.message.Payload.Auth.Res;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;
import ca.ucalgary.seng300.network.message.Payload.Auth.Req;

public class AuthHandler extends ClientHandler<Res>{
    private Consumer<Res.Login>         onLogin;
    private Consumer<Res.Logout>        onLogout;
    private Consumer<Res.Signup>        onSignup;
    private Consumer<Res.LoginToken>    onLoginToken; 
    private Consumer<Res.Error>         onError;

    public void setOnLogin(Consumer<Res.Login> cb)              { this.onLogin = cb; }
    public void setOnLogout(Consumer<Res.Logout> cb)            { this.onLogout = cb; }
    public void setOnSignup(Consumer<Res.Signup> cb)            { this.onSignup = cb; }
    public void setOnLoginToken(Consumer<Res.LoginToken> cb)    { this.onLoginToken = cb; }
    public void setOnError(Consumer<Res.Error> cb)              { this.onError = cb; }
    
	@Override
	public void handle(Res serverResponse) {
		switch (serverResponse) {
		    case Res.Login r        -> onLogin.accept(r);
		    case Res.Logout r       -> onLogout.accept(r);
		    case Res.Signup r       -> onSignup.accept(r);
		    case Res.LoginToken r   -> onLoginToken.accept(r);
		    case Res.Error e        -> onError.accept(e);
        }
	}

	public void createAccount(String username, String password) {
        Req.Signup req = new Req.Signup(username, password);
        this.sender.accept(req);
    }

    public void login(String username, String password) {
        Req.Login req = new Req.Login(username, password);
        this.sender.accept(req);
    }

    public void loginWithToken(SessionToken token) {
        Req.LoginToken req = new Req.LoginToken(token);
        this.sender.accept(req);
    }

	@Override
	public void validate() {
	    Objects.requireNonNull(onLogin,         "AuthHandler: onLogin not set");
        Objects.requireNonNull(onLogout,        "AuthHandler: onLogout not set");
        Objects.requireNonNull(onSignup,        "AuthHandler: onSignup not set");
        Objects.requireNonNull(onLoginToken,    "AuthHandler: onLoginToken not set");
        Objects.requireNonNull(onError,         "AuthHandler: onError not set");
	}
}



