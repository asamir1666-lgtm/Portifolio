package ca.ucalgary.seng300.platformcore;

import java.util.List;
import java.util.Optional;

public class MatchmakingManager
{

    // Minimum number of players in the queue before matchmaking is attempted
    private static final int MIN_QUEUE_SIZE = 2;

    private final GameType gameType;
    private final MatchQueue queue;
    private volatile MatchMakerStrategy strategy;

    public MatchmakingManager(GameType gameType, MatchQueue queue)
    {
        this.gameType = gameType;
        this.queue = queue;
        this.strategy = new EloMatchmaking(gameType);
    }

    public GameType getGameType()
    {
        return gameType;
    }

    public MatchMakerStrategy getStrategy()
    {
        return strategy;
    }


//     Allows the strategy to be swapped at runtime if needed (e.g., testing or future modes).

    public void setStrategy(MatchMakerStrategy strategy)
    {
        this.strategy = strategy;
    }

    /**
     * Attempts to find and create a match immediately using the current strategy.
     * Only runs if the minimum queue size threshold is met.
     *
     * @return an Optional containing the formed Match, or empty if no valid pairing was found
     */
    public Optional<Match> findMatchNow()
    {
        if (queue.size() < MIN_QUEUE_SIZE)
        {
            return Optional.empty();
        }

        List<QueueEntry> snapshot = queue.snapshot();
        Optional<List<Player>> maybePlayers = strategy.pickPlayersForMatch(snapshot);

        if (maybePlayers.isEmpty()) {
            return Optional.empty();
        }

        List<Player> chosen = maybePlayers.get();

        // Atomically remove matched players; if any have left since snapshot, abort
        boolean removed = queue.removeMatchedPlayers(chosen);
        if (!removed)
        {
            return Optional.empty();
        }

        return Optional.of(new Match(gameType, chosen));
    }

    /**
     * Adds a player to the queue and immediately attempts to form a match.
     * A match is not guaranteed — the player may simply be queued if no
     * suitable opponent is currently available.
     *
     * @return an Optional containing the formed Match, or empty if no match was made
     */
    public Optional<Match> joinAndMatch(Player player)
    {
        boolean added = queue.enqueue(player);
        if (!added)
        {
            return Optional.empty();
        }
        return findMatchNow();
    }

    /**
     * Removes a player from the queue (they are cancelling matchmaking).
     *
     * @return true if the player was in the queue and was removed
     */
    public boolean leave(Player player)
    {
        return queue.remove(player);
    }
}

