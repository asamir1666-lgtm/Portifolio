package ca.ucalgary.seng300.validation.account.stubs;

import java.io.Serializable;

import ca.ucalgary.seng300.validation.account.records.UserID;

public class UserProfile implements Serializable {
    private static final long serialVersionUID = 1L;
    public UserID userID;
    public String username;

    public UserProfile(UserID userID, String username) {
        this.userID = userID;
        this.username = username;
    }
}
