package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.validation.account.AccountValidation;
import ca.ucalgary.seng300.validation.account.results.AccountValidationResult;


/**
 * THIS MAY ALL CHANGE OR NOT BE NEEDED IF I DECIDE TO JUAT USE THE authHandler
 */



public class Login {

    // Tracks the current state of the login flow
    private LoginState state;

    // Stores the most recent error message from a failed login attempt
    private String lastError;

    // Stores the usernamec of the currently logged in player
    private String currentUsername;

    // real validation dependency
    private final AccountValidation accountValidation;

    // Constructor: sets the initial values when a Login object is created
    public Login(AccountValidation accountValidation) {
        // User starts off logged out
        this.state = LoginState.LOGGED_OUT;

        // No error yet at startup
        this.lastError = "";

        // No current user at startup
        this.currentUsername = null;

        // Save the validation/checking dependency
        this.accountValidation = accountValidation;
    }

    // Returns the current login state
    public LoginState getState() {
        return state;
    }

    // Returns the most recent login error message
    public String getLastError() {
        return lastError;
    }

    // Returns the username of the logged-in user, if there is one
    public String getCurrentUsername() {
        return currentUsername;
    }

    /** Main login method
     * Takes the username/password from UI and attempts to log in using validation
     */
    public AccountValidationResult userLoginCreds(String username, String password) {
        // As soon as a login attempt starts, mark it as pending
        state = LoginState.LOGIN_PENDING;
        // Clear any previous error before a new attempt
        lastError = "";

        AccountValidationResult result = accountValidation.validateLogin(username,password);

        if (result == null) {
            // Login failed
            state = LoginState.LOGIN_FAILED;
            currentUsername = null;
            lastError = "Login validation is not available";
            return null;
        }

        if (result.isValid) {
            state = LoginState.LOGGED_IN;
            currentUsername = username;
        } else {
            state = LoginState.LOGIN_FAILED;
            currentUsername = null;
            lastError = result.message;
        }

        return result;
    }

    // Logs the current user out and resets login-related fields
    public void logout() {
        state = LoginState.LOGGED_OUT;
        currentUsername = null;
        lastError = "";
    }
}
