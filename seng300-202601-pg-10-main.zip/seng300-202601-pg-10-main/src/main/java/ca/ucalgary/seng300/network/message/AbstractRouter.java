package ca.ucalgary.seng300.network.message;

import ca.ucalgary.seng300.logger.Logging;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.logging.Logger;
import java.util.HashMap;
import java.util.Map;

public abstract class AbstractRouter<H>{
    // Payload type to handler mapping.
    protected final Map<Class<?>, H> handlers = new HashMap<>();

    // Handler class to handler instance mapping.
    protected final Map<Class<?>, H> handlerInstances = new HashMap<>();
    
    protected final static Logger logger = Logging.getLogger("MessageRouter");

    public void register(H handler) {
        Type generic = ((ParameterizedType) handler
                            .getClass()
                            .getGenericSuperclass())
                            .getActualTypeArguments()[0];
        handlers.put((Class<?>) generic, handler);
        handlerInstances.put(handler.getClass(), handler);
    }

    private H resolveUnknown(Class<?> original, Class<?> current) {
        if (current == null) return null;
        H handler = handlers.get(current);
        if (handler != null) {
            handlers.put(original, handler);
            return handler;
        }
        for (Class<?> iface : current.getInterfaces()) {
            handler = handlers.get(iface);
            if (handler != null) {
                handlers.put(original, handler);
                return handler;
            }
        }
        return resolveUnknown(original, current.getSuperclass());
    }

    protected H resolveUnknown(Class<?> payloadType) {
        return resolveUnknown(payloadType, payloadType);
    }

    @SuppressWarnings("unchecked")
    public <E extends H> E getHandler(Class<?> type) { 
        return (E) handlerInstances.get(type);
    }
}

