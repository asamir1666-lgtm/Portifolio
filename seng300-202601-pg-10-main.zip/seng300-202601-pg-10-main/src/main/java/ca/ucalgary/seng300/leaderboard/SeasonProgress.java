package ca.ucalgary.seng300.leaderboard;

//will need to change class name depending on platform core
public class SeasonProgress {
    private final String nextRank;
    private final int eloNeeded;
    private final String seasonEndsIn;

    public SeasonProgress(String nextRank, int eloNeeded, String seasonEndsIn) {
        this.nextRank = nextRank;
        this.eloNeeded = eloNeeded;
        this.seasonEndsIn = seasonEndsIn;
    }

    public String getNextRank() {
        return nextRank;
    }

    public int getEloNeeded() {
        return eloNeeded;
    }

    public String getSeasonEndsIn() {
        return seasonEndsIn;
    }
}