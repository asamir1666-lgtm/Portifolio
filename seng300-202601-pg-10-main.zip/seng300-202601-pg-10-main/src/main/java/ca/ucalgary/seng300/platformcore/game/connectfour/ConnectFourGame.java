package ca.ucalgary.seng300.platformcore.game.connectfour;

import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.platformcore.game.*;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.gamevalidation.results.MoveValidationResult;

public class ConnectFourGame extends GameAbstract<ConnectFourPiece> {
    private static final int DEFAULT_ROWS = 6;
    private static final int DEFAULT_COLS = 7;
    private static final int QUIT_COLUMN = -1;

    public ConnectFourGame(int rowSize, int colSize, Player p1, Player p2) {
        super(
            GameType.CONNECTFOUR,
            rowSize < 1 ? DEFAULT_ROWS : rowSize,
            colSize < 1 ? DEFAULT_COLS : colSize,
            p1, p2
        );
        playerPieceMapping.put(p1.getID(), ConnectFourPiece.RED);
        playerPieceMapping.put(p2.getID(), ConnectFourPiece.YELLOW);
        clear();
        gameState = createGameState();
    }

    @Override
    public ConnectFourResult makeMove(GameMove move, Player player) {
        if (player == null || !player.equals(currentPlayer)) {
            return ConnectFourResult.error(QUIT_COLUMN, "It's not your turn!");
        }

        if (move == null || move.getPos() == null) {
            return ConnectFourResult.error(QUIT_COLUMN, "Missing move data");
        }

        int col = move.getPos().column;
        if (col == QUIT_COLUMN) {
            return quit();
        }

        Player movingPlayer = currentPlayer;
        if (handleMove(move)) {
            if (status == GameStatus.DRAW) {
                return ConnectFourResult.draw(col);
            }
            if (hasWin() != null) {
                return finish(col, movingPlayer);
            }
            return ConnectFourResult.ongoing(col);
        }
        return ConnectFourResult.error(col, lastMoveError);
    }

    private boolean handleMove(GameMove move) {
        int col = move.getPos().column;
        int row = findDropRow(col);
        int validationRow = row >= 0 ? row : 0;

        move.setRow(validationRow);
        move.setServerAssignedPiece(currentPlayerPiece());

        MoveValidationResult result = validator.validateMove(
            getGameType(), gameState, currentPlayer.getID(), move
        );

        if (!result.isValid() || row < 0) {
            lastMoveError = result.isValid() ? "This column is full" : result.getMessage();
            return false;
        }

        board.updateCell(row, col, currentPlayerPiece());
        updateState();
        return true;
    }

    public ConnectFourResult quit() {
        return (ConnectFourResult) resign(currentPlayer);
    }

    @Override
    protected MoveResult resignSuccess(UserID winner, UserID loser) {
        return ConnectFourResult.gameOver(QUIT_COLUMN, winner, loser);
    }

    @Override
    protected MoveResult resignFailure(String msg) {
        return ConnectFourResult.error(QUIT_COLUMN, msg);
    }

    @Override
    protected MoveResult drawAgreedSuccess() {
        return ConnectFourResult.draw(QUIT_COLUMN);
    }

    @Override
    protected MoveResult drawFailure(String msg) {
        return ConnectFourResult.error(QUIT_COLUMN, msg);
    }

    private ConnectFourResult finish(int col, Player winner) {
        Player loser = (winner == players[0]) ? players[1] : players[0];
        return ConnectFourResult.gameOver(col, winner.getID(), loser.getID());
    }

    private int findDropRow(int col) {
        if (col < 0 || col >= getColSize()) return -1;
        for (int row = getRowSize() - 1; row >= 0; row--) {
            if (board.getCellPiece(row, col) == null) return row;
        }
        return -1;
    }
}
