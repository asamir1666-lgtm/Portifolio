package ca.ucalgary.seng300.platformcore;

// reperests a single match between players.
// records game type, participating players, start/emnd time, and final results. ELO recalculation is handled externally by
// ELOCalculator before match.end() is called. this class only records outcomes and delegates stat updates to each player.

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class Match 
{
    private final String matchID = UUID.randomUUID().toString();
    private final GameType gameType;
    private final List<Player> players;
    private volatile Instant startTime;
    private volatile Instant endTime;
    private volatile Map<Player, MatchResult> results;

    public Match(GameType gameType, List<Player> players) {
        this.gameType = gameType;
        this.players = players;
        this.startTime = Instant.now();
    }
    
    public String getMatchID()
    {
        return matchID;
    }
    
    public GameType getGameType()
    {
        return gameType;
    }
    public List<Player> getPlayers() 
    {
        return players;
    }

    public Instant getStartTime()
    {
        return startTime;
    }

    public Instant getEndTime()
    {
        return endTime;
    }

    public Map<Player, MatchResult> getResults()
    {
        return results == null ? Map.of() : results;
    }

    /**
     * Ends the match and records each player's result and updated ELO.
     *
     * @param results    Map of each player to their outcome (WIN/LOSS/DRAW)
     * @param updatedElos Map of each player to their new ELO rating after the match
     */
    public synchronized void end(Map<Player, MatchResult> results, Map<Player, Integer> updatedElos) 
    {
        // Prevent match from ending more than once
        if (this.endTime != null) return;

        if (!players.containsAll(results.keySet())) 
        {
            throw new IllegalArgumentException("Results contain players not in this match");
        }

        this.endTime = Instant.now();
        this.results = Map.copyOf(results);

        for (Map.Entry<Player, MatchResult> entry : this.results.entrySet()) 
        {
            Player player = entry.getKey();
            MatchResult result = entry.getValue();
            int newElo = updatedElos.getOrDefault(player, player.getGameStats(gameType).getEloRating());
            player.recordResult(gameType, result, newElo);
        }
    }

}
