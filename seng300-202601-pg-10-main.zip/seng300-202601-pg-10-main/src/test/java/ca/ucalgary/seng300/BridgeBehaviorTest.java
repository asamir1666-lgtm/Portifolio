package ca.ucalgary.seng300;

import javafx.application.Platform;
import javafx.scene.web.WebEngine;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;

import static org.mockito.ArgumentMatchers.startsWith;
import static org.mockito.Mockito.*;

class BridgeBehaviorTest {

    private WebEngine engine;
    private Bridge bridge;

    @BeforeAll
    static void initJfx() throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        try {
            Platform.startup(latch::countDown);
        } catch (IllegalStateException e) {
            latch.countDown(); // already initialized
        }
        latch.await();
    }

    @BeforeEach
    void setUp() throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        Platform.runLater(() -> {
            engine = mock(WebEngine.class);
            bridge = new Bridge(engine);
            latch.countDown();
        });
        latch.await();
    }


    @Test
    void sendUsernames_shouldCallStartGameScript() {
        bridge.sendUsernames("playerOne", "playerTwo");
        verify(engine).executeScript("startGame('playerOne', 'playerTwo')");
    }

    // @Test
    // void validateMove_shouldConvertRowAndColumnToBoardIndex() {
    //     bridge.validateMove("ticTacToe", "state", 1, 2, "p1,p2", "p1");
    //     verify(engine).executeScript("applyMove(5)");
    // }

    // @Test
    // void validateMove_topLeft_shouldMapToZero() {
    //     bridge.validateMove("ticTacToe", "state", 0, 0, "p1,p2", "p1");
    //     verify(engine).executeScript("applyMove(0)");
    // }

    // @Test
    // void validateMove_bottomRight_shouldMapToEight() {
    //     bridge.validateMove("ticTacToe", "state", 2, 2, "p1,p2", "p1");
    //     verify(engine).executeScript("applyMove(8)");
    // }

    @Test
    void sendLeaderboardData_shouldCallRenderLeaderboardScript() {
        bridge.sendLeaderboardData();
        verify(engine).executeScript(startsWith("if(typeof renderLeaderboard==='function')renderLeaderboard(["));
    }

    @Test
    void sendUserStats_shouldCallSetUserStatsScript() {
        bridge.sendUserStats();
        verify(engine).executeScript(startsWith("if(typeof setUserStats==='function')setUserStats({"));
    }

    @Test
    void sendSeasonProgress_shouldCallSetSeasonProgressScript() {
        bridge.sendSeasonProgress();
        verify(engine).executeScript(startsWith("if(typeof setSeasonProgress==='function')setSeasonProgress({"));
    }
}