package ca.ucalgary.seng300.validation.gamevalidation;

import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.platformcore.game.Piece;
import ca.ucalgary.seng300.platformcore.game.GameMove;
import ca.ucalgary.seng300.platformcore.game.GameState;
import ca.ucalgary.seng300.platformcore.game.GridSpace;
import ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToePiece;
import ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourPiece;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.gamevalidation.enums.ValidationErrorCode;
import ca.ucalgary.seng300.validation.gamevalidation.results.MoveValidationResult;
import ca.ucalgary.seng300.validation.gamevalidation.results.WinValidationResult;
import org.junit.jupiter.api.Test;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

public class GameValidationTestNew {
    private final GameValidation validator = new GameValidation();

    // Setting up UserIDs for players 1 and 2
    private static final UserID Player1 = new UserID("P1");
    private static final UserID Player2 = new UserID("P2");

    // Setting up empty tic-tac-toe board
    private Piece[][] emptyTicTacToe() {
        Piece[][] board = new Piece[3][3];
        return board;
    }

    // Setting up empty connect 4 board
    private Piece[][] emptyConnectFour() {
        Piece[][] board = new Piece[6][7];
        return board;
    }

    // Initialized Player -> Piece for tic-tac-toe tests
    private HashMap<UserID, Piece> ticTacToePlayers() {
        HashMap<UserID, Piece> ticTacToePlayers = new HashMap<>();
        ticTacToePlayers.put(Player1, TicTacToePiece.X);
        ticTacToePlayers.put(Player2, TicTacToePiece.O);
        return ticTacToePlayers;
    }

    // Initialized player -> Piece for connect 4 tests
    private HashMap<UserID, Piece> connectFourPlayers() {
        HashMap<UserID, Piece> connectFourPlayers = new HashMap<>();
        connectFourPlayers.put(Player1, ConnectFourPiece.RED);
        connectFourPlayers.put(Player2, ConnectFourPiece.YELLOW);
        return connectFourPlayers;
    }

    // Setting up gamestate for use in each test
    private GameState newGameState(GameType gameType, HashMap<UserID, Piece> players, Piece[][] board) {
        return new GameState(gameType, new UserID[]{Player1, Player2}, players, board);
    }

    /**
     * NULL GAMESTATE, MOVE, AND BOARD + OTHER CHECKS FOR BOTH GAMES
     */
    // CHECK NULL GAME STATE FOR TIC TAC TOE
    @Test
    void checkNullState_gameState_ticTacToe() {
        Piece[][] board = emptyTicTacToe();
        GameMove testMove = new GameMove(new GridSpace(1, 1), TicTacToePiece.X);

        MoveValidationResult result = validator.validateMove(GameType.TICTACTOE, null, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }

    // CHECK NULL PLAYER MOVE FOR TIC TAC TOE
    @Test
    void checkNullState_move_ticTacToe() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);

        MoveValidationResult result = validator.validateMove(GameType.TICTACTOE, testState, Player1, null);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }

    // CHECK NULL GAME BOARD FOR TIC TAC TOE
    @Test
    void checkNullState_board_ticTacToe() {
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), null);
        GameMove testMove = new GameMove(new GridSpace(1, 1), TicTacToePiece.X);


        MoveValidationResult result = validator.validateMove(GameType.TICTACTOE, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }

    // CHECK NULL PLAYER ID FOR TIC TAC TOE
    @Test
    void checkNullState_playerIDToPiece_ticTacToe() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, null, emptyTicTacToe());
        GameMove testMove = new GameMove(new GridSpace(1, 1), TicTacToePiece.X);

        MoveValidationResult result = validator.validateMove(GameType.TICTACTOE, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }

    // CHECK NULL GAME STATE FOR CONNECT 4
    @Test
    void checkNullState_gameState_connect4() {
        GameMove testMove = new GameMove(new GridSpace(5, 1), ConnectFourPiece.RED);

        MoveValidationResult result = validator.validateMove(GameType.CONNECTFOUR, null, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }

    // CHECK NULL PLAYER MOVE FOR CONNECT 4
    @Test
    void checkNullState_move_connect4() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);

        MoveValidationResult result = validator.validateMove(GameType.CONNECTFOUR, testState, Player1, null);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }

    // CHECK NULL GAME BOARD FOR CONNECT 4
    @Test
    void checkNullState_board_connect4() {
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), null);
        GameMove testMove = new GameMove(new GridSpace(5, 1), ConnectFourPiece.RED);

        MoveValidationResult result = validator.validateMove(GameType.CONNECTFOUR, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }

    // CHECK NULL PLAYER ID FOR CONNECT 4
    @Test
    void checkNullState_playerIDToPiece_connect4() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, null, board);
        GameMove testMove = new GameMove(new GridSpace(5, 1), ConnectFourPiece.RED);

        MoveValidationResult result = validator.validateMove(GameType.CONNECTFOUR, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }



    /**
     * MOVE VALIDATION TESTS FOR TIC-TAC-TOE GAMES
     * Tests that check for: valid moves, invalid moves: out of bounds, cell occupied
     */

    // Test for a(ny) valid tic-tac-toe move (in board bounds, open cell, etc.), SHOULD RETURN TRUE.
    @Test
    void validateMove_validMove_ticTacToe() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        GameMove testMove = new GameMove(new GridSpace(1, 1), TicTacToePiece.X);

        MoveValidationResult result = validator.validateMove(GameType.TICTACTOE, testState, Player1, testMove);

        assertTrue(result.isValid());
        assertNull(result.getErrorCode());
        assertEquals("Move Accepted", result.getMessage());
    }

    // Test to see if a move is out of bounds (larger index) in tic-tac-toe
    @Test
    void validateMove_invalidMove_outOfBounds_largeIndex_ticTacToe() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        GameMove testMove = new GameMove(new GridSpace(4, 4), TicTacToePiece.X);

        MoveValidationResult result = validator.validateMove(GameType.TICTACTOE, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.OUT_OF_BOUNDS, result.getErrorCode());
        assertEquals("This move is out of bounds", result.getMessage());
    }

    // Test to see if a move is out of bounds (negative index) in tic-tac-toe
    @Test
    void validateMove_invalidMove_outOfBounds_negativeIndex_ticTacToe() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        GameMove testMove = new GameMove(new GridSpace(-2, -2), TicTacToePiece.X);

        MoveValidationResult result = validator.validateMove(GameType.TICTACTOE, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.OUT_OF_BOUNDS, result.getErrorCode());
        assertEquals("This move is out of bounds", result.getMessage());
    }

    // Test to see if a cell is occupied by any piece in tic-tac-toe
    @Test
    void validateMove_invalidMove_cellOccupied_ticTacToe() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        board[1][1] = TicTacToePiece.O;
        GameMove testMove = new GameMove(new GridSpace(1, 1), TicTacToePiece.X);

        MoveValidationResult result = validator.validateMove(GameType.TICTACTOE, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.CELL_OCCUPIED, result.getErrorCode());
        assertEquals("This cell is already taken", result.getMessage());
    }

    /**
     * MOVE VALIDATION TESTS FOR CONNECT-4 GAMES
     * Tests that check for: valid moves, invalid moves: out of bounds, cell occupied, gravity
     */


// Test that checks for a valid move at the bottom of the board in connect 4
    @Test
    void validateMove_validMove_bottomOfBoard_connect4() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        GameMove testMove = new GameMove(new GridSpace(5, 1), ConnectFourPiece.RED);

        MoveValidationResult result = validator.validateMove(GameType.CONNECTFOUR, testState, Player1, testMove);

        assertTrue(result.isValid());
        assertNull(result.getErrorCode());
        assertEquals("Move Accepted", result.getMessage());
    }

    // Test that checks for a valid move on top of a piece in connect 4
    @Test
    void validateMove_validMove_topOfPiece_connect4() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        board[5][1] = ConnectFourPiece.YELLOW;
        GameMove testMove = new GameMove(new GridSpace(4, 1), ConnectFourPiece.RED);

        MoveValidationResult result = validator.validateMove(GameType.CONNECTFOUR, testState, Player1, testMove);

        assertTrue(result.isValid());
        assertNull(result.getErrorCode());
        assertEquals("Move Accepted", result.getMessage());
    }

    // Two tests that check for out-of-bounds moves for both large and negative indexes in connect 4
    @Test
    void validateMove_invalidMove_outOfBounds_largeIndex_connect4() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        GameMove testMove = new GameMove(new GridSpace(10, 10), ConnectFourPiece.RED);

        MoveValidationResult result = validator.validateMove(GameType.CONNECTFOUR, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.OUT_OF_BOUNDS, result.getErrorCode());
        assertEquals("This move is out of bounds", result.getMessage());
    }

    @Test
    void validateMove_invalidMove_outOfBounds_negativeIndex_connect4() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        GameMove testMove = new GameMove(new GridSpace(-1, -1), ConnectFourPiece.RED);

        MoveValidationResult result = validator.validateMove(GameType.CONNECTFOUR, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.OUT_OF_BOUNDS, result.getErrorCode());
        assertEquals("This move is out of bounds", result.getMessage());
    }

    // Test that checks for an invalid move regarding an occupied cell in connect 4
    @Test
    void validateMove_invalidMove_cellOccupied_connect4() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        board[5][1] = ConnectFourPiece.YELLOW;
        GameMove testMove = new GameMove(new GridSpace(5, 1), ConnectFourPiece.RED);

        MoveValidationResult result = validator.validateMove(GameType.CONNECTFOUR, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.CELL_OCCUPIED, result.getErrorCode());
        assertEquals("This cell is already taken", result.getMessage());
    }

    // Test that checks for gravity violation (e.g. floating piece) in connect 4
    @Test
    void validateMove_invalidMove_gravityViolation_connect4() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        GameMove testMove = new GameMove(new GridSpace(1, 1), ConnectFourPiece.RED);

        MoveValidationResult result = validator.validateMove(GameType.CONNECTFOUR, testState, Player1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Connect 4 piece MUST fall to the bottom or rest on another piece", result.getMessage());
    }

    /**
     * WIN CHECKS AND CONDITIONS
     * Tests that check for: Either player winning in both games
     * 4 tests each for each game that look for vertical, horizontal, left/right diagonal wins
     */

// Test that checks for a straight, vertical win in column 1 for player 1 (X) in tic-tac-toe
    @Test
    void validateWin_ticTacToe_verticalX() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        board[0][0] = TicTacToePiece.X;
        board[1][0] = TicTacToePiece.X;
        board[2][0] = TicTacToePiece.X;

        WinValidationResult result = validator.validateWin(testState, ticTacToePlayers());

        assertTrue(result.hasWinner());
        assertFalse(result.isTie());
        assertEquals(Player1, result.getWinnerID());
    }

    // Test that checks for a straight, vertical win in row 1 for player 1 (X) in tic-tac-toe
    @Test
    void validateWin_ticTacToe_horizontalX() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        board[0][0] = TicTacToePiece.X;
        board[0][1] = TicTacToePiece.X;
        board[0][2] = TicTacToePiece.X;

        WinValidationResult result = validator.validateWin(testState, ticTacToePlayers());

        assertTrue(result.hasWinner());
        assertFalse(result.isTie());
        assertEquals(Player1, result.getWinnerID());
    }

    // Test that checks for a right diagonal win for player 1 (X) in tic-tac-toe
    @Test
    void validateWin_ticTacToe_rightDiagonalX() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        board[0][2] = TicTacToePiece.X;
        board[1][1] = TicTacToePiece.X;
        board[2][0] = TicTacToePiece.X;

        WinValidationResult result = validator.validateWin(testState, ticTacToePlayers());

        assertTrue(result.hasWinner());
        assertFalse(result.isTie());
        assertEquals(Player1, result.getWinnerID());
    }

    // Test that checks for a left diagonal win for player 1 (X) in tic-tac-toe
    @Test
    void validateWin_ticTacToe_leftDiagonalX() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        board[0][0] = TicTacToePiece.X;
        board[1][1] = TicTacToePiece.X;
        board[2][2] = TicTacToePiece.X;

        WinValidationResult result = validator.validateWin(testState, ticTacToePlayers());

        assertTrue(result.hasWinner());
        assertFalse(result.isTie());
        assertEquals(Player1, result.getWinnerID());
    }

    // Test that checks for a straight vertical win in column 1 for player 1 (RED) in connect 4
    @Test
    void validateWin_connect4_verticalRed() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        board[5][0] = ConnectFourPiece.RED;
        board[4][0] = ConnectFourPiece.RED;
        board[3][0] = ConnectFourPiece.RED;
        board[2][0] = ConnectFourPiece.RED;

        WinValidationResult result = validator.validateWin(testState, connectFourPlayers());

        assertTrue(result.hasWinner());
        assertFalse(result.isTie());
        assertEquals(Player1, result.getWinnerID());
    }

    // Test that checks for a straight horizontal win in row 6 for player 1 (RED) in connect 4
    @Test
    void validateWin_connect4_horizontalRed() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        board[5][0] = ConnectFourPiece.RED;
        board[5][1] = ConnectFourPiece.RED;
        board[5][2] = ConnectFourPiece.RED;
        board[5][3] = ConnectFourPiece.RED;

        WinValidationResult result = validator.validateWin(testState, connectFourPlayers());

        assertTrue(result.hasWinner());
        assertFalse(result.isTie());
        assertEquals(Player1, result.getWinnerID());
    }

    // Test that checks for a right diagonal win for player 1 (RED) in connect 4. Will defy gravity for the sake of testing
    @Test
    void validateWin_connect4_rightDiagonalRed() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        board[5][0] = ConnectFourPiece.RED;
        board[4][1] = ConnectFourPiece.RED;
        board[3][2] = ConnectFourPiece.RED;
        board[2][3] = ConnectFourPiece.RED;

        WinValidationResult result = validator.validateWin(testState, connectFourPlayers());

        assertTrue(result.hasWinner());
        assertFalse(result.isTie());
        assertEquals(Player1, result.getWinnerID());
    }

    // Test that checks for a left diagonal win for player 1 (RED) in connect 4. Will defy gravity for the sake of testing
    @Test
    void validateWin_connect4_leftDiagonalRed() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        board[2][0] = ConnectFourPiece.RED;
        board[3][1] = ConnectFourPiece.RED;
        board[4][2] = ConnectFourPiece.RED;
        board[5][3] = ConnectFourPiece.RED;

        WinValidationResult result = validator.validateWin(testState, connectFourPlayers());

        assertTrue(result.hasWinner());
        assertFalse(result.isTie());
        assertEquals(Player1, result.getWinnerID());
    }

    /**
     * DRAW CHECKS AND CONDITIONS
     * Tests that check for: A full board with no winners, resulting in a draw
     */

// Test that checks for a draw result in a full board with no winners in tic tac toe (9 total moves).
    @Test
    void validateDraw_ticTacToe_fullBoard1() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        // 5 total moves for player 1 (X)
        board[0][0] = TicTacToePiece.X;
        board[0][1] = TicTacToePiece.X;

        board[1][2] = TicTacToePiece.X;

        board[2][0] = TicTacToePiece.X;
        board[2][2] = TicTacToePiece.X;

        // 4 total moves for player 2 (O)
        board[0][2] = TicTacToePiece.O;

        board[1][0] = TicTacToePiece.O;
        board[1][1] = TicTacToePiece.O;

        board[2][1] = TicTacToePiece.O;

        WinValidationResult result = validator.validateWin(testState, ticTacToePlayers());

        assertFalse(result.hasWinner());
        assertTrue(result.isTie());
        assertNull(result.getWinnerID());
    }

    // Test that checks for a draw result in a full board with no winners in connect 4 (42 total moves).
    @Test
    void validateDraw_connect4_fullBoard1() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        // 21 total moves for RED
        board[0][1] = ConnectFourPiece.RED;
        board[0][2] = ConnectFourPiece.RED;
        board[0][4] = ConnectFourPiece.RED;
        board[0][5] = ConnectFourPiece.RED;

        board[1][0] = ConnectFourPiece.RED;
        board[1][3] = ConnectFourPiece.RED;

        board[2][0] = ConnectFourPiece.RED;
        board[2][2] = ConnectFourPiece.RED;
        board[2][3] = ConnectFourPiece.RED;
        board[2][4] = ConnectFourPiece.RED;
        board[2][6] = ConnectFourPiece.RED;

        board[3][0] = ConnectFourPiece.RED;
        board[3][2] = ConnectFourPiece.RED;
        board[3][3] = ConnectFourPiece.RED;
        board[3][4] = ConnectFourPiece.RED;
        board[3][6] = ConnectFourPiece.RED;

        board[4][1] = ConnectFourPiece.RED;
        board[4][2] = ConnectFourPiece.RED;
        board[4][4] = ConnectFourPiece.RED;
        board[4][5] = ConnectFourPiece.RED;

        board[5][3] = ConnectFourPiece.RED;

        // 21 total moves for YELLOW
        board[0][0] = ConnectFourPiece.YELLOW;
        board[0][3] = ConnectFourPiece.YELLOW;
        board[0][6] = ConnectFourPiece.YELLOW;

        board[1][1] = ConnectFourPiece.YELLOW;
        board[1][2] = ConnectFourPiece.YELLOW;
        board[1][4] = ConnectFourPiece.YELLOW;
        board[1][5] = ConnectFourPiece.YELLOW;
        board[1][6] = ConnectFourPiece.YELLOW;

        board[2][1] = ConnectFourPiece.YELLOW;
        board[2][5] = ConnectFourPiece.YELLOW;

        board[3][1] = ConnectFourPiece.YELLOW;
        board[3][5] = ConnectFourPiece.YELLOW;

        board[4][0] = ConnectFourPiece.YELLOW;
        board[4][3] = ConnectFourPiece.YELLOW;
        board[4][6] = ConnectFourPiece.YELLOW;

        board[5][0] = ConnectFourPiece.YELLOW;
        board[5][1] = ConnectFourPiece.YELLOW;
        board[5][2] = ConnectFourPiece.YELLOW;
        board[5][4] = ConnectFourPiece.YELLOW;
        board[5][5] = ConnectFourPiece.YELLOW;
        board[5][6] = ConnectFourPiece.YELLOW;

        WinValidationResult result = validator.validateWin(testState, connectFourPlayers());

        assertFalse(result.hasWinner());
        assertTrue(result.isTie());
        assertNull(result.getWinnerID());
    }

    /**
     * INCOMPLETE WIN CHECKS AND CONDITIONS
     * Tests that check for: Either a game in progress/no winner yet
     */

    // Empty board test. Should have no winner in tic-tac-toe
    @Test
    void emptyBoard_ticTacToe() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);

        WinValidationResult result = validator.validateWin(testState, ticTacToePlayers());

        assertFalse(result.hasWinner());
        assertFalse(result.isTie());
        assertNull(result.getWinnerID());
    }

    // Test that checks for an incomplete win in tic-tac-toe
    @Test
    void partialGame_ticTacToe1() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        board[0][2] = TicTacToePiece.X;
        board[1][1] = TicTacToePiece.X;
        board[2][1] = TicTacToePiece.X;

        WinValidationResult result = validator.validateWin(testState, ticTacToePlayers());

        assertFalse(result.hasWinner());
        assertFalse(result.isTie());
        assertNull(result.getWinnerID());
    }

    // Test that checks for an incomplete win in tic-tac-toe
    @Test
    void partialGame_ticTacToe2() {
        Piece[][] board = emptyTicTacToe();
        GameState testState = newGameState(GameType.TICTACTOE, ticTacToePlayers(), board);
        board[0][2] = TicTacToePiece.X;
        board[2][1] = TicTacToePiece.X;

        WinValidationResult result = validator.validateWin(testState, ticTacToePlayers());

        assertFalse(result.hasWinner());
        assertFalse(result.isTie());
        assertNull(result.getWinnerID());
    }

    // Test that checks for an incomplete win for connect 4
    @Test
    void emptyBoard_connectFour() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);

        WinValidationResult result = validator.validateWin(testState, connectFourPlayers());

        assertFalse(result.hasWinner());
        assertFalse(result.isTie());
        assertNull(result.getWinnerID());
    }

    // Test that checks for an incomplete win in connect 4
    @Test
    void partialGame_connectFour1() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        board[2][0] = ConnectFourPiece.RED;
        board[3][1] = ConnectFourPiece.RED;
        board[4][2] = ConnectFourPiece.RED;
        board[5][5] = ConnectFourPiece.RED;

        WinValidationResult result = validator.validateWin(testState, connectFourPlayers());

        assertFalse(result.hasWinner());
        assertFalse(result.isTie());
        assertNull(result.getWinnerID());
    }

    // Test that checks for an incomplete win in connect 4
    @Test
    void partialGame_connectFour2() {
        Piece[][] board = emptyConnectFour();
        GameState testState = newGameState(GameType.CONNECTFOUR, connectFourPlayers(), board);
        board[2][0] = ConnectFourPiece.RED;
        board[3][1] = ConnectFourPiece.RED;
        board[4][2] = ConnectFourPiece.RED;

        WinValidationResult result = validator.validateWin(testState, connectFourPlayers());

        assertFalse(result.hasWinner());
        assertFalse(result.isTie());
        assertNull(result.getWinnerID());
    }



}
