package ca.ucalgary.seng300.database;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.io.File;

import ca.ucalgary.seng300.Config;
import ca.ucalgary.seng300.platformcore.GameType;
import ca.ucalgary.seng300.database.Database;
import ca.ucalgary.seng300.platformcore.Leaderboard;
import ca.ucalgary.seng300.platformcore.LeaderboardExport;
import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.platformcore.PlayerStats;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.platformcore.GameStats;

public class LeaderboardDatabaseTest {
    private static LeaderboardDatabase leaderboardDatabase;
    private static final GameType TEST_GAME_TYPE = GameType.CONNECTFOUR;
    private static String originalDbFolder;

    @BeforeAll
    public static void setUp() {
        originalDbFolder = Config.DATABASE_FOLDER;
        Config.DATABASE_FOLDER = "database_files_test";
        Database.resetInstances();
        leaderboardDatabase = Database.getInstance(LeaderboardDatabase.class);
        leaderboardDatabase.connect();
    }
    @AfterAll
    public static void tearDown() {
        File folder = new File(Config.DATABASE_FOLDER);
        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File file : files) {
                    file.delete();
                }
            }
        }
        folder.delete();
        Config.DATABASE_FOLDER = originalDbFolder;
        Database.resetInstances();
    }

    public static ArrayList<Player> createSamplePlayerStats() {
        ArrayList<Player> playerStatsList = new ArrayList<>();
        Player player1 = new Player(new UserID("player1"), "player1");
        Player player2 = new Player(new UserID("player2"), "player2");
        Player player3 = new Player(new UserID("player3"), "player3");
        
        PlayerStats stats1 = new PlayerStats();
        stats1.setGameStats(TEST_GAME_TYPE, new GameStats(1500));
        player1.setStats(stats1);

        PlayerStats stats2 = new PlayerStats();
        stats2.setGameStats(TEST_GAME_TYPE, new GameStats(1600));
        player2.setStats(stats2);
        
        PlayerStats stats3 = new PlayerStats();
        stats3.setGameStats(TEST_GAME_TYPE, new GameStats(1400));
        player3.setStats(stats3);
        
        playerStatsList.add(player1);
        playerStatsList.add(player2);
        playerStatsList.add(player3);
        return playerStatsList;
    }

    @Test
    void testUpdateLeaderboard() {
        ArrayList<Player> playerStatsList = createSamplePlayerStats();
        Leaderboard leaderboard = leaderboardDatabase.getData();
        for (Player player : playerStatsList) {
            leaderboard.updateGameStats(player.getID(), player.getStats());
        }
        leaderboardDatabase.save();
        
        Leaderboard updatedLeaderboard = leaderboardDatabase.getData();
        UserID playerId1 = new UserID("player1");
        UserID playerId2 = new UserID("player2");
        UserID playerId3 = new UserID("player3");
        int actualEloPlayer1 = updatedLeaderboard.getPlayerStatsMap().get(playerId1).getStatsForGame(TEST_GAME_TYPE).getEloRating();
        int actualEloPlayer2 = updatedLeaderboard.getPlayerStatsMap().get(playerId2).getStatsForGame(TEST_GAME_TYPE).getEloRating();
        int actualEloPlayer3 = updatedLeaderboard.getPlayerStatsMap().get(playerId3).getStatsForGame(TEST_GAME_TYPE).getEloRating();

        assertEquals(3, updatedLeaderboard.getPlayerStatsMap().size());
        assertEquals(1500, actualEloPlayer1);
        assertEquals(1600, actualEloPlayer2);
        assertEquals(1400, actualEloPlayer3);
    }

    @Test
    void testTopKPlayers() {
        ArrayList<Player> playerStatsList = createSamplePlayerStats();
        Leaderboard leaderboard = leaderboardDatabase.getData();
        for (Player player : playerStatsList) {
            leaderboard.updateGameStats(player.getID(), player.getStats());
        }

        ArrayList<LeaderboardExport> top2Players = leaderboard.getTopPlayers(2, TEST_GAME_TYPE);

        String actualTopPlayer1 = top2Players.get(0).getPlayerId().id();
        String actualTopPlayer2 = top2Players.get(1).getPlayerId().id();

        assertEquals(2, top2Players.size());
        assertEquals("player2", actualTopPlayer1);
        assertEquals("player1", actualTopPlayer2);
    }

}

