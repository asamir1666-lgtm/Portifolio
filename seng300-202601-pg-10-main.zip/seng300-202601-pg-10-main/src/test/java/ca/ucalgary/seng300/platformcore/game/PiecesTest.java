package ca.ucalgary.seng300.platformcore.game;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToePiece;
import ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourPiece;
import ca.ucalgary.seng300.platformcore.game.Piece;

public class PiecesTest {
    @Test
    void test1() {
        Piece piece = TicTacToePiece.O;
        assertNotNull(piece);
    }
}
