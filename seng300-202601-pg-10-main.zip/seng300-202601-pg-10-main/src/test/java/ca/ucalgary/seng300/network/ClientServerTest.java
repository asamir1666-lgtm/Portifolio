package ca.ucalgary.seng300.network;

import java.io.File;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.*;

import ca.ucalgary.seng300.Config;
import ca.ucalgary.seng300.database.Database;
import ca.ucalgary.seng300.network.handler.client.AuthHandler;
import ca.ucalgary.seng300.network.handler.client.GameHandler;
import ca.ucalgary.seng300.network.handler.client.LobbyHandler;
import ca.ucalgary.seng300.network.message.Payload;
import ca.ucalgary.seng300.platformcore.GameType;

public class ClientServerTest {
    private static Client client;
    private static Client anotherClient;
    private static Server server;
    private static final CompletableFuture<Void> serverReady = new CompletableFuture<>();
    private static final CompletableFuture<Void> client1Ready = new CompletableFuture<>();
    private static final CompletableFuture<Void> client2Ready = new CompletableFuture<>();
    private static final int TIMEOUT_SECONDS = 2;
    private static String originalDbFolder;

    @BeforeAll
    static void setUp() throws Exception {
        originalDbFolder = Config.DATABASE_FOLDER;
        Config.DATABASE_FOLDER = "database_files_test";
        Database.resetInstances();
        server = new Server();
        Thread serverThread = new Thread(() -> { 
            try {
                server.start(() -> serverReady.complete(null));
            } catch (Exception e) {
                serverReady.completeExceptionally(e);
            }
        });
        serverThread.setDaemon(true);
        serverThread.start();

        serverReady.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);

        client = new Client("localhost");
        client.connect(true);
        AuthHandler auth1 = client.router.getHandler(AuthHandler.class);
        auth1.setOnError(e -> client1Ready.completeExceptionally(new RuntimeException(e.message())));
        auth1.setOnLogin(r -> client1Ready.complete(null));
        auth1.setOnSignup(r -> client.send(new Payload.Auth.Req.Login("testuser", "password123")));
        client.send(new Payload.Auth.Req.Signup("testuser", "password123"));

        anotherClient = new Client("localhost");
        anotherClient.connect(true);
        AuthHandler auth2 = anotherClient.router.getHandler(AuthHandler.class);
        auth2.setOnError(e -> client2Ready.completeExceptionally(new RuntimeException(e.message())));
        auth2.setOnLogin(r -> client2Ready.complete(null));
        auth2.setOnSignup(r -> anotherClient.send(new Payload.Auth.Req.Login("testuser2", "password123")));
        anotherClient.send(new Payload.Auth.Req.Signup("testuser2", "password123"));

        // Wait for BOTH clients to be logged in
        CompletableFuture.allOf(client1Ready, client2Ready).get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
    }

    @AfterAll
    static void tearDown() {
        File folder = new File(Config.DATABASE_FOLDER);
        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File file : files) {
                    file.delete();
                }
            }
        }
        folder.delete();
        Config.DATABASE_FOLDER = originalDbFolder;
        Database.resetInstances();
    }

    @Test
    void testFullLobbyFlow() throws Exception {
        LobbyHandler lobby1 = client.router.getHandler(LobbyHandler.class);
        LobbyHandler lobby2 = anotherClient.router.getHandler(LobbyHandler.class);

        // Step 1: client1 creates a lobby
        CompletableFuture<Void> lobbyCreated = new CompletableFuture<>();
        CompletableFuture<Payload.Lobby.Res.Create> response = new CompletableFuture<>();
        lobby1.setOnError(e -> lobbyCreated.completeExceptionally(new RuntimeException(e.message())));
        lobby1.setOnCreate(r -> {
            response.complete(r);
            lobbyCreated.complete(null);
        });
        lobby1.setOnJoin(r -> {
            // A client joined
            // Thats a good sign, just make sure its not null
        });
        client.send(new Payload.Lobby.Req.Create(GameType.CONNECTFOUR, true));
        lobbyCreated.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);

        // Step 2: client2 joins
        CompletableFuture<Void> lobbyJoined = new CompletableFuture<>();
        lobby2.setOnError(e -> lobbyJoined.completeExceptionally(new RuntimeException(e.message())));
        lobby2.setOnJoin(r -> lobbyJoined.complete(null));
        Payload.Lobby.Res.Create createRes = response.get();
        anotherClient.send(new Payload.Lobby.Req.Join(
            createRes.lobby().getID(),
            createRes.lobby().getJoinCode()
        ));
        lobbyJoined.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);

        // Step 3: client1 sends a chat via Game handler, client2 receives it
        final String chatMessage = "Hello, Server!";
        CompletableFuture<String> chatReceived = new CompletableFuture<>();
        CompletableFuture<Void> chatAcked = new CompletableFuture<>();

        GameHandler game2 = anotherClient.router.getHandler(GameHandler.class);
        GameHandler game1 = client.router.getHandler(GameHandler.class);

        game2.setOnChat(r -> chatReceived.complete(r.message()));
        game1.setOnChat(r -> chatAcked.complete(null));

        client.send(new Payload.Game.Req.Chat(chatMessage));

        String received = chatReceived.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
        chatAcked.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
        Assertions.assertEquals(chatMessage, received, "ChatSync message mismatch");
    }
}
