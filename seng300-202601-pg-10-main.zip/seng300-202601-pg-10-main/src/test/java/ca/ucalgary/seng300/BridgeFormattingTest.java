package ca.ucalgary.seng300;

import ca.ucalgary.seng300.leaderboard.LeaderboardEntry;
import ca.ucalgary.seng300.leaderboard.SeasonProgress;
import ca.ucalgary.seng300.leaderboard.UserStats;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


class BridgeFormattingTest {

    private Bridge bridge;

    @BeforeEach
    void setUp() {
        bridge = new Bridge(null);
    }

    @Test
    void escapeJs_shouldEscapeQuotesAndBackslashes() throws Exception {
        Method method = Bridge.class.getDeclaredMethod("escapeJs", String.class);
        method.setAccessible(true);

        String result = (String) method.invoke(bridge, "Ali\\\"Test");

        assertEquals("Ali\\\\\\\"Test", result);
    }

    @Test
    void convertUserStatsToJsObject_shouldIncludeAllFields() throws Exception {
        Method method = Bridge.class.getDeclaredMethod("convertUserStatsToJsObject", UserStats.class);
        method.setAccessible(true);

        UserStats stats = new UserStats("#12", 2100, 50, 10, "83.3%", 60);

        String result = (String) method.invoke(bridge, stats);

        assertTrue(result.contains("currentRank:\"#12\""));
        assertTrue(result.contains("eloRating:2100"));
        assertTrue(result.contains("wins:50"));
        assertTrue(result.contains("losses:10"));
        assertTrue(result.contains("winRate:\"83.3%\""));
        assertTrue(result.contains("totalGamesPlayed:60"));
    }

    @Test
    void convertSeasonProgressToJsObject_shouldIncludeAllFields() throws Exception {
        Method method = Bridge.class.getDeclaredMethod("convertSeasonProgressToJsObject", SeasonProgress.class);
        method.setAccessible(true);

        SeasonProgress progress = new SeasonProgress("#11", 25, "7 days");

        String result = (String) method.invoke(bridge, progress);

        assertTrue(result.contains("nextRank:\"#11\""));
        assertTrue(result.contains("eloNeeded:25"));
        assertTrue(result.contains("seasonEndsIn:\"7 days\""));
    }

    @Test
    void convertEntriesToJsArray_shouldBuildExpectedArray() throws Exception {
        Method method = Bridge.class.getDeclaredMethod("convertEntriesToJsArray", List.class);
        method.setAccessible(true);

        List<LeaderboardEntry> entries = List.of(
                new LeaderboardEntry(1, "Ali", 2000, 10, 2, "83.3%"),
                new LeaderboardEntry(2, "Sam", 1900, 8, 4, "66.7%")
        );

        String result = (String) method.invoke(bridge, entries);

        assertTrue(result.startsWith("["));
        assertTrue(result.endsWith("]"));
        assertTrue(result.contains("rank:1"));
        assertTrue(result.contains("player:\"Ali\""));
        assertTrue(result.contains("elo:2000"));
        assertTrue(result.contains("wins:10"));
        assertTrue(result.contains("losses:2"));
        assertTrue(result.contains("winRate:\"83.3%\""));

        assertTrue(result.contains("rank:2"));
        assertTrue(result.contains("player:\"Sam\""));
    }

    @Test
    void convertEntriesToJsArray_shouldEscapeSpecialCharactersInPlayerName() throws Exception {
        Method method = Bridge.class.getDeclaredMethod("convertEntriesToJsArray", List.class);
        method.setAccessible(true);

        List<LeaderboardEntry> entries = List.of(
                new LeaderboardEntry(1, "Ali\"\\Test", 2000, 10, 2, "83.3%")
        );

        String result = (String) method.invoke(bridge, entries);

        assertTrue(result.contains("player:\"Ali\\\"\\\\Test\""));
    }
}