package ca.ucalgary.seng300.database;

import org.junit.jupiter.api.*;

import java.io.Serializable;
import java.io.File;

import ca.ucalgary.seng300.Config;

public class DatabaseTest {
    private static TestDatabase testDatabase;
    private static final String TEST_DB_NAME = "test_database";
    private static String originalDbFolder;

    static class TestData implements Serializable {
    private static final long serialVersionUID = 1L;
        private String value;

        public TestData(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public String setValue(String value) {
            this.value = value;
            return this.value;
        }
    }
    static class TestDatabase extends Database<TestData> {
        private TestDatabase() {
            super(TEST_DB_NAME);
        }

        public void saveData(String value) {
            this.getData().setValue(value);
            this.save();
        }

        public TestData getTestData() {
            return this.getData();
        }

        @Override
        protected TestData getDefaultData() {
            return new TestData("default");
        }
    }

    @BeforeAll
    public static void setUp() {
        originalDbFolder = Config.DATABASE_FOLDER;
        Config.DATABASE_FOLDER = "database_files_test";
        Database.resetInstances();
        testDatabase = Database.getInstance(TestDatabase.class);
        testDatabase.connect();
    }
    @BeforeEach
    public void resetDatabase() {
        testDatabase.saveData("default");
    }

    @AfterAll
    public static void tearDown() {
        File folder = new File(Config.DATABASE_FOLDER);
        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File file : files) {
                    file.delete();
                }
            }
        }
        folder.delete();
        Config.DATABASE_FOLDER = originalDbFolder;
        Database.resetInstances();
    }


    @Test
    public void testDefaultData() {
        TestData data = testDatabase.getTestData();
        Assertions.assertEquals("default", data.getValue());
    }

    @Test
    public void testSaveAndLoad() {
        testDatabase.saveData("test_value");
        TestData loadedData = testDatabase.getTestData();
        Assertions.assertEquals("test_value", loadedData.getValue());
    }

    @Test
    public void testExistingData() {
        testDatabase.saveData("existing_value");

        TestDatabase newInstance = Database.getInstance(TestDatabase.class);
        newInstance.connect();
        TestData loadedData = newInstance.getTestData();
        Assertions.assertEquals("existing_value", loadedData.getValue());
    }

    @Test
    public void testSingleton() {
        TestDatabase instance1 = Database.getInstance(TestDatabase.class);
        TestDatabase instance2 = Database.getInstance(TestDatabase.class);
        Assertions.assertSame(instance1, instance2);
    }

    @Test
    public void testFileCreation() {
        File file = new File(Config.DATABASE_FOLDER, "test_database");
        Assertions.assertTrue(file.exists());
    }
}

