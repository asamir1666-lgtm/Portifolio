package ca.ucalgary.seng300;

import ca.ucalgary.seng300.leaderboard.LeaderboardEntry;
import ca.ucalgary.seng300.leaderboard.LeaderboardStubData;
import ca.ucalgary.seng300.leaderboard.SeasonProgress;
import ca.ucalgary.seng300.leaderboard.UserStats;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LeaderboardStubDataTest {

    @Test
    void getLeaderboardEntries_shouldReturnTenEntries() {
        List<LeaderboardEntry> entries = LeaderboardStubData.getLeaderboardEntries();

        assertNotNull(entries);
        assertEquals(10, entries.size());
    }

    @Test
    void getLeaderboardEntries_firstEntryShouldMatchExpectedStubData() {
        List<LeaderboardEntry> entries = LeaderboardStubData.getLeaderboardEntries();
        LeaderboardEntry first = entries.get(0);

        assertEquals(1, first.getRank());
        assertEquals("ShadowMaster", first.getPlayer());
        assertEquals(2847, first.getElo());
        assertEquals(1543, first.getWins());
        assertEquals(287, first.getLosses());
        assertEquals("84.3%", first.getWinRate());
    }

    @Test
    void getLeaderboardEntries_shouldBeRankedInOrder() {
        List<LeaderboardEntry> entries = LeaderboardStubData.getLeaderboardEntries();

        for (int i = 0; i < entries.size(); i++) {
            assertEquals(i + 1, entries.get(i).getRank());
        }
    }

    @Test
    void getUserStats_shouldReturnExpectedValues() {
        UserStats stats = LeaderboardStubData.getUserStats();

        assertNotNull(stats);
        assertEquals("#847", stats.getCurrentRank());
        assertEquals(1876, stats.getEloRating());
        assertEquals(234, stats.getWins());
        assertEquals(189, stats.getLosses());
        assertEquals("55.3%", stats.getWinRate());
        assertEquals(423, stats.getTotalGamesPlayed());
    }

    @Test
    void getSeasonProgress_shouldReturnExpectedValues() {
        SeasonProgress progress = LeaderboardStubData.getSeasonProgress();

        assertNotNull(progress);
        assertEquals("#846", progress.getNextRank());
        assertEquals(12, progress.getEloNeeded());
        assertEquals("14 days", progress.getSeasonEndsIn());
    }
}