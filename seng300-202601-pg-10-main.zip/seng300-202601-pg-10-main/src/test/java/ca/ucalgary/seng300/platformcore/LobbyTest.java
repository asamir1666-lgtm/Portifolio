package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.database.LobbyDatabase;
import ca.ucalgary.seng300.validation.account.records.UserID;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class LobbyTest {
  LobbyRoom lobby;
  Player player;

  @BeforeEach
  void initializeLobbyAndPlayer() {
    lobby = new LobbyRoom(new LobbyID("0"), GameType.CONNECTFOUR, 2, "1234");
    player = new Player(new UserID("testPlayer"), "testPlayer");
  }

  @Test
  void whenJoiningOpenPublicLobbyReturnSuccess() {
    LobbyJoinResponse expected = new LobbyJoinResponse(true, "Successfully joined lobby LobbyID[id=0]", LobbyResponseType.SUCCESS);
    LobbyJoinResponse actual = lobby.admitPlayer(player, "");
    assertEquals(expected, actual);
  }
  @Test
  void whenJoiningOpenPublicLobbyWithPlayerReturnSuccess() {
    lobby.admitPlayer(new Player(new UserID("playerreturnsucecss"), "playerreturnsucecss"), "");
    assert lobby.getRemainingSpots() == 1;

    LobbyJoinResponse expected = new LobbyJoinResponse(true, "Successfully joined lobby LobbyID[id=0]", LobbyResponseType.SUCCESS);
    LobbyJoinResponse actual = lobby.admitPlayer(player, "");
    assertEquals(expected, actual);
  }
  @Test
  void whenJoiningFullLobbyReturnFailure() {
    lobby.setState(LobbyState.FULL);

    LobbyJoinResponse expected = new LobbyJoinResponse(false, "Lobby is full", LobbyResponseType.FAILURE);
    LobbyJoinResponse actual = lobby.admitPlayer(player, "");
    assertEquals(expected, actual);
  }
  @Test
  void whenJoiningInGameLobbyReturnFailure() {
    lobby.setState(LobbyState.IN_GAME);

    LobbyJoinResponse expected = new LobbyJoinResponse(false, "Game is in progress", LobbyResponseType.FAILURE);
    LobbyJoinResponse actual = lobby.admitPlayer(player, "");
    assertEquals(expected, actual);
  }
  @Test
  void whenJoiningGameOverLobbyReturnFailure() {
    lobby.setState(LobbyState.GAME_OVER);

    LobbyJoinResponse expected = new LobbyJoinResponse(false, "Game is in progress", LobbyResponseType.FAILURE);
    LobbyJoinResponse actual = lobby.admitPlayer(player, "");
    assertEquals(expected, actual);
  }
  @Test
  void whenJoiningPrivateLobbyNoCodeReturnPrivate() {
    lobby.setPublicity(false);

    LobbyJoinResponse expected = new LobbyJoinResponse(false, "Access code required", LobbyResponseType.PRIVATE);
    LobbyJoinResponse actual = lobby.admitPlayer(player, "");
    assertEquals(expected, actual);
  }
  @Test
  void whenJoiningPrivateLobbyWrongCodeReturnPrivate() {
    lobby.setPublicity(false);

    LobbyJoinResponse expected = new LobbyJoinResponse(false, "Incorrect access code", LobbyResponseType.PRIVATE);
    LobbyJoinResponse actual = lobby.admitPlayer(player, "a"); //join code cannot be 1 letter
    assertEquals(expected, actual);
  }
  @Test
  void whenJoiningPrivateLobbyCorrectCodeReturnSuccess() {
    lobby.setPublicity(false);

    LobbyJoinResponse expected = new LobbyJoinResponse(true, "Successfully joined lobby LobbyID[id=0]", LobbyResponseType.SUCCESS);
    LobbyJoinResponse actual = lobby.admitPlayer(player, lobby.getJoinCode());
    assertEquals(expected, actual);
  }
  @Test
  void whenPlayerJoinedLobbyStateIsINLOBBY() {
    LobbyJoinResponse expected = new LobbyJoinResponse(true, "Successfully joined lobby LobbyID[id=0]", LobbyResponseType.SUCCESS);
    LobbyJoinResponse actual = lobby.admitPlayer(player, "");
    assertEquals(expected, actual);
    assertEquals(player.getState(), PlayerState.IN_LOBBY);
  }
  @Test
  void whenPlayerRemovedLobbyIsEmpty() {
    lobby.admitPlayer(player, "");
    assertFalse(lobby.getPlayers().isEmpty());
    lobby.removePlayer(player);
    assertTrue(lobby.getPlayers().isEmpty());
  }
  @Test
  void whenPlayerRemovedStateIsDASHBOARD() {
    lobby.admitPlayer(player, "");
    assertFalse(lobby.getPlayers().isEmpty());
    lobby.removePlayer(player);
    assertTrue(lobby.getPlayers().isEmpty());
    assertEquals(player.getState(), PlayerState.DASHBOARD);
  }
}
