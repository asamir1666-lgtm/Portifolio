# User Acceptance Testing (UAT)

---

## Feature: User Authentication
*Verifying a user before they can enter the application*

### Scenario: Successful Login 
*(Parallel to Successful Create Account, which checks inputted credentials for format and places into the database)*
* **Given:** That the project is launched and the application first opens to the `login-signup.html` view.
* **When:** The user enters their username in the username field and password in the password field, clicking "Login".
* **Then:** The user is directed forwards to `dashboard.html` via communication to the java bridge that confirms the users credentials are within the database.

---

## 2. Feature: Lobby Management
*Verifying that user can see and host game matches*

### Scenario: Hosting a Private Connect 4 Match
* **Given:** The user is on the `lobbyCreateMatch.html` page.
* **When:** The user selects "Connect 4" and "Private", then clicking the "Host" button.
* **Then:** The user is directed to the `waitingRoom.html` via communication with the java bridge and subsequently supplying a match code.

---

## 3. Feature: Gameplay Interaction
*Verifying that user actions on the game board are logically correct*

### Scenario: Placing a Piece in Connect 4
* **Given:** A that there is an active Connect 4 game, and it is the user's turn.
* **When:** The user clicks on a given column of the game board.
* * **Then:** The user's move is validated by sending the move to the corresponding java bridge.
* **And:** If the move is valid, animate a piece falling into that column.
* **And:** Subsequents, switch the move to the opponent.

---

## 4. Feature: System Boundaries
*Verifying the system handles edge cases.*

### Scenario: Attempting a Move in a Full Column
* **Given:** A column in Connect 4 board is already full.
* **When:** The user clicks that same column again.
* **Then:** The java bridge identifies the move as invalid.
* **And:** No changes are made to the game state or the visual board.