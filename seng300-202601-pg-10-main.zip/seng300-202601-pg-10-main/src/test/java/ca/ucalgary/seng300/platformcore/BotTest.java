package ca.ucalgary.seng300.platformcore;

import ca.ucalgary.seng300.platformcore.game.GameMove;
import ca.ucalgary.seng300.platformcore.game.GameState;
import ca.ucalgary.seng300.platformcore.game.GridSpace;
import ca.ucalgary.seng300.platformcore.game.Piece;
import ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourPiece;
import ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToePiece;
import ca.ucalgary.seng300.validation.account.records.UserID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;

import static ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToePiece.X;
import static ca.ucalgary.seng300.platformcore.game.tictactoe.TicTacToePiece.O;
import static ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourPiece.RED;
import static ca.ucalgary.seng300.platformcore.game.connectfour.ConnectFourPiece.YELLOW;


import static org.junit.jupiter.api.Assertions.*;


class BotTest {
  Bot bot = new Bot();
  Player player = new Player(new UserID("Player"), "Player");

  public static GameState createGameState(GameType gameType, Piece[][] board, Player player1, Player player2) {
    Piece piece1;
    Piece piece2;

    if (gameType == GameType.CONNECTFOUR) {
      piece1 = RED;
      piece2 = YELLOW;
    }
    else {
      piece1 = X;
      piece2 = O;
    }

    HashMap<UserID, Piece> pieceMap = new HashMap<>();
    pieceMap.put(player1.getID(), piece1);
    pieceMap.put(player2.getID(), piece2);
    return new GameState(gameType, new UserID[]{player1.getID(), player2.getID()}, pieceMap, board);
  }

  @BeforeEach
  void updateBot() {
    bot = new Bot();
    bot.setID(new UserID("Bot"));
    bot.setDifficulty(6);
  }

  @Test
  void testDetectWinningTTTMoveVertical() {
    Piece[][] board = {
            {null, null, O},
            {null, X,    null},
            {O,    X,    null}
    };
    GameState state = createGameState(GameType.TICTACTOE, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(0,1), X);
    GameMove actual = bot.makeMove(state, player);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectWinningTTTMoveHorizontal() {
    Piece[][] board = {
            {null, null, O},
            {X,    null, X},
            {null, O,    null}
    };
    GameState state = createGameState(GameType.TICTACTOE, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(1,1), X);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece(), bot.getPiece(), 3);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectWinningTTTMoveLDiag() {
    Piece[][] board = {
            {X,    null, O},
            {null, null, O},
            {null, null, X}
    };
    GameState state = createGameState(GameType.TICTACTOE, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(1,1), X);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece(), bot.getPiece(), 3);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectWinningTTTMoveRDiag() {
    Piece[][] board = {
            {null, null, X},
            {O,    X,    null},
            {null, O,    null}
    };
    GameState state = createGameState(GameType.TICTACTOE, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(2,0), X);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece(), bot.getPiece(), 3);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectSurvivalTTTMoveVertical() {
    Piece[][] board = {
            {X,    null, O},
            {null, null, O},
            {X, null, null}
    };
    GameState state = createGameState(GameType.TICTACTOE, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(2, 2), X);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece().opposite(), bot.getPiece(), 3);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectSurvivalTTTMoveHorizontal() {
    Piece[][] board = {
            {O,    null, O},
            {null, null, X},
            {X, null, null}
    };
    GameState state = createGameState(GameType.TICTACTOE, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(0, 1), X);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece().opposite(), bot.getPiece(), 3);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectSurvivalTTTMoveLDiag() {
    Piece[][] board = {
            {null, null, null},
            {null, O,    null},
            {X,    X,    O}
    };
    GameState state = createGameState(GameType.TICTACTOE, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(0, 0), X);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece().opposite(), bot.getPiece(), 3);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectSurvivalTTTMoveRDiag() {
    Piece[][] board = {
            {X,    null, O},
            {null, null, X},
            {O,    null, null}
    };
    GameState state = createGameState(GameType.TICTACTOE, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(1, 1), X);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece().opposite(), bot.getPiece(), 3);
    assertEquals(expected, actual);
  }

  @Test
  void testRandomTTTMoveValid() {
    for (int i = 0; i < 1000; i++) { //tests randomness repeatedly
      Piece[][] board = {
              {O,    null, null},
              {null, null, X},
              {X,    O,    null}
      };
      GameState state = createGameState(GameType.TICTACTOE, board, bot, player);

      GameMove move = bot.makeMove(state, player);
      GridSpace space = move.getPos();

      assertNull(board[space.row][space.column]);
    }
  }

  @Test
  void testDetectWinningC4MoveVertical() {
    Piece[][] board = {
            {null, null, null,   null, null, null, null},
            {null, null, null,   null, null, null, null},
            {null, null, null,   null, null, null, null},
            {null, null, null,   RED, null, null, null},
            {null, null, null,   RED, null, YELLOW, null},
            {null, YELLOW, null, RED, null, YELLOW, null}
    };
    GameState state = createGameState(GameType.CONNECTFOUR, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(2,3), RED);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece(), bot.getPiece(), 4);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectWinningC4MoveHorizontal() {
    Piece[][] board = {
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, YELLOW, null, null, null, null},
            {YELLOW, YELLOW, RED, RED, null, RED, null}
    };
    GameState state = createGameState(GameType.CONNECTFOUR, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(5,4), RED);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece(), bot.getPiece(), 4);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectWinningC4MoveLDiag() {
    Piece[][] board = {
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, RED, null, null, null, null},
            {null, null, YELLOW, null, null, null, null},
            {null, null, YELLOW, YELLOW, RED, null, null},
            {null, null, YELLOW, RED, YELLOW, RED, null}
    };
    GameState state = createGameState(GameType.CONNECTFOUR, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(3,3), RED);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece(), bot.getPiece(), 4);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectWinningC4MoveRDiag() {
    Piece[][] board = {
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, null, null, RED, YELLOW, null},
            {null, null, null, RED, YELLOW, YELLOW, null},
            {null, null, RED, YELLOW, YELLOW, RED, null}
    };
    GameState state = createGameState(GameType.CONNECTFOUR, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(2,5), RED);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece(), bot.getPiece(), 4);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectSurvivalC4MoveVertical() {
    Piece[][] board = {
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, YELLOW, null, null, null, null, null},
            {null, YELLOW, null, RED, null, null, null},
            {null, YELLOW, null, RED, RED, null, null}
    };
    GameState state = createGameState(GameType.CONNECTFOUR, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(2, 1), RED);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece().opposite(), bot.getPiece(), 4);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectSurvivalC4MoveHorizontal() {
    Piece[][] board = {
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null},
            {null, null, RED, null, null, null, null},
            {null, RED, YELLOW, YELLOW, YELLOW, null, null}
    };
    GameState state = createGameState(GameType.CONNECTFOUR, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(5, 5), RED);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece().opposite(), bot.getPiece(), 4);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectSurvivalC4MoveLDiag() {
    Piece[][] board = {
            {null, null,   null, null,     null, null, null},
            {null, null,   null, null,     null, null, null},
            {null, YELLOW, null, null,     null, null, null},
            {null, RED,    null, null,     null, null, null},
            {null, RED,    RED,  YELLOW,   null, null, null},
            {null, RED,    RED,  YELLOW,   YELLOW, null, null}
    };
    GameState state = createGameState(GameType.CONNECTFOUR, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(3, 2), RED);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece().opposite(), bot.getPiece(), 4);
    assertEquals(expected, actual);
  }

  @Test
  void testDetectSurvivalC4MoveRDiag() {
    Piece[][] board = {
            {null, null, null, null, null,  null,   null},
            {null, null, null, null, null,  null,   null},
            {null, null, null, null, null,  null,   YELLOW},
            {null, null, null, null, null,  YELLOW, RED},
            {null, null, null, null, null,  RED,    YELLOW},
            {null, null, null, YELLOW, RED, RED,    RED}
    };
    GameState state = createGameState(GameType.CONNECTFOUR, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove expected = new GameMove(new GridSpace(4, 4), RED);
    GameMove actual = Bot.findForcedMove(board, bot.getPiece().opposite(), bot.getPiece(), 4);
    assertEquals(expected, actual);
  }

  @Test
  void testNoForcedC4MoveRDiag() {
    Piece[][] board = {
            {null, null, null, null, null,  null,   null},
            {null, null, null, null, null,  null,   null},
            {null, null, null, null, null,  null,   YELLOW},
            {null, null, null, null, null,  YELLOW, RED},
            {null, null, null, null, null,  RED,    YELLOW},
            {null, null, null, YELLOW, null, RED,    RED}
    };
    GameState state = createGameState(GameType.CONNECTFOUR, board, bot, player);
    bot.updateGameState(state, true, player);

    GameMove actual = Bot.findForcedMove(board, bot.getPiece().opposite(), bot.getPiece(), 4);
    assertNull(actual);
  }

  @Test
  void testRandomC4MoveValid() {
    for (int i = 0; i < 1000; i++) { //tests randomness repeatedly
      Piece[][] board = {
              {null,   null,   null, null,   null,   null,   null},
              {null,   null,   null, null,   null,   null,   null},
              {null,   null,   null, null,   null,   YELLOW, null},
              {null,   null,   null, RED,    null,   RED,    null},
              {null,   YELLOW, null, RED,    YELLOW, RED,    null},
              {YELLOW, RED,    RED,  YELLOW, RED,    YELLOW, YELLOW}
      };
      GameState state = createGameState(GameType.CONNECTFOUR, board, bot, player);

      GameMove move = bot.makeMove(state, player);
      GridSpace space = move.getPos();

      assertNull(board[space.row][space.column]);
    }
  }
}
