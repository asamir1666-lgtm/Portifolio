package ca.ucalgary.seng300;

import javafx.scene.web.WebEngine;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertTrue;

class PostGameResultsBridgeTest {

    private PostGameResultsBridge bridge;

    @BeforeEach
    void setUp() {
        bridge = new PostGameResultsBridge(null, null);
    }

    @Test
    void rematch_withNoClient_doesNotThrow() {
        bridge.rematch();
    }

    @Test
    void log_shouldPrintMessageWithJsPrefix() {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(output));

        try {
            bridge.log("hello from js");
            assertTrue(output.toString().contains("[JS]: hello from js"));
        } finally {
            System.setOut(originalOut);
        }
    }
}