/*
package ca.ucalgary.seng300.validation.gamevalidation;

import ca.ucalgary.seng300.validation.gamevalidation.enums.GamePiece;
import ca.ucalgary.seng300.validation.gamevalidation.enums.GameType;
import ca.ucalgary.seng300.validation.gamevalidation.enums.ValidationErrorCode;
import ca.ucalgary.seng300.validation.gamevalidation.results.MoveValidationResult;
import ca.ucalgary.seng300.validation.gamevalidation.results.WinValidationResult;
import ca.ucalgary.seng300.validation.gamevalidation.stubs.GameMove;
import ca.ucalgary.seng300.validation.gamevalidation.stubs.GameState;
import ca.ucalgary.seng300.validation.gamevalidation.stubs.GridSpace;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;
class GameValidationTest {
    */
/**
     * Test set-ups
     *//*

    private GameValidation gameValidation;

    // Creates an empty board for tests
    private GamePiece[][] emptyBoard(int rows, int columns) {
        GamePiece[][] board = new GamePiece[rows][columns];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                board[i][j] = GamePiece.EMPTY;
            }
        }
        return board;
    }

    // Initialized Player -> GamePiece hashmap for Tic-Tac-Toe for tests
    private HashMap<Integer, GamePiece> ticTacToePlayers() {
        HashMap<Integer, GamePiece> players = new HashMap<>();
        players.put(1, GamePiece.X);
        players.put(2, GamePiece.O);
        return players;
    }

    // Initialized Player -> GamePiece hashmap for Connect-4 for tests
    private HashMap<Integer, GamePiece> connect4Players() {
        HashMap<Integer, GamePiece> players = new HashMap<>();
        players.put(1, GamePiece.RED);
        players.put(2, GamePiece.YELLOW);
        return players;
    }

    // Initialized Game State for tests
    private GameState newGameState(GameType gameType, int[] playerIDs, HashMap<Integer, GamePiece> players, GamePiece[][] board) {
        return new GameState(gameType, playerIDs, players, board);
    }

    // Creates a new GameValidation object before each test for a fresh run
    @BeforeEach
    void testSetUp() {
        gameValidation = new GameValidation();
    }


    */
/**
     * NULL GAMESTATE, MOVE, AND BOARD + OTHER CHECKS
     *//*

    // CHECK NULL GAME STATE FOR TIC TAC TOE
    @Test
    void checkNullState_gameState_ticTacToe() {
        GamePiece[][] emptyBoard = emptyBoard(3, 3);
        GameMove testMove = new GameMove(1, new GridSpace(1, 1), new GridSpace(-1, -1), GamePiece.X);

        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, null, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());

    }

    // CHECK NULL PLAYER MOVE FOR TIC TAC TOE
    @Test
    void checkNullState_move_ticTacToe() {
        GamePiece[][] emptyBoard = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), emptyBoard);

        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, testState, 1, null);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());

    }

    // CHECK NULL GAME BOARD FOR TIC TAC TOE
    @Test
    void checkNullState_board_ticTacToe() {
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), null);
        GameMove testMove = new GameMove(1, new GridSpace(1, 1), new GridSpace(-1, -1), GamePiece.X);


        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());

    }

    // CHECK NULL GAME STATE FOR CONNECT 4
    @Test
    void checkNullState_gameState_connect4() {
        GameMove testMove = new GameMove(1, new GridSpace(5, 1), new GridSpace(-1, -1), GamePiece.RED);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, null, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }

    // CHECK NULL PLAYER MOVE FOR CONNECT 4
    @Test
    void checkNullState_move_connect4() {
        GamePiece[][] emptyBoard = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), emptyBoard);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 1, null);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }

    // CHECK NULL GAME BOARD FOR CONNECT 4
    @Test
    void checkNullState_board_connect4() {
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), null);
        GameMove testMove = new GameMove(1, new GridSpace(5, 1), new GridSpace(-1, -1), GamePiece.RED);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Missing game data", result.getMessage());
    }


    */
/**
     * MOVE VALIDATION TESTS FOR TIC-TAC-TOE GAMES
     * Tests that check for: valid moves, invalid moves: out of bounds, cell occupied, wrong player turn, wrong piece placed
     * 1 test for valid move, 2 for out-of-bounds, 1 for cell occupied, 2 for wrong player turn, 2 for wrong player piece
     *//*

    // Test for a(ny) valid tic-tac-toe move (in board bounds, open cell, correct player move, etc.), SHOULD RETURN TRUE.
    @Test
    void validateMove_validMove_ticTacToe() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        GameMove testMove = new GameMove(1, new GridSpace(1, 1), new GridSpace(-1, -1), GamePiece.X);

        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, testState, 1, testMove);

        assertTrue(result.isValid());
        assertNull(result.getErrorCode());
        assertEquals("Move Accepted", result.getMessage());

    }

    // Test to see if a move is out of bounds (larger index) in tic-tac-toe
    @Test
    void validateMove_invalidMove_outOfBounds_largeIndex_ticTacToe() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        GameMove testMove = new GameMove(1, new GridSpace(4, 4), new GridSpace(-1, -1), GamePiece.X);

        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals("This move is out of bounds", result.getMessage());
    }

    // Test to see if a move is out of bounds (negative index) in tic-tac-toe
    @Test
    void validateMove_invalidMove_outOfBounds_negativeIndex_ticTacToe() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        GameMove testMove = new GameMove(1, new GridSpace(-2, -2), new GridSpace(-1, -1), GamePiece.X);

        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals("This move is out of bounds", result.getMessage());
    }

    // Test to see if a cell is occupied by any piece in tic-tac-toe
    @Test
    void validateMove_invalidMove_cellOccupied_ticTacToe() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        board[1][1] = GamePiece.O;
        GameMove testMove = new GameMove(1, new GridSpace(1, 1), new GridSpace(-1, -1), GamePiece.X);

        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.CELL_OCCUPIED, result.getErrorCode());
        assertEquals("This cell is already taken", result.getMessage());
    }


    // Two tests that check for invalid turns from players 1 and 2 in tic-tac-toe
    @Test
    void validateMove_invalidMove_wrongPlayerTurn1_ticTacToe() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        GameMove testMove = new GameMove(1, new GridSpace(1, 1), new GridSpace(-1, -1), GamePiece.X);

        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, testState, 2, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.INVALID_TURN, result.getErrorCode());
        assertEquals("It is not your turn", result.getMessage());
    }

    @Test
    void validateMove_invalidMove_wrongPlayerTurn2_ticTacToe() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        GameMove testMove = new GameMove(2, new GridSpace(1, 1), new GridSpace(-1, -1), GamePiece.O);

        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.INVALID_TURN, result.getErrorCode());
        assertEquals("It is not your turn", result.getMessage());
    }

    // Two tests that check for the wrong piece being placed down by players 1 and 2 in tic-tac-toe
    @Test
    void validateMove_invalidMove_wrongPieceForPlayer1_ticTacToe() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        GameMove testMove = new GameMove(1, new GridSpace(1, 1), new GridSpace(-1, -1), GamePiece.O);

        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals("You cannot place your opponent's piece", result.getMessage());
    }

    @Test
    void validateMove_invalidMove_wrongPieceForPlayer2_ticTacToe() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        GameMove testMove = new GameMove(2, new GridSpace(1, 1), new GridSpace(-1, -1), GamePiece.X);

        MoveValidationResult result = gameValidation.validateMove(GameType.TIC_TAC_TOE, testState, 2, testMove);

        assertFalse(result.isValid());
        assertEquals("You cannot place your opponent's piece", result.getMessage());
    }

    */
/**
     * MOVE VALIDATION TESTS FOR CONNECT-4 GAMES
     * Tests that check for: valid moves, invalid moves: out of bounds, cell occupied, wrong player turn, wrong piece placed, gravity
     * 2 tests for valid move, 2 for out-of-bounds, 1 for cell occupied, 2 for wrong player turn, 2 for wrong player piece, 1 for gravity
     *//*


    // Test that checks for a valid move at the bottom of the board in connect 4
    @Test
    void validateMove_validMove_bottomOfBoard_connect4() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        GameMove testMove = new GameMove(1, new GridSpace(5, 1), new GridSpace(-1, -1), GamePiece.RED);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 1, testMove);

        assertTrue(result.isValid());
        assertNull(result.getErrorCode());
        assertEquals("Move Accepted", result.getMessage());
    }

    // Test that checks for a valid move on top of a piece in connect 4
    @Test
    void validateMove_validMove_topOfPiece_connect4() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        board[5][1] = GamePiece.YELLOW;
        GameMove testMove = new GameMove(1, new GridSpace(4, 1), new GridSpace(-1, -1), GamePiece.RED);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 1, testMove);

        assertTrue(result.isValid());
        assertNull(result.getErrorCode());
        assertEquals("Move Accepted", result.getMessage());
    }

    // Two tests that check for out-of-bounds moves for both large and negative indexes in connect 4
    @Test
    void validateMove_invalidMove_outOfBounds_largeIndex_connect4() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        GameMove testMove = new GameMove(1, new GridSpace(10, 10), new GridSpace(-1, -1), GamePiece.RED);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.OUT_OF_BOUNDS, result.getErrorCode());
        assertEquals("This move is out of bounds", result.getMessage());
    }

    @Test
    void validateMove_invalidMove_outOfBounds_negativeIndex_connect4() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        GameMove testMove = new GameMove(1, new GridSpace(-1, -1), new GridSpace(-1, -1), GamePiece.RED);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.OUT_OF_BOUNDS, result.getErrorCode());
        assertEquals("This move is out of bounds", result.getMessage());
    }

    // Test that checks for an invalid move regarding an occupied cell in connect 4
    @Test
    void validateMove_invalidMove_cellOccupied_connect4() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        board[5][1] = GamePiece.YELLOW;
        GameMove testMove = new GameMove(1, new GridSpace(5, 1), new GridSpace(-1, -1), GamePiece.RED);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.CELL_OCCUPIED, result.getErrorCode());
        assertEquals("This cell is already taken", result.getMessage());
    }

    // Two tests that check for invalid player turns for players 1 and 2 in connect 4
    @Test
    void validateMove_invalidMove_wrongPlayerTurn1_connect4() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        GameMove testMove = new GameMove(1, new GridSpace(5, 1), new GridSpace(-1, -1), GamePiece.RED);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 2, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.INVALID_TURN, result.getErrorCode());
        assertEquals("It is not your turn", result.getMessage());
    }

    @Test
    void validateMove_invalidMove_wrongPlayerTurn2_connect4() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        GameMove testMove = new GameMove(2, new GridSpace(5, 1), new GridSpace(-1, -1), GamePiece.YELLOW);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.INVALID_TURN, result.getErrorCode());
        assertEquals("It is not your turn", result.getMessage());
    }

    // Two tests that check for the wrong piece being placed down by players 1 and 2 in connect 4
    @Test
    void validateMove_invalidMove_wrongPieceForPlayer1_connect4() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        GameMove testMove = new GameMove(1, new GridSpace(5, 1), new GridSpace(-1, -1), GamePiece.YELLOW);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals("You cannot place your opponent's piece", result.getMessage());
    }

    @Test
    void validateMove_invalidMove_wrongPieceForPlayer2_connect4() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        GameMove testMove = new GameMove(2, new GridSpace(5, 1), new GridSpace(-1, -1), GamePiece.RED);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 2, testMove);

        assertFalse(result.isValid());
        assertEquals("You cannot place your opponent's piece", result.getMessage());
    }

    // Test that checks for gravity violation (e.g. floating piece) in connect 4
    @Test
    void validateMove_invalidMove_gravityViolation_connect4() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        GameMove testMove = new GameMove(1, new GridSpace(1, 1), new GridSpace(-1, -1), GamePiece.RED);

        MoveValidationResult result = gameValidation.validateMove(GameType.CONNECT_4, testState, 1, testMove);

        assertFalse(result.isValid());
        assertEquals(ValidationErrorCode.ILLEGAL_MOVE, result.getErrorCode());
        assertEquals("Connect 4 piece MUST fall to the bottom or rest on another piece", result.getMessage());
    }

    */
/**
     * WIN CHECKS AND CONDITIONS
     * Tests that check for: Either player winning in both games
     * 4 tests each for each game that look for vertical, horizontal, left/right diagonal wins
     *//*

    // Test that checks for a straight, vertical win in column 1 for player 1 (X) in tic-tac-toe
    @Test
    void validateWin_ticTacToe_verticalX() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        board[0][0] = GamePiece.X;
        board[1][0] = GamePiece.X;
        board[2][0] = GamePiece.X;

        WinValidationResult result = gameValidation.validateWin(testState, ticTacToePlayers());

        assertTrue(result.hasWinner());
        assertEquals(1, result.getWinnerID());

    }

    // Test that checks for a straight, vertical win in row 1 for player 1 (X) in tic-tac-toe
    @Test
    void validateWin_ticTacToe_horizontalX() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        board[0][0] = GamePiece.X;
        board[0][1] = GamePiece.X;
        board[0][2] = GamePiece.X;

        WinValidationResult result = gameValidation.validateWin(testState, ticTacToePlayers());

        assertTrue(result.hasWinner());
        assertEquals(1, result.getWinnerID());

    }

    // Test that checks for a right diagonal win for player 1 (X) in tic-tac-toe
    @Test
    void validateWin_ticTacToe_rightDiagonalX() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        board[0][2] = GamePiece.X;
        board[1][1] = GamePiece.X;
        board[2][0] = GamePiece.X;

        WinValidationResult result = gameValidation.validateWin(testState, ticTacToePlayers());

        assertTrue(result.hasWinner());
        assertEquals(1, result.getWinnerID());

    }

    // Test that checks for a left diagonal win for player 1 (X) in tic-tac-toe
    @Test
    void validateWin_ticTacToe_leftDiagonalX() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        board[0][0] = GamePiece.X;
        board[1][1] = GamePiece.X;
        board[2][2] = GamePiece.X;

        WinValidationResult result = gameValidation.validateWin(testState, ticTacToePlayers());

        assertTrue(result.hasWinner());
        assertEquals(1, result.getWinnerID());

    }

    // Test that checks for a straight vertical win in column 1 for player 1 (RED) in connect 4
    @Test
    void validateWin_connect4_verticalRed() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        board[5][0] = GamePiece.RED;
        board[4][0] = GamePiece.RED;
        board[3][0] = GamePiece.RED;
        board[2][0] = GamePiece.RED;

        WinValidationResult result = gameValidation.validateWin(testState, connect4Players());

        assertTrue(result.hasWinner());
        assertEquals(1, result.getWinnerID());

    }

    // Test that checks for a straight vertical win in column 1 for player 1 (RED) in connect 4
    @Test
    void validateWin_connect4_horizontalRed() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        board[5][0] = GamePiece.RED;
        board[5][1] = GamePiece.RED;
        board[5][2] = GamePiece.RED;
        board[5][3] = GamePiece.RED;

        WinValidationResult result = gameValidation.validateWin(testState, connect4Players());

        assertTrue(result.hasWinner());
        assertEquals(1, result.getWinnerID());

    }

    // Test that checks for a right diagonal win for player 1 (RED) in connect 4. Will defy gravity for the sake of testing
    @Test
    void validateWin_connect4_rightDiagonalRed() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        board[5][0] = GamePiece.RED;
        board[4][1] = GamePiece.RED;
        board[3][2] = GamePiece.RED;
        board[2][3] = GamePiece.RED;

        WinValidationResult result = gameValidation.validateWin(testState, connect4Players());

        assertTrue(result.hasWinner());
        assertEquals(1, result.getWinnerID());

    }

    // Test that checks for a left diagonal win for player 1 (RED) in connect 4. Will defy gravity for the sake of testing
    @Test
    void validateWin_connect4_leftDiagonalRed() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        board[2][0] = GamePiece.RED;
        board[3][1] = GamePiece.RED;
        board[4][2] = GamePiece.RED;
        board[5][3] = GamePiece.RED;

        WinValidationResult result = gameValidation.validateWin(testState, connect4Players());

        assertTrue(result.hasWinner());
        assertEquals(1, result.getWinnerID());

    }

    */
/**
     * DRAW CHECKS AND CONDITIONS
     * Tests that check for: A full board with no winners, resulting in a draw
     *//*

    // Test that checks for a draw result in a full board with no winners in tic tac toe (9 total moves).
    @Test
    void validateDraw_ticTacToe_fullBoard1() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        // 5 total moves for player 1 (X)
        board[0][0] = GamePiece.X;
        board[0][1] = GamePiece.X;

        board[1][2] = GamePiece.X;

        board[2][0] = GamePiece.X;
        board[2][2] = GamePiece.X;

        // 4 total moves for player 2 (O)
        board[0][2] = GamePiece.O;

        board[1][0] = GamePiece.O;
        board[1][1] = GamePiece.O;

        board[2][1] = GamePiece.O;

        WinValidationResult result = gameValidation.validateWin(testState, ticTacToePlayers());

        assertFalse(result.hasWinner());
        assertEquals(-1, result.getWinnerID());

    }

    // Test that checks for a draw result in a full board with no winners in connect 4 (42 total moves).
    @Test
    void validateDraw_connect4_fullBoard1() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        // 21 total moves for RED
        board[0][1] = GamePiece.RED;
        board[0][2] = GamePiece.RED;
        board[0][4] = GamePiece.RED;
        board[0][5] = GamePiece.RED;

        board[1][0] = GamePiece.RED;
        board[1][3] = GamePiece.RED;

        board[2][0] = GamePiece.RED;
        board[2][2] = GamePiece.RED;
        board[2][3] = GamePiece.RED;
        board[2][4] = GamePiece.RED;
        board[2][6] = GamePiece.RED;

        board[3][0] = GamePiece.RED;
        board[3][2] = GamePiece.RED;
        board[3][3] = GamePiece.RED;
        board[3][4] = GamePiece.RED;
        board[3][6] = GamePiece.RED;

        board[4][1] = GamePiece.RED;
        board[4][2] = GamePiece.RED;
        board[4][4] = GamePiece.RED;
        board[4][5] = GamePiece.RED;

        board[5][3] = GamePiece.RED;

        // 21 total moves for YELLOW
        board[0][0] = GamePiece.YELLOW;
        board[0][3] = GamePiece.YELLOW;
        board[0][6] = GamePiece.YELLOW;

        board[1][1] = GamePiece.YELLOW;
        board[1][2] = GamePiece.YELLOW;
        board[1][4] = GamePiece.YELLOW;
        board[1][5] = GamePiece.YELLOW;
        board[1][6] = GamePiece.YELLOW;

        board[2][1] = GamePiece.YELLOW;
        board[2][5] = GamePiece.YELLOW;

        board[3][1] = GamePiece.YELLOW;
        board[3][5] = GamePiece.YELLOW;

        board[4][0] = GamePiece.YELLOW;
        board[4][3] = GamePiece.YELLOW;
        board[4][6] = GamePiece.YELLOW;

        board[5][0] = GamePiece.YELLOW;
        board[5][1] = GamePiece.YELLOW;
        board[5][2] = GamePiece.YELLOW;
        board[5][4] = GamePiece.YELLOW;
        board[5][5] = GamePiece.YELLOW;
        board[5][6] = GamePiece.YELLOW;

        WinValidationResult result = gameValidation.validateWin(testState, ticTacToePlayers());

        assertFalse(result.hasWinner());
        assertEquals(-1, result.getWinnerID());

    }

    */
/**
     * INCOMPLETE WIN CHECKS AND CONDITIONS
     * Tests that check for: Either a game in progress/no winner yet
     *//*

    // Empty board test. Should have no winner in tic-tac-toe
    @Test
    void emptyBoard_ticTacToe() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);

        WinValidationResult result = gameValidation.validateWin(testState, ticTacToePlayers());

        assertFalse(result.hasWinner());
        assertEquals(-1, result.getWinnerID());

    }
    // Test that checks for an incomplete win for player 1 (X) in tic-tac-toe
    @Test
    void partialGame_ticTacToe1() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        board[0][2] = GamePiece.X;
        board[1][1] = GamePiece.X;
        board[2][1] = GamePiece.X;

        WinValidationResult result = gameValidation.validateWin(testState, ticTacToePlayers());

        assertFalse(result.hasWinner());
        assertEquals(-1, result.getWinnerID());

    }

    // Test that checks for an incomplete win for player 1 (X) in tic-tac-toe
    @Test
    void partialGame_ticTacToe2() {
        GamePiece[][] board = emptyBoard(3, 3);
        GameState testState = newGameState(GameType.TIC_TAC_TOE, new int[]{1, 2}, ticTacToePlayers(), board);
        board[0][2] = GamePiece.X;
        board[2][1] = GamePiece.X;

        WinValidationResult result = gameValidation.validateWin(testState, ticTacToePlayers());

        assertFalse(result.hasWinner());
        assertEquals(-1, result.getWinnerID());

    }

    // Test that checks for an incomplete win for player 1 (RED) in connect 4
    @Test
    void emptyBoard_connectFour() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);

        WinValidationResult result = gameValidation.validateWin(testState, connect4Players());

        assertFalse(result.hasWinner());
        assertEquals(-1, result.getWinnerID());

    }

    // Test that checks for an incomplete win for player 1 (RED) in connect 4
    @Test
    void partialGame_connectFour1() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        board[2][0] = GamePiece.RED;
        board[3][1] = GamePiece.RED;
        board[4][2] = GamePiece.RED;
        board[5][5] = GamePiece.RED;

        WinValidationResult result = gameValidation.validateWin(testState, connect4Players());

        assertFalse(result.hasWinner());
        assertEquals(-1, result.getWinnerID());

    }

    // Test that checks for an incomplete win for player 1 (RED) in connect 4
    @Test
    void partialGame_connectFour2() {
        GamePiece[][] board = emptyBoard(6, 7);
        GameState testState = newGameState(GameType.CONNECT_4, new int[]{1, 2}, connect4Players(), board);
        board[2][0] = GamePiece.RED;
        board[3][1] = GamePiece.RED;
        board[4][2] = GamePiece.RED;

        WinValidationResult result = gameValidation.validateWin(testState, connect4Players());

        assertFalse(result.hasWinner());
        assertEquals(-1, result.getWinnerID());

    }












}
*/
