package ca.ucalgary.seng300.validation.account;

import ca.ucalgary.seng300.validation.account.enums.AccountErrorCode;
import ca.ucalgary.seng300.validation.account.results.AccountCreationResult;
import ca.ucalgary.seng300.validation.account.results.OperationResult;
import ca.ucalgary.seng300.validation.account.stubs.CredentialsStoreStub;
import ca.ucalgary.seng300.validation.account.stubs.TokenManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AccountDatabaseManagerTests {
    private AccountDatabaseManager manager;
    private CredentialsStoreStub credentialsStore;
    private TokenManager tokenManager;
    private AccountValidation validation;

    @BeforeEach
    void setup() {
        credentialsStore = new CredentialsStoreStub();
        tokenManager = new TokenManager();
        validation = new AccountValidation(credentialsStore, tokenManager);
        manager = new AccountDatabaseManager(validation);
    }

    //CreateAccount tests

    @Test
    void createAccountValidInputShouldSucceed() {
        AccountCreationResult result = manager.createAccount("Ronin", "Password1");
        assertTrue(result.success);
        assertNotNull(result.token);
        assertNotNull(result.userProfile);
    }

    @Test
    void createAccountUsernameTakenShouldFail() {
        manager.createAccount("Ronin", "Password1");
        AccountCreationResult result = manager.createAccount("Ronin", "Password1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USERNAME_TAKEN, result.errorCode);
    }

    @Test
    void createAccountInvalidFormatShouldFail() {
        AccountCreationResult result = manager.createAccount("", "Password1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    @Test
    void createAccountNullUsernameShouldFail() {
        AccountCreationResult result = manager.createAccount(null, "Password1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    @Test
    void createAccountNullPasswordShouldFail() {
        AccountCreationResult result = manager.createAccount("Ronin", null);
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    @Test
    void createAccountBothNullShouldFail() {
        AccountCreationResult result = manager.createAccount(null, null);
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    //updateUsername tests

    @Test
    void updateUsernameIsValidShouldSucceed() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.updateUsername("Ronin", "Password1", "Risha");
        assertTrue(result.success);
    }

    @Test
    void updateUsernameCredStoreIsUpdated() {
        manager.createAccount("Ronin", "Password1");
        manager.updateUsername("Ronin", "Password1", "Risha");
        assertNull(validation.getUserCredentials("Ronin"));
        assertNotNull(validation.getUserCredentials("Risha"));
    }

    @Test
    void updateUsernamePasswordRemainsSame() {
        manager.createAccount("Ronin", "Password1");
        manager.updateUsername("Ronin", "Password1", "Risha");
        OperationResult result = manager.updateUsername("Risha", "Password1", "Asher");
        assertTrue(result.success);
    }


    @Test
    void updateUsernameNotValidUserNotFound() {
        OperationResult result = manager.updateUsername("Ronin", "Password1", "Risha");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USER_NOT_FOUND, result.errorCode);
    }

    @Test
    void updateUsernameNotValidUsernameTaken() {
        manager.createAccount("Ronin", "Password1");
        manager.createAccount("Risha", "Password123");
        OperationResult result = manager.updateUsername("Risha", "Password123", "Ronin");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USERNAME_TAKEN, result.errorCode);
    }

    @Test
    void updateUsernameNotValidSameUsername() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.updateUsername("Ronin", "Password1", "Ronin");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USERNAME_TAKEN, result.errorCode);
    }

    @Test
    void updateUsernameNotValidEmptyInput() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.updateUsername("Ronin", "Password1", "");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    @Test
    void updateUsernameNullUsernameShouldFail() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.updateUsername(null, "Password1", "Risha");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USER_NOT_FOUND, result.errorCode);
    }

    @Test
    void updateUsernameNullPasswordShouldFail() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.updateUsername("Ronin", null, "Risha");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_CREDENTIALS, result.errorCode);
    }

    @Test
    void updateUsernameNullNewUsernameShouldFail() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.updateUsername("Ronin", "Password1", null);
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    @Test
    void updateUsernameAllNullShouldFail() {
        OperationResult result = manager.updateUsername(null, null, null);
        assertFalse(result.success);
    }

    //updatePassword tests

    @Test
    void updatePasswordIsValidShouldSucceed() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.updatePassword("Ronin", "Password1", "newerpassword1");
        assertTrue(result.success);
    }

    @Test
    void updatePasswordUpdatesCredStore() {
        manager.createAccount("Ronin", "password1");
        manager.updatePassword("Ronin", "password1", "newerpassword1");
        OperationResult result = manager.updatePassword("Ronin", "password1", "anotherpassword1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_CREDENTIALS, result.errorCode);
    }

    @Test
    void updatePasswordNewPasswordWorks() {
        manager.createAccount("Ronin", "password1");
        manager.updatePassword("Ronin", "password1", "newerpassword1");
        OperationResult result = manager.updatePassword("Ronin", "newerpassword1", "anotherpassword1");
        assertTrue(result.success);
    }

    @Test
    void updatePasswordNotValidNoUserFound() {
      OperationResult result =  manager.updatePassword("Ronin", "password1", "newerpassword1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USER_NOT_FOUND, result.errorCode);
    }

    @Test
    void updatePasswordNotValidWrongOldPassword() {
        manager.createAccount("Ronin", "password1");
        OperationResult result =  manager.updatePassword("Ronin", "wrongpassword1", "newerpassword1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_CREDENTIALS, result.errorCode);
    }

    @Test
    void updatePasswordNotValidEmptyNewPassword() {
        manager.createAccount("Ronin", "password1");
        OperationResult result =  manager.updatePassword("Ronin", "password1", "");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    @Test
    void updatePasswordNotValidSamePassword() {
        manager.createAccount("Ronin", "password1");
        OperationResult result =  manager.updatePassword("Ronin", "password1", "password1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.PASSWORD_MISMATCH, result.errorCode);
    }

    @Test
    void updatePasswordNullUsernameShouldFail() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.updatePassword(null, "Password1", "NewerPass1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USER_NOT_FOUND, result.errorCode);
    }

    @Test
    void updatePasswordNullOldPasswordShouldFail() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.updatePassword("Ronin", null, "NewerPass1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_CREDENTIALS, result.errorCode);
    }

    @Test
    void updatePasswordNullNewPasswordShouldFail() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.updatePassword("Ronin", "Password1", null);
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    @Test
    void updatePasswordAllNullShouldFail() {
        OperationResult result = manager.updatePassword(null, null, null);
        assertFalse(result.success);
    }

    //DeleteAccount tests

    @Test
    void deleteAccountIsValidShouldSucceed() {
        manager.createAccount("Ronin", "password1");
        OperationResult result = manager.deleteAccount("Ronin", "password1");
        assertTrue(result.success);
    }

    @Test
    void deleteAccountShouldRemoveCredentials() {
        manager.createAccount("Ronin", "password1");
        manager.deleteAccount("Ronin", "password1");
        assertNull(validation.getUserCredentials("Ronin"));
    }

    @Test
    void deleteAccountNotValidUserNotFound() {
        OperationResult result = manager.deleteAccount("Ronin", "password1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USER_NOT_FOUND, result.errorCode);
    }

    @Test
    void deleteAccountNotValidWrongPassword() {
        manager.createAccount("Ronin", "password1");
        OperationResult result = manager.deleteAccount("Ronin", "wrongpassword1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_CREDENTIALS, result.errorCode);
    }

    @Test
    void deleteAccountWrongPasswordCredentialsArentRemoved() {
        manager.createAccount("Ronin", "password1");
        manager.deleteAccount("Ronin", "wrongpassword1");
        // credentials should still exist since deletion failed
        assertNotNull(validation.getUserCredentials("Ronin"));
    }

    @Test
    void deleteAccountNotValidEmptyPassword() {
        manager.createAccount("Ronin", "password");
        OperationResult result = manager.deleteAccount("Ronin", "");
        assertFalse(result.success);
    }

    @Test
    void deleteAccountShouldAllowReuseOfUsername() {
        manager.createAccount("Ronin", "password1");
        manager.deleteAccount("Ronin", "password1");
        // same username should be available again after deletion
        AccountCreationResult result = manager.createAccount("Ronin", "password1");
        assertTrue(result.success);
        assertNotNull(result.userProfile);
    }

    @Test
    void deleteAccountNotValidAlreadyDeleted() {
        manager.createAccount("Ronin", "password1");
        manager.deleteAccount("Ronin", "password1");
        // trying to delete again should fail since user no longer exists
        OperationResult result = manager.deleteAccount("Ronin", "password1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USER_NOT_FOUND, result.errorCode);
    }

    @Test
    void deleteAccountNullUsernameShouldFail() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.deleteAccount(null, "Password1");
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USER_NOT_FOUND, result.errorCode);
    }

    @Test
    void deleteAccountNullPasswordShouldFail() {
        manager.createAccount("Ronin", "Password1");
        OperationResult result = manager.deleteAccount("Ronin", null);
        assertFalse(result.success);
        assertEquals(AccountErrorCode.INVALID_CREDENTIALS, result.errorCode);
    }

    @Test
    void deleteAccountBothNullShouldFail() {
        OperationResult result = manager.deleteAccount(null, null);
        assertFalse(result.success);
        assertEquals(AccountErrorCode.USER_NOT_FOUND, result.errorCode);
    }

}
