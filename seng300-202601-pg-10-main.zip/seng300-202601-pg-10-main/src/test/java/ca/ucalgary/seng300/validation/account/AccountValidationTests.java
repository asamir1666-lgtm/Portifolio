package ca.ucalgary.seng300.validation.account;

import ca.ucalgary.seng300.validation.account.enums.AccountErrorCode;
import ca.ucalgary.seng300.validation.account.records.UserID;
import ca.ucalgary.seng300.validation.account.results.AccountValidationResult;
import ca.ucalgary.seng300.validation.account.results.ValidationResult;
import ca.ucalgary.seng300.validation.account.stubs.CredentialsStoreStub;
import ca.ucalgary.seng300.validation.account.stubs.TokenManager;
import ca.ucalgary.seng300.validation.account.stubs.UserCredentials;
import ca.ucalgary.seng300.validation.account.stubs.UserProfile;
import ca.ucalgary.seng300.validation.account.stubs.SessionToken;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AccountValidationTests {

    private AccountValidation validation;
    private CredentialsStoreStub credentialsStore;
    private TokenManager tokenManager;

    // valid format credentials used across tests
    private static final String VALID_USER      = "Risha";
    private static final String VALID_PASSWORD  = "Password1";
    private static final String VALID_USER_ID   = "risha-001";
    private static final String INVALID_TOKEN   = "invalid_token";

    @BeforeEach
    void setup() {
        credentialsStore = new CredentialsStoreStub();
        tokenManager     = new TokenManager();
        validation       = new AccountValidation(credentialsStore, tokenManager);

        //seed one registered user so login / edit tests have something to work with
        String hashed = AccountValidation.hashPassword(VALID_PASSWORD);
        UserProfile profile = new UserProfile(new UserID(VALID_USER_ID), VALID_USER);
        UserCredentials creds = new UserCredentials(profile, hashed);
        credentialsStore.saveCredentials(creds);
    }

    // Tests for ValidateLogin

    @Test
    void loginValidCredentialsShouldSucceed() {
        AccountValidationResult result = validation.validateLogin(VALID_USER, VALID_PASSWORD);
        assertTrue(result.isValid);
        assertNotNull(result.token);
        assertNotNull(result.userProfile);
    }

    @Test
    void loginShouldStoreTokenInTokenManager() {
        AccountValidationResult res = validation.validateLogin(VALID_USER, VALID_PASSWORD);
        UserID userId = res.userProfile.userID;
        assertTrue(res.isValid);
        assertNotNull(tokenManager.getToken(userId));
    }
    @Test
    void loginWrongPasswordShouldFail() {
        AccountValidationResult result = validation.validateLogin(VALID_USER, "WrongPass9");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_CREDENTIALS,result.errorCode);
    }

    @Test
    void loginUserNotFoundShouldFail() {
        AccountValidationResult result = validation.validateLogin("ghost_user", "Password1");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.USER_NOT_FOUND, result.errorCode);
    }

    @Test
    void loginInvalidFormatShouldFail() {
        AccountValidationResult result = validation.validateLogin("ab", "Password1");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    @Test
    void loginNullInputShouldFail() {
        AccountValidationResult result = validation.validateLogin(null, null);
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    // Tests for validateRegistration

    @Test
    void registrationValidInputShouldSucceed() {
        ValidationResult result = validation.validateRegistration("new_user1","Secure99");
        assertTrue(result.isValid);
    }

    @Test
    void registrationUsernameTakenShouldFail() {
        ValidationResult result = validation.validateRegistration(VALID_USER,"Secure99");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.USERNAME_TAKEN, result.errorCode);
    }

    @Test
    void registrationInvalidFormatUsernameShouldFail() {
        ValidationResult result = validation.validateRegistration("ab", "Secure99");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_FORMAT,result.errorCode);
    }

    @Test
    void registrationInvalidFormatPasswordNoDigitShouldFail() {
        ValidationResult result = validation.validateRegistration("new_user1", "NoDigitsHere");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }
    @Test
    void registrationInvalidFormatPasswordNoLetterShouldFail() {
        ValidationResult result = validation.validateRegistration("new_user1","12345678");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    @Test
    void registrationInvalidFormatEmptyInputShouldFail() {
        ValidationResult result = validation.validateRegistration("","");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }

    // Tests for validateToken

    @Test
    void validateTokenValidShouldSucceed() {
        AccountValidationResult loginResult = validation.validateLogin(VALID_USER, VALID_PASSWORD);
        ValidationResult result = validation.validateToken(loginResult.token);
        assertTrue(result.isValid);
    }


    @Test
    void validateTokenWrongValueShouldFail() {
        // TODO: Fix pls
        // validation.validateLogin(VALID_USER, VALID_PASSWORD);
        // ValidationResult result = validation.validateToken(new SessionToken(INVALID_TOKEN, VALID_USER_ID));
        // assertFalse(result.isValid);
        // assertEquals(AccountErrorCode.INVALID_TOKEN, result.errorCode);
    }

    @Test
    void validateTokenNoSessionShouldFail() {
        // TODO: Fix pls
        // ValidationResult result = validation.validateToken(VALID_USER, "any_token");
        // assertFalse(result.isValid);
        // assertEquals(AccountErrorCode.SESSION_NOT_FOUND,result.errorCode);
    }

    @Test
    void validateTokenExpiredShouldFail() {
        // TODO: Fix pls
        // SessionToken expiredToken = new SessionToken("expired_value");
        // expiredToken.createdAt = System.currentTimeMillis() - (31 *60 * 1000L);
        // tokenManager.writeToken(VALID_USER, expiredToken);
        //
        // ValidationResult result = validation.validateToken(VALID_USER,"expired_value");
        // assertFalse(result.isValid);
        // assertEquals(AccountErrorCode.TOKEN_EXPIRED, result.errorCode);
    }

    @Test
    void validateTokenExpiredShouldRemoveToken() {
        // TODO: Fix pls
        // SessionToken expiredToken = new SessionToken("expired_value");
        // expiredToken.createdAt = System.currentTimeMillis() -(31 * 60 * 1000L);
        // tokenManager.writeToken(VALID_USER, expiredToken);
        //
        // validation.validateToken(VALID_USER, "expired_value");
        // assertNull(tokenManager.getToken(VALID_USER));
    }

    // Tests for endSessionToken

    @Test
    void endSessionValidTokenShouldSucceed() {
        // TODO: Fix pls
        // AccountValidationResult loginResult = validation.validateLogin(VALID_USER, VALID_PASSWORD);
        // ValidationResult result = validation.endSessionToken(VALID_USER, loginResult.token);
        // assertTrue(result.isValid);
    }

    @Test
    void endSessionShouldRemoveToken() {
        // TODO: Fix pls
        // AccountValidationResult loginResult = validation.validateLogin(VALID_USER, VALID_PASSWORD);
        // validation.endSessionToken(VALID_USER, loginResult.token);
        // assertNull(tokenManager.getToken(VALID_USER));
    }

    @Test
    void endSessionWrongTokenShouldFail() {
        // TODO: Fix pls
        // validation.validateLogin(VALID_USER, VALID_PASSWORD);
        // ValidationResult result = validation.endSessionToken(VALID_USER, "wrong_token");
        // assertFalse(result.isValid);
        // assertEquals(AccountErrorCode.INVALID_TOKEN, result.errorCode);
    }

    @Test
    void endSessionNoSessionShouldFail() {
        // TODO: Fix pls
        // ValidationResult result = validation.endSessionToken(VALID_USER, "any_token");
        // assertFalse(result.isValid);
        // assertEquals(AccountErrorCode.SESSION_NOT_FOUND, result.errorCode);
    }

    // Tests for validateProfileEditUsername

    @Test
    void editUsernameIsValidShouldSucceed() {
        ValidationResult result = validation.validateProfileEditUsername(VALID_USER, VALID_PASSWORD,"new_name1");
        assertTrue(result.isValid);
    }

    @Test
    void editUsernameNotValidUserNotFound() {
        ValidationResult result = validation.validateProfileEditUsername("nobody",VALID_PASSWORD, "new_name1");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.USER_NOT_FOUND,result.errorCode);
    }

    @Test
    void editUsernameNotValidWrongPassword() {
        ValidationResult result = validation.validateProfileEditUsername(VALID_USER,  "WrongPass9", "new_name1");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_CREDENTIALS,result.errorCode);
    }

    @Test
    void editUsernameNotValidNewNameTaken() {
        // TODO: Fix pls
        // String hashed = AccountValidation.hashPassword("Password2");
        // UserProfile p2 = new UserProfile("user-002","taken_name");
        // credentialsStore.saveCredentials(new UserCredentials("user-002", "taken_name",hashed, p2));
        //
        // ValidationResult result = validation.validateProfileEditUsername(VALID_USER, VALID_PASSWORD, "taken_name");
        // assertFalse(result.isValid);
        // assertEquals(AccountErrorCode.USERNAME_TAKEN, result.errorCode);
    }


    @Test
    void editUsernameNotValidSameUsername() {
        ValidationResult result= validation.validateProfileEditUsername(VALID_USER, VALID_PASSWORD, VALID_USER);
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.USERNAME_TAKEN,result.errorCode);
    }

    @Test
    void editUsernameNotValidEmptyNewUsername() {
        ValidationResult result =validation.validateProfileEditUsername(VALID_USER, VALID_PASSWORD, "");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_FORMAT,result.errorCode);
    }

    // Tests for validateProfileEditPassword

    @Test
    void editPasswordIsValidShouldSucceed() {
        ValidationResult result = validation.validateProfileEditPassword(VALID_USER, VALID_PASSWORD,"NewPass99");
        assertTrue(result.isValid);
    }

    @Test
    void editPasswordNotValidUserNotFound() {
        ValidationResult result = validation.validateProfileEditPassword("nobody", VALID_PASSWORD,"NewPass99");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.USER_NOT_FOUND, result.errorCode);
    }

    @Test
    void editPasswordNotValidWrongCurrentPassword() {
        ValidationResult result =validation.validateProfileEditPassword(VALID_USER,"WrongPass9", "NewPass99");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_CREDENTIALS, result.errorCode);
    }

    @Test
    void editPasswordNotValidSamePassword() {
        ValidationResult result = validation.validateProfileEditPassword(VALID_USER,VALID_PASSWORD, VALID_PASSWORD);
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.PASSWORD_MISMATCH,result.errorCode);
    }


    @Test
    void editPasswordNotValidEmptyNewPassword() {
        ValidationResult result = validation.validateProfileEditPassword(VALID_USER,VALID_PASSWORD, "");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }


    @Test
    void editPasswordNotValidNoDigit() {
        ValidationResult result = validation.validateProfileEditPassword(VALID_USER, VALID_PASSWORD,"NoDigitsHere");
        assertFalse(result.isValid);
        assertEquals(AccountErrorCode.INVALID_FORMAT, result.errorCode);
    }
}
