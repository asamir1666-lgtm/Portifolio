package ca.ucalgary.seng300;

import javafx.application.Platform;
import javafx.scene.web.WebEngine;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class LobbyTest {
    private Bridge bridge;
    private WebEngine engine;

    @BeforeAll
    static void initJFX() {
        try {
            Platform.startup(() -> {});
        } catch (IllegalStateException e) {
            System.err.println("Failed to start JFX");
        }
    }

    @BeforeEach
    void setUp() {
        engine = mock(WebEngine.class);
        bridge = new Bridge(engine);
    }

    @Test
    void testNavigationActions() {
        assertDoesNotThrow(() -> {
            bridge.handleNavigation("DASHBOARD");
            bridge.handleNavigation("LOBBY");
        });
    }

    @Test
    void testSetUsername() {
        String testUser = "LUCKI";
        bridge.setUsername(testUser);

        verify(engine).executeScript("updateDashboardUI('LUCKI')");
    }

    @Test
    void testHandleNavigation_UnknownAction() {
        bridge.handleNavigation("HOME");
        verify(engine, never()).load(anyString());
    }

    @Test
    void testSendLeaderboardData_callsRenderLeaderboard() {
        assertDoesNotThrow(() -> bridge.sendLeaderboardData());
        verify(engine).executeScript(startsWith("if(typeof renderLeaderboard==='function')renderLeaderboard(["));
    }

    @Test
    void testLog_doesNotThrow() {
        assertDoesNotThrow(() -> bridge.log("test message"));
    }
}
