package ca.ucalgary.seng300.platformcore.game.tictactoe;

import ca.ucalgary.seng300.platformcore.Player;
import ca.ucalgary.seng300.validation.account.records.UserID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TicTacToeGameTest {

    // private TicTacToeGame game;
    // private Player p1;
    // private Player p2;

    @BeforeEach
    void setUp() {
        // TODO: Its not correct yet
        // p1 = new Player(new UserID("13"));
        // p2 = new Player(new UserID("22"));
        // game = new TicTacToeGame(3,3,p1,p2);
    }

    //Test for valid move
    @Test
    void testValidMove() {
        // TicTacToeMove move = new TicTacToeMove(0,0, "13");
        // game.receiveData(move);
        // assertNull(game.hasWin());
    }
}
