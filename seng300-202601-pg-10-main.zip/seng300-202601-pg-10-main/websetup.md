# JavaFX WebView Setup Guide

## Prerequisites
- IntelliJ IDEA
- JDK 25 — [Download here](https://jdk.java.net/25/)
- The project cloned from the repo

---

## Step 1 — Set Project SDK to JDK 25
1. Open IntelliJ and load the project
2. Go to **File → Project Structure → Project**
3. Under **SDK**, select `openjdk-25` (or click **Download JDK** and select version 25)
4. Hit **Apply → OK**

---

## Step 2 — Add JavaFX Web Dependency to `pom.xml`
Open `pom.xml` and make sure all three of these dependencies are inside `<dependencies>`:

```xml
<dependency>
    <groupId>org.openjfx</groupId>
    <artifactId>javafx-controls</artifactId>
    <version>25.0.2</version>
</dependency>

<dependency>
    <groupId>org.openjfx</groupId>
    <artifactId>javafx-fxml</artifactId>
    <version>25.0.2</version>
</dependency>

<dependency>
    <groupId>org.openjfx</groupId>
    <artifactId>javafx-web</artifactId>
    <version>25.0.2</version>
</dependency>
```
### Step 3 — Reload Maven
1. After saving pom.xml, click the 🐘 elephant icon in the top right of IntelliJ.
2. Or right-click pom.xml → Maven → Reload Project.
3. You should see javafx-web:25.0.2 appear under External Libraries.

### Step 4 - Verify Folder Structure
src/
└── main/
├── java/
│   └── ca/ucalgary/seng300/
│       ├── MainApp.java
│       └── Bridge.java
└── resources/
└── ca/ucalgary/seng300/
└── styles/ ← CSS files should be here 
└── views/
└── login.html   ← html files should be in views

## Step 5 - Run App
- Do NOT use the green play button. Always run via:
- Maven panel (right side) → Plugins → javafx → double-click javafx:run

