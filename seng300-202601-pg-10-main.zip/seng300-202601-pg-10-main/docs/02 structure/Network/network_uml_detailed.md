```plantuml
@startuml
skinparam dpi 75
scale max 4096 width
title Network Package - Detailed Class Diagram

hide empty members
skinparam classAttributeIconSize 0
skinparam linetype ortho

package "network" {
  class Client {
    - socket: Socket
    - out: ObjectOutputStream
    - serverAddress: InetAddress
    + router: ClientRouter
    + connect(): void
    + connect(skipValidation: Boolean): void
    + send(req: Payload.Request): void
  }

  class Server {
    - clients: Set<ClientData>
    - router: ServerRouter
    + start(): void
    + send(out: ObjectOutputStream, res: Payload.Response): void
  }

  class ClientData {
    - out: ObjectOutputStream
    - player: Player
    + getOutStream(): ObjectOutputStream
    + getPlayer(): Player
    + setPlayer(player: Player): void
  }

  enum DiscoveryType {
    SUBNET_SCAN
    BROADCAST
    MULTICAST
  }

  class Util {
    + getLocalIP(): String
  }
}

package "network.handler" {
  interface Validatable {
    + validate(): void
  }
}

package "network.handler.client" {
  abstract class ClientHandler {
    # sender: Consumer<Payload.Request>
    + setSender(sender: Consumer<Payload.Request>): void
    + handle(serverResponse: Payload.Response): void
  }

  class GameHandler {
    + setOnMove(cb): void
    + setOnMoveSync(cb): void
    + setOnError(cb): void
    + playMove(lobbyId: String, move: String): void
    + validate(): void
  }

  class "LobbyHandler" as ClientLobbyHandler {
    + setOnChat(cb): void
    + setOnChatSync(cb): void
    + setOnCreate(cb): void
    + setOnJoin(cb): void
    + setOnList(cb): void
    + setOnError(cb): void
    + validate(): void
  }
}

package "network.handler.server" {
  abstract class ServerHandler {
    + handle(payload: Payload.Request): Payload.Response
  }

  class AuthHandler {
    - accountDatabase: AccountDatabase
    + setOnLogin(cb): void
    + handle(req): Payload.Auth.Res
  }

  class "LobbyHandler" as ServerLobbyHandler {
    - lobbyDatabase: LobbyDatabase
    + handle(req): Payload.Lobby.Res
  }

  class ErrorHandler {
    + handle(payload: Payload.Error): Payload.Error
  }
}

package "network.message" {
  abstract class AbstractRouter {
    # handlers: Map
    # handlerInstances: Map
    + register(handler): void
    + getHandler(type): Object
  }

  class ClientRouter {
    + validateAll(): void
    + route(res: Payload.Response): void
    + wireAll(sender: Consumer<Payload.Request>): void
  }

  class ServerRouter {
    + route(req: Payload.Request): Payload.Response
  }

  interface Payload
  interface "Payload.Request" as PayloadRequest
  interface "Payload.Response" as PayloadResponse
  interface "Payload.Broadcast" as PayloadBroadcast
  interface "Payload.Sync" as PayloadSync

  interface "Payload.Auth.Req" as PayloadAuthReq
  interface "Payload.Auth.Res" as PayloadAuthRes
  interface "Payload.Lobby.Req" as PayloadLobbyReq
  interface "Payload.Lobby.Res" as PayloadLobbyRes
  interface "Payload.Game.Req" as PayloadGameReq
  interface "Payload.Game.Res" as PayloadGameRes

  class "Payload.Lobby.Req.Chat" as PayloadLobbyReqChat <<record>>
  class "Payload.Game.Req.Move" as PayloadGameReqMove <<record>>
  class "Payload.Error" as PayloadError <<record>>
}

package "external dependencies (referenced)" {
  class Config
  class Player
  class AccountDatabase
  class LobbyDatabase
}

' Router hierarchy
ClientRouter --|> AbstractRouter
ServerRouter --|> AbstractRouter

' Handler hierarchy
ClientHandler ..|> Validatable
GameHandler --|> ClientHandler
ClientLobbyHandler --|> ClientHandler
AuthHandler --|> ServerHandler
ServerLobbyHandler --|> ServerHandler
ErrorHandler --|> ServerHandler

' Payload hierarchy
PayloadRequest --|> Payload
PayloadResponse --|> Payload
PayloadBroadcast --|> PayloadRequest
PayloadSync --|> PayloadResponse
PayloadAuthReq --|> PayloadRequest
PayloadAuthRes --|> PayloadResponse
PayloadLobbyReq --|> PayloadRequest
PayloadLobbyRes --|> PayloadResponse
PayloadGameReq --|> PayloadRequest
PayloadGameRes --|> PayloadResponse
PayloadLobbyReqChat ..|> PayloadLobbyReq
PayloadLobbyReqChat ..|> PayloadBroadcast
PayloadGameReqMove ..|> PayloadGameReq
PayloadGameReqMove ..|> PayloadBroadcast
PayloadError ..|> PayloadAuthRes
PayloadError ..|> PayloadLobbyRes
PayloadError ..|> PayloadGameRes
PayloadError ..|> PayloadRequest

' Core package wiring
Client o-- ClientRouter
Server o-- ServerRouter
Server o-- ClientData
ClientData --> Player
Client ..> Util

' Registration/usage relationships
ClientRouter o-- GameHandler
ClientRouter o-- ClientLobbyHandler
ServerRouter o-- AuthHandler
ServerRouter o-- ServerLobbyHandler
ServerRouter o-- ErrorHandler

Client ..> PayloadRequest : sends
Client ..> PayloadResponse : receives
Server ..> PayloadRequest : receives
Server ..> PayloadResponse : sends

Client ..> Config
Server ..> Config
AuthHandler --> AccountDatabase
ServerLobbyHandler --> LobbyDatabase

@enduml
```
