```plantuml
@startuml
title Network Package - Simplified Class Diagram

hide empty members
skinparam classAttributeIconSize 0
skinparam linetype ortho
left to right direction

class Client
class Server
class ClientData
class Util
enum DiscoveryType

abstract class AbstractRouter
class ClientRouter
class ServerRouter

interface Validatable
abstract class ClientHandler
class GameHandler
class ClientLobbyHandler

abstract class ServerHandler
class AuthHandler
class ServerLobbyHandler
class ErrorHandler

interface Payload
interface PayloadRequest
interface PayloadResponse
class PayloadError

class Config
class Player
class AccountDatabase
class LobbyDatabase

ClientRouter --|> AbstractRouter
ServerRouter --|> AbstractRouter

ClientHandler ..|> Validatable
GameHandler --|> ClientHandler
ClientLobbyHandler --|> ClientHandler

AuthHandler --|> ServerHandler
ServerLobbyHandler --|> ServerHandler
ErrorHandler --|> ServerHandler

PayloadRequest --|> Payload
PayloadResponse --|> Payload
PayloadError ..|> PayloadRequest
PayloadError ..|> PayloadResponse

Client o-- ClientRouter
Server o-- ServerRouter
Server o-- ClientData
ClientData --> Player
Client ..> Util
Client ..> Config
Server ..> Config

ClientRouter o-- GameHandler
ClientRouter o-- ClientLobbyHandler
ServerRouter o-- AuthHandler
ServerRouter o-- ServerLobbyHandler
ServerRouter o-- ErrorHandler

Client ..> PayloadRequest : sends
Client ..> PayloadResponse : receives
Server ..> PayloadRequest : receives
Server ..> PayloadResponse : sends

AuthHandler --> AccountDatabase
ServerLobbyHandler --> LobbyDatabase

@enduml
```
