# Game Validation Integration Details
This document outlines all the details about how to integrate GameValidation into other aspects of the project. Specifically for Platform Core.

It is worth checking out the structure diagrams in: `docs/02 structure/Validation`

## Overview
There should only be one class that you should call methods on: `GameValidation`. Everything else can be ignored and should integrate properly. Keep in mind that every method on `GameValidation` is static.

One big change was changing any instance of playerID was switched to a string type, rather than an int. Since Account Validation uses Strings and UUIDs it makes the most sense to do this.

## `GameValidation` Methods

### `MoveValidationResult validateMove(GameType gameType, GameState gameState, String currentPlayerID, GameMove move)`
This method takes in information about the game and returns a `MoveValidationResult` object that outlines if the move is valid.

If the move isn't valid, then `MoveValidationResult.isValid` will be false and `MoveValidationResult.errorCode` and `MoveValidationResult.message` will give more information

### `WinValidationResult validateWin(GameState gameState, HashMap<String, Piece> playerIDToPiece)`
This method takes in information about the game and returns a `WinValidationResult` object which outlines if there was a win or draw.

If there is a win, `WinValidationResult.hasWinner` will be true, and `WinValidationResult.winnerID` will contain the ID of the winner

If it's a draw, `WinValidationResult.isTie` will be true

If neither is the case, both `WinValidationResult.hasWinner` and `WinValidationResult.isTie` will be false. And the game can continue.