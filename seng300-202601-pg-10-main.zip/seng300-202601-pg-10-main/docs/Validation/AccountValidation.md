# Account Validation Documentation
This outlines how Account Validation works for those integrating in the Platform Core subteam. It will outline the classes that you will use and the methods you call.

Also, look at docs/02 structure/Validation for a structure diagram of this. Most of it is unused by PC, but it could help.

## Basic Overview
There are only **two classes** you need to interact with, `AccountValidation` and `AccountDatabaseManager`. For most inquires, you will call methods on `AccountValidation`, but for editing, creating, or deleting accounts/profiles, you will use `AccountDatabaseManager`.

All of the methods on the classes you will call are **static**. This means you do not need to create an `AccountValidation` object. Rather, just call it directly via: `AccountValidation.validateLogin()` 

Most methods have descriptions commented above them. These automatically appear if you type the method and hover your mouth above the method name.

## Return values
There are a few classes that we return when you validate. These contain more information then just a boolean true false. They also list out an error code and a message.

We return classes like `ValidationResult` and `AccountValidationResult` (the latter extends the former). These are relatively simple. Containing a boolean isvalid, an errorCode, a message, and some extra information if needed.

Look at the classes themselves for more details, they aren't long.
## `AccountValidation`

### `validateLogin()`
Takes in a String username and password and returns an `AccountValidationResult` object.

If the login is successful, then the returned `AccountValidationResult` will contain a token that can be used to validate the user without the need for a password. It is recommended to do this often (like when joining a lobby)

### `validateToken()`
Takes in a username and a token. Use the token you got from `validateLogin()` here.

This is a quick and easy way to verify a user.

### `endSessionToken()`

Takes in a username and a token. It ends the session token so it can no longer be used. Meant to be used when the user is logging off or signs out

### Unused Methods
This is just a list of methods that are public, but not meant to be used by subteams outside of Validation. You are safe to ignore them and not call them.

- `validateRegistration()`
    - Use `createAccount()` in `AccountDatabaseManager` instead
- `validateProfileEditUsername()`
    - Use `updateUsername()` in `AccountDatabaseManager` instead
- `validateProfileEditPassword()`
    - Use `updatePassword()` in `AccountDatabaseManager` instead
- `generateSessionToken()`
- `hashPassword()`

## `AccountDatabaseManager`

Methods here are actually really well documented, and doesn't contain any public methods PC doesn't need. 

### `createAccount()`
Creates an account using the given name and password

### `updateUsername()`
Takes in the current username and password of a user and a new username. Changes the username to the new username

### `updatePassword()`
Takes in the current username and password of a user and a new password. Changes the password to the new password

### `deleteAccount()`
Takes in a username and password, and deletes the corresponding account
