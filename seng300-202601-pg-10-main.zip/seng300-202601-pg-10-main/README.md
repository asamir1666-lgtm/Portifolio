## Required Software

Confirm you have **all** the following:

- ✅ **JDK 25** ([Download here](https://jdk.java.net/25/))
- ✅ **IntelliJ IDEA** (Community or Ultimate)
- ✅ Git installed

> ⚠ **IntelliJ is the expected IDE for this setup.**

---

## Clone the Repository or Download the .zip file

Clone the starter repository using Git (HTTPS or SSH):

```
git clone <repo-url>
cd <repo-directory>
```

Otherwise, download the .zip containing all the necessary files that are needed to run the project

---

## Open the Project in IntelliJ

1. Open IntelliJ IDEA
2. Choose Open
3. Select the root folder of the repository (or navigate to the directory where the project files are located)
4. When prompted:
    - Trust the project
    - Allow IntelliJ to import the Maven project

IntelliJ should detect this as a Maven project automatically.

# JavaFX WebView Setup Guide

---

## Step 1 — Set Project SDK to JDK 25
1. Once project is open, go to **File → Project Structure → Project**
2. Under **SDK**, select `openjdk-25` (or click **Download JDK** and select version 25)
3. Hit **Apply → OK**

---

## Step 2 — Add JavaFX Web Dependency to `pom.xml`
Open `pom.xml` and make sure all three of these dependencies are inside `<dependencies>`:

```xml
<dependency>
    <groupId>org.openjfx</groupId>
    <artifactId>javafx-controls</artifactId>
    <version>25.0.2</version>
</dependency>

<dependency>
    <groupId>org.openjfx</groupId>
    <artifactId>javafx-fxml</artifactId>
    <version>25.0.2</version>
</dependency>

<dependency>
    <groupId>org.openjfx</groupId>
    <artifactId>javafx-web</artifactId>
    <version>25.0.2</version>
</dependency>
```
### Step 3 — Reload Maven
1. After saving pom.xml, click the 🐘 elephant icon in the top right of IntelliJ.
2. Or right-click pom.xml → Maven → Reload Project.
3. You should see javafx-web:25.0.2 appear under External Libraries.

## Step 4 - Run App
- Do NOT use the green play button. Always run via:
- Maven panel (right side) → Plugins → javafx → double-click javafx:run
- Doing so will result in the following error:

```
JavaFX runtime components are missing
```

---

## Run the Project (Choose One Method)

### Option A - Run in IntelliJ (recommended)

1. Open the Maven tool window
2. Expand:
   Project
   -> Plugins
   -> javafx
3. Double-click:
   javafx:run

A JavaFX window should open.

---

### Option B - Run from the Terminal (Maven Wrapper)

This project uses the Maven Wrapper.
You do not need to install Maven.

Windows (PowerShell):

```
.\mvnw.cmd javafx:run
```

macOS or Linux:

```
./mvnw javafx:run
```

First run note:
The first run may take one to two minutes while dependencies download. This is normal.

---

## Expected Result

If everything is correct:
- A JavaFX window opens
- No JavaFX runtime errors appear
- No additional setup is required

You are ready to use the project.

---

## JUnit Test Cases
In order to run the JUnit tests pertaining to the lobby bridge, must first edit its configuration
- You must first edit the configuration of the given JUnit file that you want to run
- To run a JUnit file, first navigate to the top under "run" and select "edit configuration"
- Then click the + icon on the top left of the new window and select "JUnit"
- Beside the "Class" option, navigate to the path where the JUnit file is located
- Lastly, in the VM field, enter "-Dnet.bytebuddy.experimental=true"
- From here, you can click "apply" followed by "ok" where you can then run the rest cases
- Note that this configuration is only required for test case files that use WebEngine
---


## Common Problems (Quick Check)

If something goes wrong, check these first:

- Running MainApp directly instead of javafx:run
- Wrong JDK selected in IntelliJ
- Installing JavaFX manually
- Using mvn instead of mvnw or mvnw.cmd

If the JavaFX window opens, your setup is correct.

---

## Summary

If the project runs using javafx:run, your setup is correct and you may begin work.

